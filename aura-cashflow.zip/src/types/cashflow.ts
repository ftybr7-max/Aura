/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Comprehensive UK Wealth & Retirement Data Types
 */

export type TaxRegion = 'england_wales_ni' | 'scotland';

export type PensionType = 'dc' | 'db';

export type MortgageType = 'repayment' | 'interest_only';

export type DrawdownStrategy = 'tax_optimised' | 'pro_rata' | 'pension_first' | 'isa_first' | 'cash_first' | 'custom';

export type DrawdownPotKey = 'cash' | 'gia' | 'pension' | 'isa';

export type IndividualOwner = 'primary' | 'partner';

export type OwnershipType = 'primary' | 'partner' | 'joint';

export type LegalRelationshipType = 'spouse_civil_partner' | 'unmarried_partner' | 'other';

export interface PersonalDetails {
  fullName: string;
  currentAge: number;
  targetRetirementAge: number;
  planningHorizonAge: number; // e.g. 95 or 100
  taxRegion: TaxRegion;
  hasPartner: boolean;
  partnerName?: string;
  partnerAge?: number;
  partnerTargetRetirementAge?: number;
  partnerTaxRegion?: TaxRegion;
  relationshipType?: LegalRelationshipType; // 'spouse_civil_partner' | 'unmarried_partner' | 'other'
  isAlreadyRetired?: boolean;
  partnerIsAlreadyRetired?: boolean;
}

export interface EmploymentIncome {
  id: string;
  owner: IndividualOwner; // Strictly individual under UK PAYE legislation
  label: string;
  annualGross: number;
  annualBonus: number;
  employeePensionPercent: number;
  employerPensionPercent: number;
  isSalarySacrifice: boolean;
  annualGrowthPercent: number;
}

export interface OtherIncome {
  id: string;
  owner: OwnershipType;
  jointSplitPercent?: number; // e.g. 50% for 50/50 split (primary %), remainder to partner
  label: string;
  annualAmount: number;
  startAge: number;
  endAge: number;
  isTaxable: boolean;
  isInflationLinked: boolean;
}

export interface ExpenseItem {
  id: string;
  owner?: OwnershipType;
  jointSplitPercent?: number;
  label: string;
  category: 'essential' | 'lifestyle' | 'housing' | 'healthcare' | 'one_off';
  annualAmount: number;
  startAge: number;
  endAge: number;
  isSingleYear?: boolean; // If true, one-off single outgoing in startAge year only
  retirementMultiplier: number; // e.g., 0.8 for 80% spending in retirement
  isInflationLinked: boolean;
  notes?: string;
}

export type LifeEventType =
  | 'inheritance'
  | 'business_sale'
  | 'property_downsize'
  | 'gift_out'
  | 'education_fees'
  | 'wedding_gift'
  | 'major_purchase'
  | 'custom';

export interface LifeEvent {
  id: string;
  label: string;
  type: LifeEventType;
  direction: 'inflow' | 'outflow'; // cash in vs cash out
  amount: number; // £ lump sum (in today's money or nominal)
  targetAge: number; // Primary client age when event occurs (assume start of tax year)
  calendarYear?: number;
  notes?: string;
  owner?: OwnershipType;
  jointSplitPercent?: number;
}

export interface DefinedContributionPension {
  id: string;
  owner: IndividualOwner; // Strictly individual under HMRC Pensions Tax Manual
  label: string;
  currentPotValue: number;
  ongoingMonthlyContribution: number;
  ongoingEmployerMonthlyContribution: number;
  fundingSource?: 'salary' | 'surplus_cash' | 'cash' | string;
  growthRatePercent: number;
  annualFeePercent: number;
  taxFreeCashTakenPercent: number; // 0-25%
  isTargetForDrawdown: boolean;
}

export type GiftClassification =
  | 'PET'
  | 'CLT'
  | 'EXEMPT_ANNUAL'
  | 'EXEMPT_MARRIAGE'
  | 'EXEMPT_SMALL'
  | 'EXEMPT_EXCESS_INCOME'
  | 'EXEMPT_CHARITY'
  | 'pet'
  | 'clt'
  | 'excess_income'
  | 'annual_exemption'
  | 'small_gift'
  | 'marriage_gift'
  | 'spousal';

export type GiftType = GiftClassification;

export interface HistoricGift {
  id: string;
  donor: IndividualOwner | 'joint'; // 'primary' | 'partner' | 'joint'
  doneeName: string;
  doneeRelationship?: string;
  giftDate: string; // YYYY-MM-DD
  amount: number;
  type: GiftClassification;
  description?: string;
  exemptReason?: string;
  annualExemptionClaimed?: number; // £0 - £3,000 (or £6,000 if 1-year carry-forward used)
  taperReliefPercent?: number; // e.g. 0%, 20%, 40%, 60%, 80%, 100%
  notes?: string;
}

export interface ExcessIncomeGiftingPlan {
  enabled?: boolean;
  isEnabled?: boolean;
  donor: IndividualOwner | 'joint' | 'household';
  annualAmount?: number;
  annualGiftAmount?: number;
  habitualFrequency?: 'monthly' | 'quarterly' | 'annual';
  fundingFrequency?: 'monthly' | 'annual';
  doneeDescription?: string;
  recipientName?: string;
  recipientRelationship?: string;
  startAge?: number;
  durationYears?: number; // e.g. 5, 10, or up to planning horizon
  documentationInPlace?: boolean;
  notes?: string;
}

export interface DefinedBenefitPension {
  id: string;
  owner: IndividualOwner; // Strictly individual under HMRC Pensions Tax Manual
  label: string;
  annualGuaranteedIncome: number;
  startAge: number;
  annualEscalationPercent: number; // e.g. CPI up to 2.5% or 5%
  lumpSumOption: number;
  spousesBenefitPercent: number; // e.g. 50%
}

export interface IsaAccount {
  id: string;
  owner: IndividualOwner; // Strictly individual under UK Individual Savings Account Regulations 1998
  label: string;
  balance: number;
  ongoingMonthlyContribution: number;
  fundingSource?: 'surplus_cash' | string; // 'surplus_cash' (default) or GIA id for Bed & ISA
  growthRatePercent: number;
  annualFeePercent: number;
}

export interface GiaAccount {
  id: string;
  owner: OwnershipType; // Can be sole or tenants-in-common / joint
  jointSplitPercent?: number; // Default 50%
  label: string;
  balance: number;
  costBasis: number;
  ongoingMonthlyContribution: number;
  fundingSource?: 'surplus_cash' | 'cash' | string;
  growthRatePercent: number;
  dividendYieldPercent: number;
  annualFeePercent: number;
}

export interface CashAccount {
  id: string;
  owner: OwnershipType; // Can be sole or joint bank accounts / NS&I
  jointSplitPercent?: number; // Default 50%
  label: string;
  balance: number;
  interestRatePercent: number;
  isEmergencyFund: boolean;
  minimumReserve: number;
}

export type SpecialistInvestmentType =
  | 'eis'
  | 'vct'
  | 'seis'
  | 'onshore_bond'
  | 'offshore_bond'
  | 'direct_shares_plc'
  | 'direct_shares_private'
  | 'other';

export type InvestmentBondType = 'onshore' | 'offshore';

export type BondTrustType =
  | 'none'
  | 'discretionary'
  | 'loan_trust'
  | 'discounted_gift_trust'
  | 'bare_trust';

export interface InvestmentBondAccount {
  id: string;
  owner: OwnershipType; // primary, partner, joint (joint life second death)
  jointSplitPercent?: number; // default 50%
  label: string;
  bondType: InvestmentBondType; // 'onshore' (UK Life Assurance) or 'offshore' (International Life Assurance)
  originalPremium: number; // Initial capital invested (£) - base for statutory 5% tax-deferred allowance
  currentValue: number; // Current valuation / market value (£)
  yearsHeld: number; // Complete policy years held since inception (for cumulative 5% calculation & top slicing)
  cumulativeWithdrawalsTaken: number; // Total £ withdrawals already taken to date under 5% rule
  annualWithdrawalPercent?: number; // Planned regular annual tax-deferred withdrawal % (e.g. 5.0% or 0%)
  annualWithdrawalAmount?: number; // Planned regular annual withdrawal (£/yr)
  growthRatePercent: number; // Expected gross annual growth rate (default 4.0%)
  annualFeePercent: number; // Annual management charge & platform fee (default 0.5%)
  heldInTrust?: boolean; // Held within an IHT / estate planning trust
  trustType?: BondTrustType;
  notes?: string;
}

export interface OtherInvestmentAccount {
  id: string;
  owner: OwnershipType; // primary, partner, joint
  jointSplitPercent?: number;
  label: string;
  investmentType: SpecialistInvestmentType;
  balance: number; // Current market value (£)
  costBasis: number; // Acquisition cost / purchase base (£)
  ongoingMonthlyContribution?: number;
  growthRatePercent: number;
  dividendYieldPercent: number;
  annualFeePercent: number;
  notes?: string;
}

export interface PropertyAsset {
  id: string;
  owner?: OwnershipType;
  jointSplitPercent?: number; // Default 50%
  label: string;
  isPrimaryResidence: boolean;
  currentValue: number;
  costBasis?: number; // Acquisition price / base cost for CGT (for non-primary residences)
  annualGrowthPercent: number;
  rentalIncomeAnnual: number;
  isDownsizingPlanned: boolean;
  downsizeAge?: number;
  downsizeYear?: number;
  downsizeTargetValue?: number;
  downsizeReleasedAmount?: number;
  downsizeReleaseToSavings?: boolean;
}

export interface MortgageLiability {
  id: string;
  owner?: OwnershipType;
  jointSplitPercent?: number; // Default 50%
  propertyId: string;
  label: string;
  outstandingBalance: number;
  interestRatePercent: number;
  remainingTermYears: number;
  monthlyPayment: number;
  mortgageType: MortgageType;
}

export interface OtherLiability {
  id: string;
  owner?: OwnershipType;
  jointSplitPercent?: number;
  label: string;
  outstandingBalance: number;
  interestRatePercent: number;
  monthlyPayment: number;
  remainingTermYears: number;
}

export interface StatePensionSettings {
  includeStatePension: boolean;
  primaryStatePensionAge: number; // typically 66-68
  primaryAnnualAmount: number; // Full new State Pension £12,450.00 (2026/27 Triple Lock)
  partnerStatePensionAge?: number;
  partnerAnnualAmount?: number;
  tripleLockAssumptionPercent: number;
}

export interface EconomicAssumptions {
  inflationRatePercent: number; // Default CPI at 2.0%
  realTermsDiscounting: boolean; // default true for today's purchasing power
  defaultEquityGrowthRatePercent: number; // Default 4.0% (after fees)
  defaultBondCashGrowthRatePercent: number; // Default 2.0% for cash/National Savings
  advisorPlatformFeePercent: number; // e.g. 0.00% or user-customised
  drawdownStrategy: DrawdownStrategy;
  customDrawdownOrder?: DrawdownPotKey[];
  includePensionsInIhtPost2027: boolean; // UK Autumn Budget 2024 legislated change effective 6 April 2027
}

export interface CashflowProfile {
  personal: PersonalDetails;
  employment: EmploymentIncome[];
  otherIncomes: OtherIncome[];
  expenses: ExpenseItem[];
  lifeEvents?: LifeEvent[];
  historicGifts?: HistoricGift[];
  excessIncomeGifting?: ExcessIncomeGiftingPlan;
  dcPensions: DefinedContributionPension[];
  dbPensions: DefinedBenefitPension[];
  isas: IsaAccount[];
  gias: GiaAccount[];
  cashAccounts: CashAccount[];
  investmentBonds?: InvestmentBondAccount[];
  otherInvestments?: OtherInvestmentAccount[];
  properties: PropertyAsset[];
  mortgages: MortgageLiability[];
  otherLiabilities: OtherLiability[];
  statePension: StatePensionSettings;
  assumptions: EconomicAssumptions;
}

export interface TaxCalculationResult {
  grossIncome: number;
  adjustedNetIncome: number;
  personalAllowance: number;
  basicRateTax: number;
  higherRateTax: number;
  additionalRateTax: number;
  totalIncomeTax: number;
  nationalInsurance: number;
  dividendTax: number;
  cgtPaid: number;
  totalTax: number;
  netIncome: number;
  effectiveTaxRatePercent: number;
  marginalTaxRatePercent: number;
  pensionTaxReliefReceived: number;
}

export interface YearlyCashflowData {
  year: number;
  calendarYear: number;
  age: number;
  partnerAge?: number;
  isRetired: boolean;
  isPartnerRetired?: boolean;
  discountFactor: number;

  // Inflows
  grossEmploymentIncome: number;
  grossBonus: number;
  dbPensionIncome: number;
  statePensionIncome: number;
  rentalIncome: number;
  otherTaxableIncome: number;
  otherNonTaxableIncome: number;
  totalGrossInflow: number;

  // Deductions & Tax
  pensionContributionsTotal: number;
  incomeTax: number;
  nationalInsurance: number;
  totalTaxPaid: number;
  netSpendableInflow: number;

  // Outflows
  livingExpenses: number;
  mortgagePayments: number;
  otherDebtPayments: number;
  totalOutflows: number;

  // Cashflow Gap
  cashflowSurplusOrDeficit: number;

  // Drawdown sources (if deficit)
  drawdownCash: number;
  drawdownGia: number;
  drawdownIsa: number;
  drawdownPensionTaxFree: number;
  drawdownPensionTaxable: number;
  totalDrawdown: number;
  unmetShortfall: number;

  // Asset Balances (Nominal)
  pensionPotNominal: number;
  isaBalanceNominal: number;
  giaBalanceNominal: number;
  cashBalanceNominal: number;
  propertyValueNominal: number;
  liquidNetWorthNominal: number;
  totalNetWorthNominal: number;
  mortgageDebtNominal: number;

  // Asset Balances (Real - In Today's Money)
  pensionPotReal: number;
  isaBalanceReal: number;
  giaBalanceReal: number;
  cashBalanceReal: number;
  propertyValueReal: number;
  liquidNetWorthReal: number;
  totalNetWorthReal: number;
  mortgageDebtReal: number;

  // Real Terms Inflows/Outflows
  totalGrossInflowReal: number;
  netSpendableInflowReal: number;
  totalOutflowsReal: number;
  totalDrawdownReal: number;
  unmetShortfallReal: number;

  // Key Life Events occurring in this year
  activeLifeEvents?: LifeEvent[];

  // Individual Partner Tax Breakdown
  primaryGrossInflow: number;
  primaryIncomeTax: number;
  primaryNationalInsurance: number;
  primaryNetIncome: number;
  partnerGrossInflow?: number;
  partnerIncomeTax?: number;
  partnerNationalInsurance?: number;
  partnerNetIncome?: number;
  isMarriedOrCivilPartner?: boolean;
  spousalIhtExemptionApplied?: boolean;

  // IHT Estate Projection
  estimatedGrossEstate: number;
  estimatedIhtLiability: number;
  netEstateToHeirs: number;
}

export interface CashflowSimulationResult {
  years: YearlyCashflowData[];
  retirementAge: number;
  planningHorizonAge: number;
  ageFundsDepleted: number | null; // null if never depleted
  isPlanFullyFunded: boolean;
  sustainableAnnualSpendingNominal: number;
  sustainableAnnualSpendingReal: number;
  wealthAtRetirementNominal: number;
  wealthAtRetirementReal: number;
  legacyWealthAt95Nominal: number;
  legacyWealthAt95Real: number;
  totalLifetimeTaxPaidNominal: number;
  totalLifetimeTaxPaidReal: number;
  totalPensionsSavedTaxNominal: number;
  peakNetWorthNominal: number;
  peakNetWorthAge: number;
  projectedIhtLiabilityAtEndNominal: number;
  projectedIhtLiabilityAtEndReal: number;
  summaryMilestones: {
    today: { age: number; netWorth: number };
    retirement: { age: number; netWorth: number; annualSpending: number };
    mortgageFreeAge?: number;
    statePensionAge: number;
    age75: { netWorth: number };
    planningHorizon: { age: number; netWorth: number };
  };
}

export interface MonteCarloTrialResult {
  trialIndex: number;
  isSuccessful: boolean;
  depletionAge: number | null;
  terminalWealthReal: number;
  yearlyLiquidWealthReal: number[];
}

export interface MonteCarloSummary {
  trialsCount: number;
  successProbabilityPercent: number; // e.g. 92%
  medianTerminalWealthReal: number;
  p10TerminalWealthReal: number;
  p90TerminalWealthReal: number;
  medianDepletionAge: number | null;
  yearlyPercentilesReal: {
    age: number;
    p10: number;
    p25: number;
    p50: number; // median
    p75: number;
    p90: number;
  }[];
  resilienceRating: 'Very High' | 'High' | 'Moderate' | 'Vulnerable' | 'Critical';
  verdictPlainEnglish: string;
}

export interface WhatIfScenarioModifiers {
  retirementAgeOffset: number; // e.g. -3 (retire 3 years earlier)
  spendingChangePercent: number; // e.g. -10% or +15%
  marketReturnOffsetPercent: number; // e.g. -1.5%
  inflationRateOffsetPercent: number; // e.g. +1.0%
  earlyDownsize: boolean;
  marketCrashAtRetirement: boolean; // toggle for market crash shock
  marketCrashTiming?: 'next_year' | 'at_retirement' | 'custom_year'; // crash timing option
  marketCrashYear?: number; // specific year (from 2026 onwards, default next year)
  marketCrashSeverityPercent?: number; // default -25%
  longTermCareCostShock: boolean; // £50k/year expense from age 82 for 3 years
  includeStatePension: boolean;
}

export interface AdviserPracticeDetails {
  adviserName: string;
  adviserTitle: string; // e.g. "Independent Financial Adviser", "Chartered Financial Planner, FPFS"
  firmName: string; // e.g. "Aura Wealth Advisory"
  firmTagline: string; // e.g. "Independent Cashflow Modelling & Wealth Planning"
  email: string;
  phone: string;
  website: string;
  officeAddress: string;
  adviserNotes?: string;
}

export const DEFAULT_ADVISER_DETAILS: AdviserPracticeDetails = {
  adviserName: 'James Sterling, FPFS',
  adviserTitle: 'Chartered Financial Planner',
  firmName: 'Aura Wealth Advisory',
  firmTagline: 'Precision Cashflow Modelling & Retirement Projections',
  email: 'j.sterling@auracashflow.co.uk',
  phone: '+44 (0)20 7946 0192',
  website: 'www.auracashflow.co.uk',
  officeAddress: '125 Old Broad Street, City of London, EC2N 1AR',
  adviserNotes: 'Cashflow modelling is provided for strategic illustration and scenario planning purposes.',
};
