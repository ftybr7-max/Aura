/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Master Application Entry Point
 * Implements Step 3: Entry Flow, Landing Hub & In-Session Planning Workspace.
 */

import React, { useState } from 'react';
import { CashflowProvider, useCashflow } from './aura/context/CashflowContext';
import { Header } from './components/layout/Header';
import { LandingWelcomeHub } from './components/hub/LandingWelcomeHub';
import { ModellerDashboard } from './components/dashboard/ModellerDashboard';
import { ProfileStudio } from './components/profile/ProfileStudio';
import { TaxDrawdownOptimizer } from './components/drawdown/TaxDrawdownOptimizer';
import { WhatIfLab } from './components/whatif/WhatIfLab';
import { MonteCarloView } from './components/montecarlo/MonteCarloView';
import { FinancialReportView } from './components/report/FinancialReportView';
import { RulesAuditRegistry } from './components/rules/RulesAuditRegistry';
import { PrivacyModal } from './components/common/PrivacyModal';
import { HardDrive } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab } = useCashflow();
  const [isSessionActive, setIsSessionActive] = useState<boolean>(true);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  // If in Welcome Hub mode, render the full Landing Hub
  if (!isSessionActive) {
    return (
      <LandingWelcomeHub
        onEnterSession={() => setIsSessionActive(true)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Primary Top Header & Tab Navigation */}
      <Header
        onExitSession={() => setIsSessionActive(false)}
        onOpenPrivacy={() => setIsPrivacyModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'modeller' && <ModellerDashboard />}
        {activeTab === 'profile' && <ProfileStudio />}
        {activeTab === 'drawdown' && <TaxDrawdownOptimizer />}
        {activeTab === 'whatif' && <WhatIfLab />}
        {activeTab === 'montecarlo' && <MonteCarloView />}
        {activeTab === 'report' && <FinancialReportView />}
        {activeTab === 'rules' && <RulesAuditRegistry />}
      </main>

      {/* Trust & Data Transparency Footer */}
      <footer className="no-print border-t border-slate-200 bg-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-emerald-700" />
            <span>
              <strong>Private & Local:</strong> All financial data is calculated and stored exclusively inside your browser’s local storage.
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setIsSessionActive(false)}
              className="text-amber-700 hover:text-amber-800 font-semibold hover:underline cursor-pointer"
            >
              ← Return to Welcome Hub
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => setIsPrivacyModalOpen(true)}
              className="text-slate-600 hover:text-emerald-800 font-medium hover:underline cursor-pointer"
            >
              Export / Import JSON Data
            </button>
            <span>·</span>
            <span>UK Tax Year 2026/27 Rules Engine</span>
          </div>
        </div>
      </footer>

      {/* Privacy & Backup Modal */}
      <PrivacyModal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <CashflowProvider>
      <AppContent />
    </CashflowProvider>
  );
}
