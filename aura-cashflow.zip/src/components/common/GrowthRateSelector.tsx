/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Reusable Growth Rate Selector with Standard Presets & Custom Free-Text
 */

import React, { useState, useEffect } from 'react';
import { Percent, Sparkles } from 'lucide-react';

interface GrowthRateSelectorProps {
  id?: string;
  label: string;
  value: number;
  onChange: (val: number) => void;
  helperText?: string;
  defaultPreset?: number; // e.g. 4.0 for equities/pensions, 2.0 for cash, 3.0 for property
  defaultRate?: number; // alias for defaultPreset
  presets?: number[];
  benchmarkNote?: string;
  min?: number;
  max?: number;
  step?: number;
}

const DEFAULT_PRESETS = [0, 1, 2, 3, 4, 5, 6, 7, 8];

export const GrowthRateSelector: React.FC<GrowthRateSelectorProps> = ({
  id,
  label,
  value,
  onChange,
  helperText,
  defaultPreset,
  defaultRate,
  presets,
  benchmarkNote,
  min = -10,
  max = 25,
  step = 0.1,
}) => {
  const targetDefault = defaultPreset ?? defaultRate ?? 4.0;
  const activePresets = presets && presets.length > 0 ? presets : DEFAULT_PRESETS;
  
  // Ensure the targetDefault is included in presets list if not present
  const fullPresetsList = Array.from(new Set([...activePresets, targetDefault])).sort((a, b) => a - b);

  // Check if current value matches one of our exact presets
  const isPresetMatch = fullPresetsList.includes(value);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(!isPresetMatch);

  useEffect(() => {
    if (!fullPresetsList.includes(value)) {
      setIsCustomMode(true);
    }
  }, [value, fullPresetsList]);

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = e.target.value;
    if (selected === 'custom') {
      setIsCustomMode(true);
    } else {
      setIsCustomMode(false);
      const numVal = parseFloat(selected);
      if (!isNaN(numVal)) {
        onChange(numVal);
      }
    }
  };

  const handleCustomInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const num = parseFloat(e.target.value);
    onChange(isNaN(num) ? 0 : num);
  };

  const selectValue = isCustomMode ? 'custom' : fullPresetsList.includes(value) ? String(value) : 'custom';

  return (
    <div className="space-y-1.5" id={id}>
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-slate-800 tracking-tight flex items-center gap-1.5">
          {label}
        </label>
        {benchmarkNote ? (
          <span className="text-[10px] text-slate-500 font-normal">{benchmarkNote}</span>
        ) : (
          targetDefault !== undefined && (
            <button
              type="button"
              onClick={() => {
                setIsCustomMode(false);
                onChange(targetDefault);
              }}
              className="text-[10px] text-emerald-700 hover:text-emerald-800 font-medium inline-flex items-center gap-0.5 hover:underline"
              title={`Reset to default benchmark (${targetDefault}%)`}
            >
              <Sparkles className="w-2.5 h-2.5" />
              Default {targetDefault}%
            </button>
          )
        )}
      </div>

      <div className="flex items-center gap-2">
        {/* Preset Dropdown */}
        <div className="relative flex-1 min-w-[120px]">
          <select
            value={selectValue}
            onChange={handleSelectChange}
            className="w-full bg-white border border-slate-300 text-slate-800 text-xs rounded-xl focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 py-2 px-3 font-medium transition-all appearance-none cursor-pointer pr-8"
          >
            {fullPresetsList.map((p) => (
              <option key={p} value={p}>
                {p}% {p === targetDefault ? `(Default Benchmark)` : ''}
              </option>
            ))}
            <option value="custom">Custom %...</option>
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-slate-400">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>

        {/* Custom Input Field (visible when custom chosen or non-standard percent active) */}
        {isCustomMode && (
          <div className="relative flex-1 min-w-[100px] animate-in fade-in duration-150">
            <input
              type="number"
              step={step}
              min={min}
              max={max}
              value={isNaN(value) ? '' : value}
              onChange={handleCustomInputChange}
              placeholder="e.g. 4.25"
              className="w-full bg-white border border-slate-300 text-slate-800 text-xs rounded-xl focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 py-2 pl-3 pr-7 font-mono font-medium transition-all"
            />
            <span className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400 text-xs font-semibold">
              %
            </span>
          </div>
        )}
      </div>

      {helperText && <p className="text-[11px] text-slate-500 leading-tight">{helperText}</p>}
    </div>
  );
};
