/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Official Brand Logo & Golden Wave Emblem
 * High-definition vector rendition matching the authentic Aura Cashflow brand identity.
 */

import React from 'react';

interface AuraBrandLogoProps {
  variant?: 'full' | 'emblem' | 'compact-header' | 'report-header';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showTagline?: boolean;
}

export const AuraBrandLogo: React.FC<AuraBrandLogoProps> = ({
  variant = 'compact-header',
  size = 'md',
  className = '',
  showTagline = true,
}) => {
  // Golden circular emblem SVG with stylized 'A' and intersecting golden wave ribbon
  const EmblemSvg = ({ className = 'w-10 h-10' }: { className?: string }) => (
    <svg
      viewBox="0 0 200 200"
      className={`${className} shrink-0 drop-shadow-md`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Aura Cashflow Golden Emblem"
    >
      <defs>
        {/* Rich Metallic Gold Gradient */}
        <linearGradient id="auraGoldLinear" x1="20" y1="20" x2="180" y2="180" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFF1B8" />
          <stop offset="25%" stopColor="#E6C667" />
          <stop offset="50%" stopColor="#C99824" />
          <stop offset="75%" stopColor="#F7DF8D" />
          <stop offset="100%" stopColor="#A37512" />
        </linearGradient>

        {/* Golden Wave Ribbon Gradient */}
        <linearGradient id="auraWaveGradient" x1="10" y1="120" x2="190" y2="110" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#DEBA57" />
          <stop offset="35%" stopColor="#FFF2BD" />
          <stop offset="65%" stopColor="#CA9928" />
          <stop offset="100%" stopColor="#F9E299" />
        </linearGradient>

        {/* Soft Drop Shadow Filter for Ribbon */}
        <filter id="auraGlow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#040915" floodOpacity="0.6" />
        </filter>
      </defs>

      {/* Outer Golden Ring */}
      <circle
        cx="100"
        cy="100"
        r="80"
        stroke="url(#auraGoldLinear)"
        strokeWidth="11"
        strokeLinecap="round"
      />

      {/* Inner Stylized Geometric 'A' Apex and Legs */}
      <path
        d="M100 35 L48 152 H72 L100 78 L128 152 H152 L100 35Z"
        fill="url(#auraGoldLinear)"
      />

      {/* Inner Triangle Opening in 'A' */}
      <path
        d="M100 80 L76 138 H124 L100 80Z"
        fill="#081326"
      />

      {/* Intersecting Flowing Golden Wave Ribbon */}
      <path
        d="M16 142 C46 112, 78 104, 102 115 C132 129, 160 120, 192 108 C168 126, 138 142, 108 132 C78 122, 48 132, 16 142 Z"
        fill="url(#auraWaveGradient)"
        filter="url(#auraGlow)"
      />
    </svg>
  );

  // Variant 1: Compact Header (Optimized for top nav bar on mobile, tablet & desktop)
  if (variant === 'compact-header') {
    return (
      <div className={`flex items-center gap-2.5 sm:gap-3 shrink-0 ${className}`}>
        <EmblemSvg className="w-9 h-9 sm:w-10 sm:h-10" />
        <div className="flex flex-col leading-none">
          <div className="flex items-baseline gap-1.5">
            <span className="font-sans font-black text-base sm:text-lg tracking-wider text-white">
              AURA
            </span>
            <span className="font-sans font-bold text-xs sm:text-sm tracking-widest text-[#E6C667]">
              CASHFLOW
            </span>
          </div>
          {showTagline && (
            <span className="text-[8px] sm:text-[9px] font-semibold tracking-widest uppercase text-slate-300/80 mt-0.5 whitespace-nowrap">
              Model Today. Live Tomorrow.
            </span>
          )}
        </div>
      </div>
    );
  }

  // Variant 2: Full Display Hero (For Landing & Welcome Hub)
  if (variant === 'full') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`}>
        {/* Large Emblem */}
        <div className="relative mb-5 group">
          <div className="absolute inset-0 rounded-full bg-amber-500/10 blur-2xl transform group-hover:scale-110 transition-transform duration-500" />
          <EmblemSvg className="w-24 h-24 sm:w-32 sm:h-32 relative z-10" />
        </div>

        {/* Brand Name Typography */}
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-3">
            <span className="font-sans font-black text-3xl sm:text-5xl tracking-[0.25em] text-white pl-2">
              AURA
            </span>
          </div>
          <div className="flex items-center justify-center">
            <span className="font-sans font-bold text-lg sm:text-2xl tracking-[0.35em] text-[#E6C667] pl-2">
              CASHFLOW
            </span>
          </div>
        </div>

        {/* Gold Divider Rule */}
        <div className="w-20 sm:w-28 h-0.5 bg-gradient-to-r from-transparent via-[#E6C667] to-transparent my-3 sm:my-4" />

        {/* Official Slogan */}
        {showTagline && (
          <p className="text-xs sm:text-sm font-medium tracking-[0.28em] text-slate-300 uppercase">
            Model Today. Live Tomorrow.
          </p>
        )}
      </div>
    );
  }

  // Variant 3: Report Header (For Printed PDF / Client Plan)
  if (variant === 'report-header') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <EmblemSvg className="w-11 h-11" />
        <div>
          <div className="flex items-baseline gap-1.5 leading-none">
            <span className="font-sans font-black text-xl tracking-wider text-slate-900">
              AURA
            </span>
            <span className="font-sans font-bold text-sm tracking-widest text-[#B8860B]">
              CASHFLOW
            </span>
          </div>
          <p className="text-[9px] font-semibold tracking-widest uppercase text-slate-500 mt-1">
            Model Today. Live Tomorrow.
          </p>
        </div>
      </div>
    );
  }

  // Variant 4: Icon Emblem Only
  return <EmblemSvg className={`${size === 'xl' ? 'w-20 h-20' : size === 'lg' ? 'w-14 h-14' : size === 'sm' ? 'w-7 h-7' : 'w-10 h-10'} ${className}`} />;
};
