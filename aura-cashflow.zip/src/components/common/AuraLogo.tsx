/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Official Brand Logo & Mark Components
 */

import React from 'react';

interface AuraLogoProps {
  variant?: 'full' | 'mark-only' | 'compact' | 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  className?: string;
}

export const AuraIconMark: React.FC<{ size?: number; className?: string }> = ({
  size = 36,
  className = '',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-label="Aura Cashflow Emblem"
    >
      <defs>
        <linearGradient id="auraGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F5D77F" />
          <stop offset="35%" stopColor="#D4AF37" />
          <stop offset="70%" stopColor="#AA7C11" />
          <stop offset="100%" stopColor="#E5C158" />
        </linearGradient>
        <linearGradient id="auraWaveGrad" x1="20%" y1="10%" x2="80%" y2="90%">
          <stop offset="0%" stopColor="#FFF2B2" />
          <stop offset="50%" stopColor="#D4AF37" />
          <stop offset="100%" stopColor="#8C650A" />
        </linearGradient>
        <filter id="auraGlow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000000" floodOpacity="0.25" />
        </filter>
      </defs>

      {/* Outer circular gold ring border */}
      <circle
        cx="50"
        cy="50"
        r="44"
        stroke="url(#auraGoldGrad)"
        strokeWidth="4.5"
        fill="none"
        filter="url(#auraGlow)"
      />

      {/* Inner circular subtle accent track */}
      <circle
        cx="50"
        cy="50"
        r="39"
        stroke="url(#auraGoldGrad)"
        strokeWidth="1"
        strokeOpacity="0.4"
        fill="none"
      />

      {/* Fluid Dynamic 'A' Wave Ribbon */}
      <path
        d="M28 66 C32 50, 42 32, 50 26 C58 32, 68 50, 72 66 C65 62, 58 56, 50 56 C42 56, 35 62, 28 66 Z"
        fill="url(#auraWaveGrad)"
      />

      {/* Sine wave crossbar accent */}
      <path
        d="M27 60 C38 52, 62 52, 73 60 C64 66, 36 66, 27 60 Z"
        fill="url(#auraGoldGrad)"
        opacity="0.85"
      />

      {/* Center apex shine dot */}
      <circle cx="50" cy="33" r="2.5" fill="#FFFBE6" />
    </svg>
  );
};

export const AuraLogo: React.FC<AuraLogoProps> = ({
  variant = 'full',
  size = 'md',
  showTagline = true,
  className = '',
}) => {
  const iconSizes = {
    sm: 28,
    md: 36,
    lg: 46,
    xl: 56,
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-base sm:text-lg',
    lg: 'text-xl sm:text-2xl',
    xl: 'text-2xl sm:text-3xl',
  };

  const taglineSizes = {
    sm: 'text-[8px] tracking-[0.2em]',
    md: 'text-[9px] sm:text-[10px] tracking-[0.22em]',
    lg: 'text-[11px] tracking-[0.25em]',
    xl: 'text-xs tracking-[0.28em]',
  };

  const isLightMode = variant === 'light';

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <AuraIconMark size={iconSizes[size]} />

      {variant !== 'mark-only' && (
        <div className="flex flex-col justify-center">
          <div className="flex items-center gap-2">
            <span
              className={`font-serif font-bold tracking-wider uppercase ${titleSizes[size]} ${
                isLightMode ? 'text-slate-900' : 'text-amber-50'
              }`}
              style={{ letterSpacing: '0.08em' }}
            >
              Aura <span className="font-light text-amber-400">Cashflow</span>
            </span>
          </div>

          {showTagline && (
            <span
              className={`font-sans font-semibold uppercase text-amber-300/80 ${taglineSizes[size]} mt-0.5`}
            >
              Model Today. Live Tomorrow.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
