/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Privacy & Data Storage Modal & Currency Input Utility
 */

import React, { useEffect } from 'react';
import { ShieldCheck, Lock, HardDrive, Download, Upload, RefreshCw, X } from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';

export const PrivacyModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { exportProfileJson, importProfileJson, resetToDefault } = useCashflow();
  const [importText, setImportText] = React.useState('');
  const [importStatus, setImportStatus] = React.useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (isOpen) {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleDownloadBackup = () => {
    const json = exportProfileJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aura_Cashflow_Backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = () => {
    if (!importText.trim()) return;
    const success = importProfileJson(importText);
    if (success) {
      setImportStatus('success');
      setTimeout(() => {
        onClose();
        setImportStatus('idle');
        setImportText('');
      }, 1200);
    } else {
      setImportStatus('error');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-dialog-title"
    >
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 md:p-8 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 id="privacy-dialog-title" className="text-xl font-semibold text-slate-900">
                Privacy & Data Ownership
              </h3>
              <p className="text-sm text-slate-500">Your sensitive financial model stays strictly in your browser</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Close privacy dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-6 space-y-4 text-sm text-slate-600 leading-relaxed">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-3.5">
            <Lock className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block mb-0.5">100% Client-Side Local Storage</strong>
              All incomes, pensions, property values, and mortgage details entered into Aura Cashflow are saved locally in your device's browser cache (<code className="text-xs bg-slate-200 px-1 py-0.5 rounded">localStorage</code>). No financial figures or personal identifiers are transmitted to external servers.
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-3.5">
            <HardDrive className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block mb-0.5">Device Persistence & Cache Clearing</strong>
              If you clear your browser cookies and site data, or use a private/incognito browsing window, your plan data will be reset. We recommend creating an encrypted JSON backup below before clearing history.
            </div>
          </div>
        </div>

        {/* Export / Import Section */}
        <div className="mt-8 border-t border-slate-200 pt-6 space-y-4">
          <h4 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <Download className="w-4 h-4 text-emerald-700" /> Backup & Data Portability
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleDownloadBackup}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-emerald-900 hover:bg-emerald-950 text-white rounded-xl font-medium transition-colors text-sm shadow-xs"
            >
              <Download className="w-4 h-4" /> Download Plan Backup (.JSON)
            </button>

            <button
              onClick={() => {
                if (window.confirm('Reset all financial figures to standard baseline template?')) {
                  resetToDefault();
                  onClose();
                }
              }}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium transition-colors text-sm border border-slate-200"
            >
              <RefreshCw className="w-4 h-4 text-slate-500" /> Reset to Blank / Default Plan
            </button>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100">
            <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-slate-500" /> Restore / Import Plan JSON:
            </label>
            <textarea
              rows={3}
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="Paste previously exported Aura Cashflow JSON backup here..."
              className="w-full text-xs font-mono p-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 text-slate-700"
            />
            {importStatus === 'success' && (
              <p className="text-xs text-emerald-700 font-medium mt-1">✓ Plan restored successfully!</p>
            )}
            {importStatus === 'error' && (
              <p className="text-xs text-red-600 font-medium mt-1">✕ Invalid plan JSON format. Please check and retry.</p>
            )}
            {importText.trim().length > 0 && (
              <button
                onClick={handleImportSubmit}
                className="mt-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-medium rounded-lg transition-colors"
              >
                Apply Imported Plan
              </button>
            )}
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-medium text-sm transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

export const PersonaSelector: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { loadPresetProfile } = useCashflow();

  useEffect(() => {
    if (isOpen) {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSelect = (id: string) => {
    loadPresetProfile(id);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="persona-dialog-title"
    >
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 md:p-8 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 id="persona-dialog-title" className="text-xl font-semibold text-slate-900">
              Load Client Case Study
            </h3>
            <p className="text-sm text-slate-500 mt-1">Select a realistic UK household scenario to test the modeller</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Close client case study selector"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4">
          <button
            onClick={() => handleSelect('mid-career-professional')}
            className="p-5 text-left rounded-2xl border border-slate-200 hover:border-emerald-700 hover:bg-emerald-50/40 transition-all group"
          >
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-semibold text-slate-900 group-hover:text-emerald-950">
                Eleanor & David (Mid-Career Family)
              </h4>
              <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-medium">
                Age 44 & 42 · Target 60
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Employed professional in Bristol with £85k gross salary, workplace pension with 8% employer match, home with £195k mortgage, ISA portfolio, and two children.
            </p>
          </button>

          <button
            onClick={() => handleSelect('approaching-retirement')}
            className="p-5 text-left rounded-2xl border border-slate-200 hover:border-emerald-700 hover:bg-emerald-50/40 transition-all group"
          >
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-semibold text-slate-900 group-hover:text-emerald-950">
                Robert & Fiona (Approaching Retirement)
              </h4>
              <span className="text-xs px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 font-medium">
                Age 58 & 57 · Target 60
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Imminent retirement in Harrogate. Strong DC pots (£800k combined), mortgage paid off, high tax-efficiency questions on pension drawdown sequencing and April 2027 IHT planning.
            </p>
          </button>

          <button
            onClick={() => handleSelect('young-accumulator')}
            className="p-5 text-left rounded-2xl border border-slate-200 hover:border-emerald-700 hover:bg-emerald-50/40 transition-all group"
          >
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-semibold text-slate-900 group-hover:text-emerald-950">
                Marcus (Young Wealth Accumulator / Scottish Taxpayer)
              </h4>
              <span className="text-xs px-2.5 py-1 rounded-full bg-purple-100 text-purple-800 font-medium">
                Age 32 · FIRE Target 55
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Tech worker in Edinburgh aiming for Financial Independence (FIRE) at age 55, navigating Scottish tax brackets, aggressive salary sacrifice, and maximum ISA allowances.
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};

export const CurrencyInput: React.FC<{
  id?: string;
  label: string;
  value: number | '' | undefined;
  onChange: (val: number | '') => void;
  prefix?: string;
  suffix?: string;
  helperText?: string;
  placeholder?: string;
  step?: number;
  min?: number;
  max?: number;
  disabled?: boolean;
  required?: boolean;
}> = ({
  id,
  label,
  value,
  onChange,
  prefix = '£',
  suffix,
  helperText,
  placeholder,
  step = 100,
  min = 0,
  max,
  disabled = false,
  required = false,
}) => {
  const inputId = id || `input-${label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

  return (
    <div className={disabled ? 'opacity-60 select-none' : ''}>
      <label htmlFor={inputId} className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className="relative rounded-xl shadow-2xs">
        {prefix && (
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
            <span className={`font-medium sm:text-sm ${disabled ? 'text-slate-300' : 'text-slate-400'}`}>{prefix}</span>
          </div>
        )}
        <input
          type="number"
          id={inputId}
          disabled={disabled}
          placeholder={placeholder}
          value={value === '' || value === undefined || isNaN(value as number) ? '' : value}
          onChange={(e) => {
            if (e.target.value === '') {
              onChange('');
            } else {
              const parsed = parseFloat(e.target.value);
              onChange(isNaN(parsed) ? '' : parsed);
            }
          }}
          min={min}
          max={max}
          step={step}
          className={`block w-full rounded-xl border text-sm font-medium transition-all ${
            disabled
              ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
              : 'bg-white border-slate-200 text-slate-900 focus:border-emerald-700 focus:ring-2 focus:ring-emerald-700/20 focus:outline-none'
          } ${prefix ? 'pl-8' : 'pl-3.5'} ${suffix ? 'pr-8' : 'pr-3.5'}`}
        />
        {suffix && (
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3.5">
            <span className={`font-medium sm:text-sm ${disabled ? 'text-slate-300' : 'text-slate-400'}`}>{suffix}</span>
          </div>
        )}
      </div>
      {helperText && <p className="mt-1 text-xs text-slate-500">{helperText}</p>}
    </div>
  );
};
