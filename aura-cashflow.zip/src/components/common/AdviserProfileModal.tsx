/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — IFA & Advisory Practice Profile Modal
 * Configures the adviser details, company contact information, and presentation headers
 * displayed on the top navigation bar and all printed Client Reports.
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  UserCheck,
  Building2,
  Mail,
  Phone,
  Globe,
  MapPin,
  FileText,
  RotateCcw,
  Check,
  ShieldCheck,
  Sparkles,
  Info,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { AdviserPracticeDetails, DEFAULT_ADVISER_DETAILS } from '../../types/cashflow';

interface AdviserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdviserProfileModal: React.FC<AdviserProfileModalProps> = ({ isOpen, onClose }) => {
  const { adviserDetails, updateAdviserDetails, resetAdviserDetails } = useCashflow();

  const [formData, setFormData] = useState<AdviserPracticeDetails>(adviserDetails);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFormData(adviserDetails);
      setSavedSuccess(false);
    }
  }, [isOpen, adviserDetails]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdviserDetails(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  const handleReset = () => {
    resetAdviserDetails();
    setFormData(DEFAULT_ADVISER_DETAILS);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 1200);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="adviser-modal-title"
    >
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header with Aura Cashflow brand styling */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 px-6 py-5 text-white flex items-center justify-between border-b border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-inner">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 id="adviser-modal-title" className="text-lg font-serif font-bold text-white tracking-tight">
                Adviser & Practice Profile
              </h2>
              <p className="text-xs text-emerald-200/80">
                Customise IFA contact details and header branding for reports
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Regulatory & Unregulated Clarification Notice */}
        <div className="bg-emerald-50/70 border-b border-emerald-100 px-6 py-3 flex items-start gap-2.5 text-xs text-emerald-950">
          <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold text-emerald-900">Aura Cashflow Modelling Engine: </span>
            Cashflow forecasting is an analytical planning tool illustrating potential wealth trajectories. 
            Because cashflow illustration is not a regulated activity, no FCA firm number is required.
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[calc(85vh-160px)] overflow-y-auto">
          {/* Section 1: Adviser Identity */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
              Lead Adviser Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Adviser Name & Post-nominals
                </label>
                <input
                  type="text"
                  value={formData.adviserName}
                  onChange={(e) => setFormData({ ...formData, adviserName: e.target.value })}
                  placeholder="e.g. James Sterling, FPFS"
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Professional Title / Role
                </label>
                <input
                  type="text"
                  value={formData.adviserTitle}
                  onChange={(e) => setFormData({ ...formData, adviserTitle: e.target.value })}
                  placeholder="e.g. Chartered Financial Planner"
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Firm & Practice Details */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-emerald-700" />
              Firm & Practice Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Company / Firm Name
                </label>
                <input
                  type="text"
                  value={formData.firmName}
                  onChange={(e) => setFormData({ ...formData, firmName: e.target.value })}
                  placeholder="e.g. Aura Wealth Advisory"
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Firm Tagline / Proposition
                </label>
                <input
                  type="text"
                  value={formData.firmTagline}
                  onChange={(e) => setFormData({ ...formData, firmTagline: e.target.value })}
                  placeholder="e.g. Precision UK Cashflow Modelling"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Contact Details */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-emerald-700" />
              Contact Information (Displayed in Reports & Header)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-slate-400" /> Email Address
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="adviser@firm.co.uk"
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" /> Telephone
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+44 (0)20 7946 0192"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Globe className="w-3 h-3 text-slate-400" /> Website
                </label>
                <input
                  type="text"
                  value={formData.website}
                  onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                  placeholder="www.auracashflow.co.uk"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" /> Office / Registered Address
              </label>
              <input
                type="text"
                value={formData.officeAddress}
                onChange={(e) => setFormData({ ...formData, officeAddress: e.target.value })}
                placeholder="125 Old Broad Street, London, EC2N 1AR"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all"
              />
            </div>
          </div>

          {/* Section 4: Adviser Notes & Preface */}
          <div className="space-y-2 pt-3 border-t border-slate-100">
            <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-emerald-700" />
              Advisory Preface / Client Notes (Appears on Cover of Client Reports)
            </label>
            <textarea
              rows={2}
              value={formData.adviserNotes || ''}
              onChange={(e) => setFormData({ ...formData, adviserNotes: e.target.value })}
              placeholder="e.g. This cashflow forecast illustrates the viability of retirement at age 60 under current tax rules and agreed investment growth parameters."
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:border-transparent transition-all resize-none"
            />
          </div>

          {/* Live Preview Card */}
          <div className="pt-2">
            <div className="p-4 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-md">
              <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3" /> Live Header & Report Card Preview
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="font-serif font-bold text-sm text-white">
                    {formData.adviserName || 'Adviser Name'}
                  </div>
                  <div className="text-xs text-slate-300">
                    {formData.adviserTitle} · <span className="text-emerald-300 font-semibold">{formData.firmName}</span>
                  </div>
                </div>
                <div className="text-right text-[11px] text-slate-400 space-y-0.5">
                  <div>{formData.email}</div>
                  <div>{formData.phone}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset to Aura Default
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-md transition-all cursor-pointer"
              >
                {savedSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-200" />
                    Saved Successfully!
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-200" />
                    Save & Update Header
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
