/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Reusable UK Ownership & Legal Attribution Selector
 */

import React from 'react';
import { User, Users, ShieldAlert, Info } from 'lucide-react';
import { OwnershipType, IndividualOwner } from '../../types/cashflow';

interface OwnershipSelectorProps {
  owner: OwnershipType;
  onChangeOwner: (owner: OwnershipType) => void;
  supportsJoint?: boolean;
  jointSplitPercent?: number; // Primary % (0-100)
  onChangeJointSplit?: (percent: number) => void;
  primaryName?: string;
  partnerName?: string;
  hasPartner: boolean;
  itemTypeLabel?: string; // e.g. "pension", "ISA", "GIA", "property"
}

export const OwnershipSelector: React.FC<OwnershipSelectorProps> = ({
  owner,
  onChangeOwner,
  supportsJoint = true,
  jointSplitPercent = 50,
  onChangeJointSplit,
  primaryName = 'Primary Client',
  partnerName = 'Partner',
  hasPartner,
  itemTypeLabel,
}) => {
  if (!hasPartner) {
    return null;
  }

  const effectivePrimaryName = primaryName.trim() || 'Primary';
  const effectivePartnerName = partnerName.trim() || 'Partner';

  return (
    <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200/80 space-y-2.5">
      <div className="flex items-center justify-between gap-2">
        <label className="text-[11px] font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
          <User className="w-3.5 h-3.5 text-emerald-800" /> Account & Tax Attribution
        </label>
        {!supportsJoint && (
          <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
            <Info className="w-3 h-3 text-slate-400" /> Strictly individual under UK law
          </span>
        )}
      </div>

      {/* Segmented Control */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <button
          type="button"
          onClick={() => onChangeOwner('primary')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            owner === 'primary'
              ? 'bg-emerald-900 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span className="truncate">{effectivePrimaryName}</span>
        </button>

        <button
          type="button"
          onClick={() => onChangeOwner('partner')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            owner === 'partner'
              ? 'bg-emerald-900 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span className="truncate">{effectivePartnerName}</span>
        </button>

        {supportsJoint && (
          <button
            type="button"
            onClick={() => onChangeOwner('joint')}
            className={`col-span-2 sm:col-span-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
              owner === 'joint'
                ? 'bg-emerald-900 text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Joint Ownership</span>
          </button>
        )}
      </div>

      {/* Joint Split Slider & Input */}
      {supportsJoint && owner === 'joint' && onChangeJointSplit && (
        <div className="pt-2 border-t border-slate-200/60 space-y-2">
          <div className="flex items-center justify-between text-xs font-medium text-slate-700">
            <span>
              {effectivePrimaryName}: <strong className="text-emerald-900 font-bold">{jointSplitPercent}%</strong>
            </span>
            <span>
              {effectivePartnerName}: <strong className="text-emerald-900 font-bold">{100 - jointSplitPercent}%</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={jointSplitPercent}
              onChange={(e) => onChangeJointSplit(parseInt(e.target.value, 10) || 50)}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-800"
            />
            <div className="flex gap-1 shrink-0">
              <button
                type="button"
                onClick={() => onChangeJointSplit(50)}
                className={`px-2 py-0.5 text-[11px] rounded-md border font-medium ${
                  jointSplitPercent === 50
                    ? 'bg-emerald-100 border-emerald-300 text-emerald-900 font-bold'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                50 / 50
              </button>
              <button
                type="button"
                onClick={() => onChangeJointSplit(100)}
                className={`px-2 py-0.5 text-[11px] rounded-md border font-medium ${
                  jointSplitPercent === 100
                    ? 'bg-emerald-100 border-emerald-300 text-emerald-900 font-bold'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                100% {effectivePrimaryName}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
