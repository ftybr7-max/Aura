/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Overwrite Confirmation & Navigation Safety Modal
 * Protects active client planning sessions from accidental data loss during preset loading or JSON imports.
 */

import React from 'react';
import { AlertTriangle, Download, RefreshCw, X, ArrowRight } from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';

interface OverwriteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  targetActionTitle: string;
  targetActionDescription?: string;
}

export const OverwriteConfirmModal: React.FC<OverwriteConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  targetActionTitle,
  targetActionDescription,
}) => {
  const { profile, exportProfileJson } = useCashflow();

  if (!isOpen) return null;

  const clientName = profile.personal.fullName || 'Current Client';
  const hasPartner = profile.personal.hasPartner && profile.personal.partnerName;

  const handleDownloadBackup = () => {
    const json = exportProfileJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeName = (profile.personal.fullName || 'Client').replace(/\s+/g, '_');
    a.download = `Aura_Cashflow_Backup_${safeName}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-labelledby="overwrite-modal-title"
    >
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in zoom-in-95 duration-150">
        {/* Warning Header */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 px-6 py-4 text-white flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white border border-white/30 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 id="overwrite-modal-title" className="text-base font-bold text-white tracking-tight">
                Overwrite Active Client Plan?
              </h2>
              <p className="text-xs text-amber-100 font-medium">
                Active session data detected
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-full hover:bg-white/20 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 text-slate-700">
          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs leading-relaxed text-amber-950">
            <p className="font-semibold text-amber-900 mb-1">
              You are about to load: <span className="underline">{targetActionTitle}</span>
            </p>
            {targetActionDescription && (
              <p className="text-amber-800 text-[11px] mb-2">{targetActionDescription}</p>
            )}
            <p>
              This will replace all financial details, pensions, properties, tax wrappers, and cashflow projections currently entered for{' '}
              <strong>{clientName}{hasPartner ? ` & ${profile.personal.partnerName}` : ''}</strong>.
            </p>
          </div>

          <p className="text-xs text-slate-500">
            We recommend exporting a JSON backup before proceeding so you can restore this client file at any time.
          </p>

          {/* Download Backup Button */}
          <button
            type="button"
            onClick={handleDownloadBackup}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all border border-slate-200 cursor-pointer shadow-2xs"
          >
            <Download className="w-4 h-4 text-slate-600" />
            Download {clientName} Backup (.JSON) First
          </button>

          {/* Action Footer */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel & Keep Active Plan
            </button>
            <button
              type="button"
              onClick={() => {
                onConfirm();
                onClose();
              }}
              className="flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-md transition-all cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Confirm & Overwrite Plan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
