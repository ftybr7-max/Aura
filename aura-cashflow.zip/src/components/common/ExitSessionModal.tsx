/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Exit Session & Hub Return Modal
 * Provides safe session navigation with prompt for JSON backups.
 */

import React from 'react';
import { Home, Download, ArrowRight, X, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';

interface ExitSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmExit: () => void;
}

export const ExitSessionModal: React.FC<ExitSessionModalProps> = ({
  isOpen,
  onClose,
  onConfirmExit,
}) => {
  const { profile, exportProfileJson } = useCashflow();

  if (!isOpen) return null;

  const clientName = profile.personal.fullName || 'Current Client';
  const hasPartner = profile.personal.hasPartner && profile.personal.partnerName;

  const handleDownloadAndExit = () => {
    const json = exportProfileJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeName = (profile.personal.fullName || 'Client').replace(/\s+/g, '_');
    a.download = `Aura_Cashflow_${safeName}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // After brief delay, confirm exit
    setTimeout(() => {
      onConfirmExit();
      onClose();
    }, 400);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-labelledby="exit-session-title"
    >
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <h2 id="exit-session-title" className="text-base font-bold text-white tracking-tight">
                Return to Welcome Hub?
              </h2>
              <p className="text-xs text-slate-400">
                Active Client Plan: <span className="text-emerald-300 font-medium">{clientName}{hasPartner ? ` & ${profile.personal.partnerName}` : ''}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-slate-700">
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-emerald-950">
              <p className="font-semibold text-emerald-900 mb-0.5">
                Auto-Saved in Browser Cache
              </p>
              Your current plan calculations and inputs remain stored in this browser session. You can re-open it at any time from the Hub.
            </div>
          </div>

          <p className="text-xs text-slate-600">
            For long-term records or client archiving, you can also download a portable JSON backup file now.
          </p>

          <div className="space-y-2 pt-2">
            <button
              type="button"
              onClick={handleDownloadAndExit}
              className="w-full flex items-center justify-between px-4 py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer group"
            >
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-emerald-200 group-hover:animate-bounce" />
                <span>Save JSON Backup & Return to Hub</span>
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-200" />
            </button>

            <button
              type="button"
              onClick={() => {
                onConfirmExit();
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-all border border-slate-200 cursor-pointer"
            >
              <Home className="w-4 h-4 text-slate-600" />
              Return to Hub (Keep Local Browser Cache)
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Continue In-Session Planning
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
