/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Navigation Header & Mode Controls
 * Features authentic Aura Cashflow golden wave branding, dedicated client identity row,
 * responsive Office button for tablet & mobile, and safe session exit controls.
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  BarChart3,
  SlidersHorizontal,
  Coins,
  FlaskConical,
  TrendingUp,
  FileText,
  BookOpen,
  Lock,
  Menu,
  X,
  FileCheck,
  Building2,
  UserCheck,
  Home,
  User,
  Users,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { PrivacyModal } from '../common/PrivacyModal';
import { AdviserProfileModal } from '../common/AdviserProfileModal';
import { ExitSessionModal } from '../common/ExitSessionModal';
import { AuraBrandLogo } from '../common/AuraBrandLogo';

interface HeaderProps {
  onExitSession: () => void;
  onOpenPrivacy?: () => void;
  onOpenPersonas?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onExitSession,
  onOpenPrivacy,
}) => {
  const {
    profile,
    adviserDetails,
    activeTab,
    setActiveTab,
    reportMode,
    setReportMode,
    isRealTerms,
    setIsRealTerms,
  } = useCashflow();

  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isAdviserOpen, setIsAdviserOpen] = useState(false);
  const [isExitModalOpen, setIsExitModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const tabButtonRefs = useRef<{ [key: string]: HTMLButtonElement | null }>({});

  const navItems = [
    {
      id: 'modeller',
      label: 'Cashflow Modeller',
      icon: BarChart3,
      accentColor: 'text-emerald-400',
      activeBg: 'from-emerald-700 to-teal-800 border-emerald-400/60 shadow-emerald-950/60',
    },
    {
      id: 'profile',
      label: 'Financial Profile',
      icon: SlidersHorizontal,
      accentColor: 'text-teal-400',
      activeBg: 'from-teal-700 to-cyan-800 border-teal-400/60 shadow-teal-950/60',
    },
    {
      id: 'drawdown',
      label: 'Tax & Drawdown',
      icon: Coins,
      accentColor: 'text-amber-400',
      activeBg: 'from-amber-700 to-emerald-800 border-amber-400/60 shadow-amber-950/60',
    },
    {
      id: 'whatif',
      label: 'What-If Lab',
      icon: FlaskConical,
      accentColor: 'text-sky-400',
      activeBg: 'from-sky-700 to-indigo-800 border-sky-400/60 shadow-sky-950/60',
    },
    {
      id: 'montecarlo',
      label: 'Monte Carlo (1,000 Trials)',
      icon: TrendingUp,
      accentColor: 'text-purple-400',
      activeBg: 'from-purple-700 to-indigo-800 border-purple-400/60 shadow-purple-950/60',
    },
    {
      id: 'rules',
      label: 'UK Rules Audit',
      icon: BookOpen,
      accentColor: 'text-rose-400',
      activeBg: 'from-rose-700 to-slate-800 border-rose-400/60 shadow-rose-950/60',
    },
  ] as const;

  // Smoothly center active tab on change
  useEffect(() => {
    const activeEl = tabButtonRefs.current[activeTab];
    if (activeEl && scrollContainerRef.current) {
      activeEl.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
    }
  }, [activeTab]);

  const handleOpenPrivacy = () => {
    if (onOpenPrivacy) onOpenPrivacy();
    else setIsPrivacyOpen(true);
  };

  const clientPrimaryName = profile.personal.fullName || 'Client';
  const hasPartner = profile.personal.hasPartner && profile.personal.partnerName;
  const clientDisplayName = hasPartner
    ? `${clientPrimaryName} (${profile.personal.currentAge}) & ${profile.personal.partnerName} (${profile.personal.partnerAge || profile.personal.currentAge})`
    : `${clientPrimaryName} (Age ${profile.personal.currentAge})`;

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#071124] border-b border-slate-800 text-white shadow-xl">
        {/* Top Branding & Client Metadata Bar (Zero Overlap Layout) */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="py-2.5 sm:py-3 flex flex-col gap-2.5">
            {/* Top Row: Brand & Hub Exit (Left) + Client Pill (Center/Left) + Controls & Office (Right) */}
            <div className="flex items-center justify-between gap-3 min-w-0 flex-wrap lg:flex-nowrap">
              {/* Left Group: Home Hub Exit + Official Aura Brand */}
              <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
                {/* Home / Exit Session Button */}
                <button
                  type="button"
                  onClick={() => setIsExitModalOpen(true)}
                  className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-slate-700/90 text-xs font-bold transition-all shadow-xs cursor-pointer group"
                  title="Return to Welcome Hub (with unsaved changes check)"
                >
                  <Home className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span className="hidden sm:inline">Hub</span>
                </button>

                {/* Aura Cashflow Official Logo & Golden Emblem */}
                <AuraBrandLogo variant="compact-header" showTagline={true} />
              </div>

              {/* Center Group: Client Demographics & Horizon Identity Badge */}
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700/80 shadow-inner max-w-full sm:max-w-md lg:max-w-none shrink min-w-0">
                <div className="w-6 h-6 rounded-lg bg-emerald-950 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  {hasPartner ? (
                    <Users className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-bold text-white tracking-tight truncate">
                      {clientDisplayName}
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/60 shrink-0">
                      {profile.personal.taxRegion === 'scotland' ? 'Scotland' : 'rUK 2026/27'}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-300/80 truncate">
                    Retire: Age {profile.personal.targetRetirementAge}
                    {hasPartner && ` / ${profile.personal.partnerTargetRetirementAge || profile.personal.targetRetirementAge}`}
                    {' '}· Horizon: {profile.personal.planningHorizonAge || 95}
                  </div>
                </div>
              </div>

              {/* Right Group: Office Button (Mobile/Tablet/Desktop), Real/Nominal, Reports, Privacy */}
              <div className="flex items-center gap-2 sm:gap-2.5 shrink-0 ml-auto lg:ml-0">
                {/* Office / Adviser Practice Button (Clean on Mobile, Tablet & Desktop) */}
                <button
                  type="button"
                  onClick={() => setIsAdviserOpen(true)}
                  className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700/90 text-xs font-semibold text-slate-200 hover:text-white transition-all cursor-pointer group shrink-0"
                  title={`Adviser Profile & Practice: ${adviserDetails.adviserName || 'Adviser'} (${adviserDetails.firmName || 'Practice'})`}
                >
                  <Building2 className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform shrink-0" />
                  <span className="text-xs font-bold">Office</span>
                  <span className="hidden xl:inline text-[11px] text-slate-400 font-normal truncate max-w-[110px]">
                    · {adviserDetails.firmName || 'Practice'}
                  </span>
                </button>

                {/* Real vs Nominal Toggle */}
                <div
                  className="flex items-center bg-slate-800/95 rounded-xl p-0.5 border border-slate-700/80 shadow-xs shrink-0"
                  role="group"
                  aria-label="Measurement terms"
                >
                  <button
                    type="button"
                    onClick={() => setIsRealTerms(true)}
                    className={`px-2 sm:px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                      isRealTerms
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title="Real Terms (adjusted for inflation, today's £)"
                  >
                    Real <span className="hidden xl:inline">(Today's £)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsRealTerms(false)}
                    className={`px-2 sm:px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                      !isRealTerms
                        ? 'bg-amber-700 text-white shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title="Nominal Terms (future inflated £)"
                  >
                    Nominal
                  </button>
                </div>

                {/* Client Report Selector */}
                <div
                  className={`flex items-center rounded-xl p-0.5 border transition-all shrink-0 ${
                    activeTab === 'report'
                      ? 'bg-gradient-to-r from-blue-900/90 to-indigo-900/90 border-blue-400 shadow-md ring-2 ring-blue-400/30'
                      : 'bg-slate-800/95 hover:bg-slate-800 border-slate-700/80 shadow-xs'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setActiveTab('report')}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === 'report' ? 'text-white' : 'text-slate-200 hover:text-white'
                    }`}
                    title="Generate Client Financial Report"
                  >
                    <FileText className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'report' ? 'text-blue-300' : 'text-blue-400'}`} />
                    <span className="hidden sm:inline">Report</span>
                  </button>

                  <div className="flex items-center pl-1 border-l border-slate-700/70 gap-0.5 pr-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setReportMode('full');
                        setActiveTab('report');
                      }}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                        activeTab === 'report' && reportMode === 'full'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Full
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setReportMode('summary');
                        setActiveTab('report');
                      }}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                        activeTab === 'report' && reportMode === 'summary'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Sum
                    </button>
                  </div>
                </div>

                {/* Privacy & Backup Button */}
                <button
                  type="button"
                  onClick={handleOpenPrivacy}
                  className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-slate-800/95 hover:bg-slate-700 text-slate-200 border border-slate-700/80 transition-colors cursor-pointer shrink-0"
                  title="Local storage and JSON backup options"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="hidden md:inline">Backup</span>
                </button>

                {/* Mobile Menu Button */}
                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="p-1.5 text-slate-300 hover:text-white rounded-xl bg-slate-800 border border-slate-700 sm:hidden shrink-0"
                  aria-label="Toggle mobile menu"
                >
                  {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* DISTINCTIVE TAB NAVIGATION BAR (CLEAN HORIZONTAL SCROLL & REMOVED CASE STUDIES) */}
        <nav
          aria-label="Main application sections"
          className="relative bg-slate-950/95 border-t border-slate-800/90 shadow-inner overflow-hidden"
        >
          <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
            <div
              ref={scrollContainerRef}
              className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto py-2 sm:py-2.5 scrollbar-none touch-pan-x"
            >
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    ref={(el) => (tabButtonRefs.current[item.id] = el)}
                    onClick={() => setActiveTab(item.id)}
                    className={`group relative flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 cursor-pointer shrink-0 ${
                      isActive
                        ? `bg-gradient-to-r ${item.activeBg} text-white border shadow-md ring-2 ring-emerald-400/25`
                        : 'bg-slate-900/95 hover:bg-slate-800/95 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse shadow-sm shadow-emerald-400 shrink-0" />
                    )}

                    <Icon
                      className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                        isActive ? 'text-white drop-shadow-sm' : item.accentColor
                      }`}
                    />

                    <span className="tracking-tight whitespace-nowrap">{item.label}</span>

                    {isActive && (
                      <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-emerald-400/90 rounded-full shadow-xs shadow-emerald-300" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Mobile Drawer */}
        {isMobileMenuOpen && (
          <div className="sm:hidden bg-slate-900 border-t border-slate-800 px-4 pt-3 pb-4 space-y-2 animate-in slide-in-from-top-2">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 px-1">
              Client Reports & Privacy
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setReportMode('full');
                  setActiveTab('report');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 text-xs font-semibold bg-blue-900/80 text-blue-100 rounded-xl border border-blue-700 hover:bg-blue-800"
              >
                <FileCheck className="w-4 h-4 text-blue-300" />
                Full Client Report
              </button>
              <button
                type="button"
                onClick={() => {
                  setReportMode('summary');
                  setActiveTab('report');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 text-xs font-semibold bg-blue-900/80 text-blue-100 rounded-xl border border-blue-700 hover:bg-blue-800"
              >
                <FileText className="w-4 h-4 text-blue-300" />
                Summary Report
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsAdviserOpen(true);
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 text-xs font-semibold bg-emerald-950/80 text-emerald-200 rounded-xl border border-emerald-800"
              >
                <Building2 className="w-4 h-4 text-emerald-400" />
                Office Profile
              </button>

              <button
                type="button"
                onClick={() => {
                  handleOpenPrivacy();
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 text-xs font-semibold bg-slate-800 text-slate-200 rounded-xl border border-slate-700"
              >
                <Lock className="w-4 h-4 text-emerald-400" />
                JSON Backup
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setIsExitModalOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 text-xs font-bold bg-amber-950 text-amber-200 rounded-xl border border-amber-800 mt-2"
            >
              <Home className="w-4 h-4 text-amber-400" />
              Return to Welcome Hub
            </button>
          </div>
        )}
      </header>

      {/* Modals */}
      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />

      <AdviserProfileModal
        isOpen={isAdviserOpen}
        onClose={() => setIsAdviserOpen(false)}
      />

      <ExitSessionModal
        isOpen={isExitModalOpen}
        onClose={() => setIsExitModalOpen(false)}
        onConfirmExit={onExitSession}
      />
    </>
  );
};
