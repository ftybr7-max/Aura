/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Master Cashflow & Retirement Modeller Dashboard
 */

import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  AreaChart,
  Area,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Coins,
  Home,
  ShieldAlert,
  ArrowUpRight,
  Download,
  Calendar,
  Layers,
  HelpCircle,
  Eye,
  EyeOff,
  RotateCcw,
  Check,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';

export const ModellerDashboard: React.FC = () => {
  const { profile, simulationResult, isRealTerms, setActiveTab } = useCashflow();
  const [chartView, setChartView] = useState<'cashflow' | 'assets'>('cashflow');
  const [tableFilter, setTableFilter] = useState<'all' | 'retirement' | 'decade'>('all');

  // Interactive Asset Class Layer Visibility
  const [visibleAssets, setVisibleAssets] = useState<{
    pensionPot: boolean;
    isaBalance: boolean;
    giaBalance: boolean;
    cashBalance: boolean;
    propertyEquity: boolean;
    totalNetWorth: boolean;
  }>({
    pensionPot: true,
    isaBalance: true,
    giaBalance: true,
    cashBalance: true,
    propertyEquity: true,
    totalNetWorth: true,
  });

  // Interactive Cashflow Inflows/Outflows Visibility
  const [visibleCashflows, setVisibleCashflows] = useState<{
    employment: boolean;
    dbPension: boolean;
    statePension: boolean;
    drawdownTaxFree: boolean;
    drawdownTaxable: boolean;
    drawdownIsa: boolean;
    drawdownCash: boolean;
    totalOutflows: boolean;
  }>({
    employment: true,
    dbPension: true,
    statePension: true,
    drawdownTaxFree: true,
    drawdownTaxable: true,
    drawdownIsa: true,
    drawdownCash: true,
    totalOutflows: true,
  });

  const toggleAssetKey = (key: keyof typeof visibleAssets) => {
    setVisibleAssets((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const toggleCashflowKey = (key: keyof typeof visibleCashflows) => {
    setVisibleCashflows((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Asset Presets
  const setAllAssets = () => {
    setVisibleAssets({
      pensionPot: true,
      isaBalance: true,
      giaBalance: true,
      cashBalance: true,
      propertyEquity: true,
      totalNetWorth: true,
    });
  };

  const setLiquidOnly = () => {
    setVisibleAssets({
      pensionPot: true,
      isaBalance: true,
      giaBalance: true,
      cashBalance: true,
      propertyEquity: false,
      totalNetWorth: true,
    });
  };

  const setPensionsAndIsasOnly = () => {
    setVisibleAssets({
      pensionPot: true,
      isaBalance: true,
      giaBalance: false,
      cashBalance: false,
      propertyEquity: false,
      totalNetWorth: true,
    });
  };

  const isAllAssetsSelected =
    visibleAssets.pensionPot &&
    visibleAssets.isaBalance &&
    visibleAssets.giaBalance &&
    visibleAssets.cashBalance &&
    visibleAssets.propertyEquity;

  const isLiquidOnlySelected =
    visibleAssets.pensionPot &&
    visibleAssets.isaBalance &&
    visibleAssets.giaBalance &&
    visibleAssets.cashBalance &&
    !visibleAssets.propertyEquity;

  const {
    years,
    retirementAge,
    ageFundsDepleted,
    isPlanFullyFunded,
    sustainableAnnualSpendingReal,
    sustainableAnnualSpendingNominal,
    wealthAtRetirementReal,
    wealthAtRetirementNominal,
    legacyWealthAt95Real,
    legacyWealthAt95Nominal,
    totalLifetimeTaxPaidReal,
    totalLifetimeTaxPaidNominal,
    totalPensionsSavedTaxNominal,
    projectedIhtLiabilityAtEndReal,
    projectedIhtLiabilityAtEndNominal,
    summaryMilestones,
  } = simulationResult;

  // Format GBP Currency Helper
  const formatGbp = (val: number, compact: boolean = false) => {
    if (compact) {
      if (Math.abs(val) >= 1000000) {
        return `£${(val / 1000000).toFixed(2)}m`;
      }
      if (Math.abs(val) >= 1000) {
        return `£${Math.round(val / 1000)}k`;
      }
    }
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Chart Data Mapping (strictly respecting isRealTerms and interactive visibility)
  const chartData = years.map((y) => {
    const pensionPotVal = isRealTerms ? y.pensionPotReal : y.pensionPotNominal;
    const isaBalanceVal = isRealTerms ? y.isaBalanceReal : y.isaBalanceNominal;
    const giaBalanceVal = isRealTerms ? y.giaBalanceReal : y.giaBalanceNominal;
    const cashBalanceVal = isRealTerms ? y.cashBalanceReal : y.cashBalanceNominal;
    const propertyEquityVal = isRealTerms
      ? Math.max(0, y.propertyValueReal - y.mortgageDebtReal)
      : Math.max(0, y.propertyValueNominal - y.mortgageDebtNominal);

    // Dynamic sum of currently visible asset layers
    const activeFilteredNetWorth =
      (visibleAssets.pensionPot ? pensionPotVal : 0) +
      (visibleAssets.isaBalance ? isaBalanceVal : 0) +
      (visibleAssets.giaBalance ? giaBalanceVal : 0) +
      (visibleAssets.cashBalance ? cashBalanceVal : 0) +
      (visibleAssets.propertyEquity ? propertyEquityVal : 0);

    return {
      age: y.age,
      calendarYear: y.calendarYear,
      isRetired: y.isRetired,

      // Inflows (Real or Nominal)
      employment: isRealTerms ? y.grossEmploymentIncome / y.discountFactor : y.grossEmploymentIncome,
      dbPension: isRealTerms ? y.dbPensionIncome / y.discountFactor : y.dbPensionIncome,
      statePension: isRealTerms ? y.statePensionIncome / y.discountFactor : y.statePensionIncome,
      drawdownTaxFree: isRealTerms ? y.drawdownPensionTaxFree / y.discountFactor : y.drawdownPensionTaxFree,
      drawdownTaxable: isRealTerms ? y.drawdownPensionTaxable / y.discountFactor : y.drawdownPensionTaxable,
      drawdownIsa: isRealTerms ? y.drawdownIsa / y.discountFactor : y.drawdownIsa,
      drawdownCash: isRealTerms ? y.drawdownCash / y.discountFactor : y.drawdownCash,
      otherInflows: isRealTerms ? (y.rentalIncome + y.otherTaxableIncome + y.otherNonTaxableIncome) / y.discountFactor : (y.rentalIncome + y.otherTaxableIncome + y.otherNonTaxableIncome),

      // Total Outflow
      totalOutflows: isRealTerms ? y.totalOutflowsReal : y.totalOutflows,
      shortfall: isRealTerms ? y.unmetShortfallReal : y.unmetShortfall,

      // Asset Balances (Real or Nominal)
      pensionPot: pensionPotVal,
      isaBalance: isaBalanceVal,
      giaBalance: giaBalanceVal,
      cashBalance: cashBalanceVal,
      propertyEquity: propertyEquityVal,
      totalNetWorth: isRealTerms ? y.totalNetWorthReal : y.totalNetWorthNominal,
      liquidNetWorth: isRealTerms ? y.liquidNetWorthReal : y.liquidNetWorthNominal,
      filteredNetWorth: activeFilteredNetWorth,
    };
  });

  // Export Table Data to CSV
  const handleExportCsv = () => {
    const headers = [
      'Age',
      'Calendar Year',
      'Status',
      isRealTerms ? 'Total Inflows (Real £)' : 'Total Inflows (Nominal £)',
      isRealTerms ? 'Total Outflows (Real £)' : 'Total Outflows (Nominal £)',
      isRealTerms ? 'Drawdown Needed (Real £)' : 'Drawdown Needed (Nominal £)',
      isRealTerms ? 'Pension Pot (Real £)' : 'Pension Pot (Nominal £)',
      isRealTerms ? 'ISA Balance (Real £)' : 'ISA Balance (Nominal £)',
      isRealTerms ? 'Liquid Wealth (Real £)' : 'Liquid Wealth (Nominal £)',
      isRealTerms ? 'Total Net Worth (Real £)' : 'Total Net Worth (Nominal £)',
    ];

    const rows = years.map((y) => [
      y.age,
      y.calendarYear,
      y.isRetired ? 'Retired' : 'Working',
      isRealTerms ? Math.round(y.totalGrossInflowReal) : Math.round(y.totalGrossInflow),
      isRealTerms ? Math.round(y.totalOutflowsReal) : Math.round(y.totalOutflows),
      isRealTerms ? Math.round(y.totalDrawdownReal) : Math.round(y.totalDrawdown),
      isRealTerms ? Math.round(y.pensionPotReal) : Math.round(y.pensionPotNominal),
      isRealTerms ? Math.round(y.isaBalanceReal) : Math.round(y.isaBalanceNominal),
      isRealTerms ? Math.round(y.liquidNetWorthReal) : Math.round(y.liquidNetWorthNominal),
      isRealTerms ? Math.round(y.totalNetWorthReal) : Math.round(y.totalNetWorthNominal),
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Aura_Cashflow_Simulation_${isRealTerms ? 'Real' : 'Nominal'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const displayedWealthAtRetirement = isRealTerms ? wealthAtRetirementReal : wealthAtRetirementNominal;
  const displayedSustainableSpending = isRealTerms ? sustainableAnnualSpendingReal : sustainableAnnualSpendingNominal;
  const displayedLegacyAt95 = isRealTerms ? legacyWealthAt95Real : legacyWealthAt95Nominal;
  const displayedLifetimeTax = isRealTerms ? totalLifetimeTaxPaidReal : totalLifetimeTaxPaidNominal;
  const displayedIhtAtEnd = isRealTerms ? projectedIhtLiabilityAtEndReal : projectedIhtLiabilityAtEndNominal;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Hero Executive KPI Metric Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Wealth at Retirement Tile */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">
              Wealth at Retirement (Age {retirementAge})
            </span>
            <Coins className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight font-serif">
            {formatGbp(displayedWealthAtRetirement)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
            <span className="inline-flex items-center gap-1 font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {isRealTerms ? "Today's purchasing power" : 'Future nominal cash'}
            </span>
            <span>Target age {retirementAge}</span>
          </div>
        </div>

        {/* Sustainable Annual Retirement Spending */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">
              Target Retirement Spending
            </span>
            <TrendingUp className="w-4 h-4 text-teal-700" />
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight font-serif">
            {formatGbp(displayedSustainableSpending)}
            <span className="text-sm font-normal text-slate-500"> / yr</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
            <span className="text-slate-600">
              {formatGbp(displayedSustainableSpending / 12)} / month
            </span>
            <span className="text-emerald-700 font-medium">100% inflation linked</span>
          </div>
        </div>

        {/* Plan Longevity / Funding Status */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">
              Funding Status & Horizon
            </span>
            {isPlanFullyFunded ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-600" />
            )}
          </div>
          <div className="text-2xl font-bold tracking-tight font-serif">
            {isPlanFullyFunded ? (
              <span className="text-emerald-800">Fully Funded</span>
            ) : (
              <span className="text-amber-800">Depletes at Age {ageFundsDepleted}</span>
            )}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-slate-500">Modeled to Age {profile.personal.planningHorizonAge || 95}</span>
            <span className="font-medium text-slate-700">
              {isPlanFullyFunded ? '£0 Shortfall' : 'Shortfall detected'}
            </span>
          </div>
        </div>

        {/* Projected Legacy at Age 95 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">
              Legacy Wealth at Age 95
            </span>
            <Home className="w-4 h-4 text-slate-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight font-serif">
            {formatGbp(displayedLegacyAt95)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
            <span>
              Est. IHT: <strong className="text-slate-700">{formatGbp(displayedIhtAtEnd)}</strong>
            </span>
            <span className="text-emerald-700 font-medium">{isRealTerms ? 'In today’s £' : 'In future £'}</span>
          </div>
        </div>
      </div>

      {/* 2. Master Interactive Cashflow & Asset Evolution Chart */}
      <div className="bg-white p-4 sm:p-6 lg:p-7 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base sm:text-lg font-semibold text-slate-900 font-serif flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-800 shrink-0" />
              <span>{chartView === 'cashflow' ? 'Annual Inflows, Drawdown & Living Outflows' : 'Net Worth & Asset Class Trajectory'}</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {isRealTerms ? "Showing figures in Real Terms (today's purchasing power, discounted at CPI)" : 'Showing figures in Nominal Terms (future cash amounts)'}
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto w-full sm:w-auto">
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200 text-xs font-medium w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setChartView('cashflow')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
                  chartView === 'cashflow'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Cashflow & Drawdown
              </button>
              <button
                type="button"
                onClick={() => setChartView('assets')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-center transition-all cursor-pointer ${
                  chartView === 'assets'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Net Worth & Assets
              </button>
            </div>
          </div>
        </div>

        {/* DISTINCTIVE, RESPONSIVE CHART VISUAL KEYS (INTERACTIVE LEGEND) - CLICK TO SHOW/HIDE */}
        <div className="bg-slate-50/90 rounded-xl p-3 sm:p-3.5 border border-slate-200/90 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Interactive Layer Keys
              </span>
              <span className="text-[11px] text-slate-500 hidden sm:inline">
                · Click any key to isolate or remove from chart
              </span>
            </div>

            {/* Quick Filter Presets for Net Worth & Assets */}
            {chartView === 'assets' && (
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider hidden lg:inline">
                  Presets:
                </span>
                <button
                  type="button"
                  onClick={setAllAssets}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                    isAllAssetsSelected
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                  }`}
                  title="Show all assets including property"
                >
                  All Assets
                </button>
                <button
                  type="button"
                  onClick={setLiquidOnly}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                    isLiquidOnlySelected
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'bg-white text-emerald-800 hover:bg-emerald-50 border border-emerald-300'
                  }`}
                  title="Exclude property to isolate liquid financial wealth only"
                >
                  <span>💧 Liquid Only</span>
                  <span className="text-[10px] opacity-80">(Excl. Property)</span>
                </button>
                <button
                  type="button"
                  onClick={setPensionsAndIsasOnly}
                  className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-white text-slate-600 hover:text-slate-900 border border-slate-200 transition-all cursor-pointer hidden md:inline-block"
                  title="Show only pensions and ISAs"
                >
                  Pensions & ISAs
                </button>
              </div>
            )}
          </div>

          {chartView === 'cashflow' ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:flex lg:flex-wrap gap-2 text-xs text-slate-700">
              <button
                type="button"
                onClick={() => toggleCashflowKey('employment')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.employment
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Employment income"
              >
                <span className={`w-3 h-3 rounded bg-[#0D9488] shrink-0 ${!visibleCashflows.employment ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.employment ? 'line-through' : ''}`}>Employment</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('dbPension')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.dbPension
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle DB Pension income"
              >
                <span className={`w-3 h-3 rounded bg-[#0284C7] shrink-0 ${!visibleCashflows.dbPension ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.dbPension ? 'line-through' : ''}`}>DB Pension</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('statePension')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.statePension
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle State Pension"
              >
                <span className={`w-3 h-3 rounded bg-[#6366F1] shrink-0 ${!visibleCashflows.statePension ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.statePension ? 'line-through' : ''}`}>State Pension</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('drawdownTaxFree')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.drawdownTaxFree
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Pension 25% Tax-Free Drawdown"
              >
                <span className={`w-3 h-3 rounded bg-[#10B981] shrink-0 ${!visibleCashflows.drawdownTaxFree ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.drawdownTaxFree ? 'line-through' : ''}`}>Pension Tax-Free</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('drawdownTaxable')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.drawdownTaxable
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Pension Taxable Drawdown"
              >
                <span className={`w-3 h-3 rounded bg-[#059669] shrink-0 ${!visibleCashflows.drawdownTaxable ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.drawdownTaxable ? 'line-through' : ''}`}>Pension Taxable</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('drawdownIsa')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.drawdownIsa
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle ISA Drawdown"
              >
                <span className={`w-3 h-3 rounded bg-[#F59E0B] shrink-0 ${!visibleCashflows.drawdownIsa ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.drawdownIsa ? 'line-through' : ''}`}>ISA Drawdown</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('drawdownCash')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.drawdownCash
                    ? 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Cash Drawdown"
              >
                <span className={`w-3 h-3 rounded bg-[#94A3B8] shrink-0 ${!visibleCashflows.drawdownCash ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleCashflows.drawdownCash ? 'line-through' : ''}`}>Cash Drawdown</span>
              </button>

              <button
                type="button"
                onClick={() => toggleCashflowKey('totalOutflows')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleCashflows.totalOutflows
                    ? 'bg-rose-50 border-rose-200 text-rose-900 shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Required Outflows line"
              >
                <span className={`w-4 h-1 rounded-full bg-[#E11D48] shrink-0 ${!visibleCashflows.totalOutflows ? 'opacity-30' : ''}`} />
                <span className={`font-bold text-[11px] sm:text-xs ${!visibleCashflows.totalOutflows ? 'line-through text-slate-400' : 'text-rose-900'}`}>Required Outflows</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:flex lg:flex-wrap gap-2 text-xs text-slate-700">
              {/* DC Pensions */}
              <button
                type="button"
                onClick={() => toggleAssetKey('pensionPot')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.pensionPot
                    ? 'bg-white border-emerald-300/80 text-slate-900 shadow-2xs ring-1 ring-emerald-500/20'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to show/hide DC Pensions & SIPPs"
              >
                <span className={`w-3 h-3 rounded bg-[#10B981] shrink-0 ${!visibleAssets.pensionPot ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleAssets.pensionPot ? 'line-through' : ''}`}>DC Pensions</span>
                {visibleAssets.pensionPot ? (
                  <Check className="w-3 h-3 text-emerald-600 ml-auto sm:ml-0.5" />
                ) : (
                  <EyeOff className="w-3 h-3 text-slate-400 ml-auto sm:ml-0.5" />
                )}
              </button>

              {/* ISAs */}
              <button
                type="button"
                onClick={() => toggleAssetKey('isaBalance')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.isaBalance
                    ? 'bg-white border-amber-300/80 text-slate-900 shadow-2xs ring-1 ring-amber-500/20'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to show/hide Stocks & Shares ISAs"
              >
                <span className={`w-3 h-3 rounded bg-[#F59E0B] shrink-0 ${!visibleAssets.isaBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleAssets.isaBalance ? 'line-through' : ''}`}>ISAs</span>
                {visibleAssets.isaBalance ? (
                  <Check className="w-3 h-3 text-amber-600 ml-auto sm:ml-0.5" />
                ) : (
                  <EyeOff className="w-3 h-3 text-slate-400 ml-auto sm:ml-0.5" />
                )}
              </button>

              {/* GIAs */}
              <button
                type="button"
                onClick={() => toggleAssetKey('giaBalance')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.giaBalance
                    ? 'bg-white border-blue-300/80 text-slate-900 shadow-2xs ring-1 ring-blue-500/20'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to show/hide GIAs"
              >
                <span className={`w-3 h-3 rounded bg-[#3B82F6] shrink-0 ${!visibleAssets.giaBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleAssets.giaBalance ? 'line-through' : ''}`}>GIAs</span>
                {visibleAssets.giaBalance ? (
                  <Check className="w-3 h-3 text-blue-600 ml-auto sm:ml-0.5" />
                ) : (
                  <EyeOff className="w-3 h-3 text-slate-400 ml-auto sm:ml-0.5" />
                )}
              </button>

              {/* Cash & NS&I */}
              <button
                type="button"
                onClick={() => toggleAssetKey('cashBalance')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.cashBalance
                    ? 'bg-white border-slate-300 text-slate-900 shadow-2xs ring-1 ring-slate-400/20'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to show/hide Cash & NS&I Premium Bonds"
              >
                <span className={`w-3 h-3 rounded bg-[#94A3B8] shrink-0 ${!visibleAssets.cashBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleAssets.cashBalance ? 'line-through' : ''}`}>Cash & NS&I</span>
                {visibleAssets.cashBalance ? (
                  <Check className="w-3 h-3 text-slate-600 ml-auto sm:ml-0.5" />
                ) : (
                  <EyeOff className="w-3 h-3 text-slate-400 ml-auto sm:ml-0.5" />
                )}
              </button>

              {/* Property Equity */}
              <button
                type="button"
                onClick={() => toggleAssetKey('propertyEquity')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.propertyEquity
                    ? 'bg-purple-50/70 border-purple-300 text-purple-950 shadow-2xs ring-1 ring-purple-500/20 font-bold'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to show/hide Property Equity (Toggle off to see Liquid Wealth)"
              >
                <span className={`w-3 h-3 rounded bg-[#8B5CF6] shrink-0 ${!visibleAssets.propertyEquity ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] sm:text-xs ${!visibleAssets.propertyEquity ? 'line-through' : ''}`}>Property Equity</span>
                {visibleAssets.propertyEquity ? (
                  <Check className="w-3 h-3 text-purple-700 ml-auto sm:ml-0.5" />
                ) : (
                  <span className="text-[10px] text-purple-600 font-bold px-1 rounded bg-purple-100 ml-auto sm:ml-0.5">Off</span>
                )}
              </button>

              {/* Trajectory Line */}
              <button
                type="button"
                onClick={() => toggleAssetKey('totalNetWorth')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.totalNetWorth
                    ? 'bg-slate-900 border-slate-800 text-white shadow-2xs'
                    : 'bg-slate-100/80 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Click to toggle Total / Filtered Net Worth trajectory line"
              >
                <span className={`w-4 h-1 rounded-full bg-emerald-400 shrink-0 ${!visibleAssets.totalNetWorth ? 'opacity-30' : ''}`} />
                <span className={`font-bold text-[11px] sm:text-xs ${!visibleAssets.totalNetWorth ? 'line-through text-slate-400' : 'text-white'}`}>
                  {isLiquidOnlySelected ? 'Liquid Wealth Line' : isAllAssetsSelected ? 'Total Net Worth' : 'Filtered Sum'}
                </span>
                {visibleAssets.totalNetWorth ? (
                  <Check className="w-3 h-3 text-emerald-400 ml-auto sm:ml-0.5" />
                ) : (
                  <EyeOff className="w-3 h-3 text-slate-400 ml-auto sm:ml-0.5" />
                )}
              </button>
            </div>
          )}
        </div>

        {/* Chart Stage - High-DPI Responsive Canvas with Compact Mobile Margins */}
        <div className="h-80 sm:h-96 lg:h-[420px] w-full pt-1">
          <ResponsiveContainer width="100%" height="100%">
            {chartView === 'cashflow' ? (
              <ComposedChart data={chartData} margin={{ top: 12, right: 6, left: -16, bottom: 18 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis
                  dataKey="age"
                  tickLine={false}
                  axisLine={{ stroke: '#CBD5E1' }}
                  tick={{ fill: '#64748B', fontSize: 10 }}
                  interval="preserveStartEnd"
                  label={{ value: 'Client Age', position: 'insideBottom', offset: -12, fill: '#64748B', fontSize: 10 }}
                />
                <YAxis
                  tickLine={false}
                  axisLine={{ stroke: '#CBD5E1' }}
                  tick={{ fill: '#64748B', fontSize: 10 }}
                  tickFormatter={(v) => formatGbp(v, true)}
                  width={46}
                />
                <Tooltip
                  formatter={(value: any, name: string) => [
                    formatGbp(Number(value)),
                    name === 'employment'
                      ? 'Employment Income'
                      : name === 'dbPension'
                      ? 'DB Pension'
                      : name === 'statePension'
                      ? 'State Pension'
                      : name === 'drawdownTaxFree'
                      ? 'Pension 25% Tax-Free'
                      : name === 'drawdownTaxable'
                      ? 'Pension Taxable Drawdown'
                      : name === 'drawdownIsa'
                      ? 'ISA Tax-Free Drawdown'
                      : name === 'drawdownCash'
                      ? 'Cash Drawdown'
                      : name === 'totalOutflows'
                      ? 'Total Living Outflows'
                      : name,
                  ]}
                  labelFormatter={(age) => {
                    const row = chartData.find((d) => d.age === age);
                    return `Age ${age} (${row?.calendarYear || ''}) · ${row?.isRetired ? 'Retired' : 'Working'}`;
                  }}
                  contentStyle={{ backgroundColor: '#0F172A', color: '#F8FAFC', borderRadius: '12px', border: 'none', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' }}
                />
                {/* Inflow Stack (Filtered by Visible Keys) */}
                {visibleCashflows.employment && <Bar dataKey="employment" name="Employment" stackId="inflow" fill="#0D9488" />}
                {visibleCashflows.dbPension && <Bar dataKey="dbPension" name="DB Pension" stackId="inflow" fill="#0284C7" />}
                {visibleCashflows.statePension && <Bar dataKey="statePension" name="State Pension" stackId="inflow" fill="#6366F1" />}
                {visibleCashflows.drawdownTaxFree && <Bar dataKey="drawdownTaxFree" name="Pension Tax-Free" stackId="inflow" fill="#10B981" />}
                {visibleCashflows.drawdownTaxable && <Bar dataKey="drawdownTaxable" name="Pension Taxable" stackId="inflow" fill="#059669" />}
                {visibleCashflows.drawdownIsa && <Bar dataKey="drawdownIsa" name="ISA Drawdown" stackId="inflow" fill="#F59E0B" />}
                {visibleCashflows.drawdownCash && <Bar dataKey="drawdownCash" name="Cash Drawdown" stackId="inflow" fill="#94A3B8" />}

                {/* Spending Line */}
                {visibleCashflows.totalOutflows && (
                  <Line
                    type="monotone"
                    dataKey="totalOutflows"
                    name="Required Outflows"
                    stroke="#E11D48"
                    strokeWidth={2.5}
                    dot={false}
                  />
                )}
              </ComposedChart>
            ) : (
              <ComposedChart data={chartData} margin={{ top: 12, right: 6, left: -16, bottom: 18 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis
                  dataKey="age"
                  tickLine={false}
                  axisLine={{ stroke: '#CBD5E1' }}
                  tick={{ fill: '#64748B', fontSize: 10 }}
                  interval="preserveStartEnd"
                  label={{ value: 'Client Age', position: 'insideBottom', offset: -12, fill: '#64748B', fontSize: 10 }}
                />
                <YAxis
                  tickLine={false}
                  axisLine={{ stroke: '#CBD5E1' }}
                  tick={{ fill: '#64748B', fontSize: 10 }}
                  tickFormatter={(v) => formatGbp(v, true)}
                  width={46}
                />
                <Tooltip
                  formatter={(value: any, name: string) => [
                    formatGbp(Number(value)),
                    name === 'pensionPot'
                      ? 'DC Pensions'
                      : name === 'isaBalance'
                      ? 'ISA Accounts'
                      : name === 'giaBalance'
                      ? 'GIA Accounts'
                      : name === 'cashBalance'
                      ? 'Cash Reserves & NS&I'
                      : name === 'propertyEquity'
                      ? 'Property Equity'
                      : name === 'filteredNetWorth' || name === 'totalNetWorth'
                      ? isLiquidOnlySelected
                        ? 'Liquid Financial Wealth'
                        : isAllAssetsSelected
                        ? 'Total Net Worth'
                        : 'Filtered Wealth Total'
                      : name,
                  ]}
                  labelFormatter={(age) => {
                    const row = chartData.find((d) => d.age === age);
                    const displayedTotal = row?.filteredNetWorth ?? row?.totalNetWorth ?? 0;
                    return `Age ${age} (${row?.calendarYear || ''}) · ${
                      isLiquidOnlySelected ? 'Liquid Wealth' : isAllAssetsSelected ? 'Net Worth' : 'Filtered Total'
                    }: ${formatGbp(displayedTotal)}`;
                  }}
                  contentStyle={{ backgroundColor: '#0F172A', color: '#F8FAFC', borderRadius: '12px', border: 'none', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' }}
                />
                {/* Asset Stack (Filtered dynamically by key selection) */}
                {visibleAssets.pensionPot && <Bar dataKey="pensionPot" name="DC Pensions" stackId="assets" fill="#10B981" />}
                {visibleAssets.isaBalance && <Bar dataKey="isaBalance" name="ISAs" stackId="assets" fill="#F59E0B" />}
                {visibleAssets.giaBalance && <Bar dataKey="giaBalance" name="GIAs" stackId="assets" fill="#3B82F6" />}
                {visibleAssets.cashBalance && <Bar dataKey="cashBalance" name="Cash & NS&I" stackId="assets" fill="#94A3B8" />}
                {visibleAssets.propertyEquity && <Bar dataKey="propertyEquity" name="Property Equity" stackId="assets" fill="#8B5CF6" />}

                {/* Filtered Trajectory Line */}
                {visibleAssets.totalNetWorth && (
                  <Line
                    type="monotone"
                    dataKey="filteredNetWorth"
                    name={isLiquidOnlySelected ? 'Liquid Financial Wealth' : isAllAssetsSelected ? 'Total Net Worth' : 'Filtered Total'}
                    stroke="#0F172A"
                    strokeWidth={2.5}
                    dot={false}
                  />
                )}
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* 3. Milestone Roadmap */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-800" /> Life Milestones & Key Financial Transitions
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Today */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Today</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-1 block">Age {profile.personal.currentAge}</span>
            <span className="text-xs text-slate-600 font-medium block mt-0.5">
              {formatGbp(summaryMilestones.today.netWorth, true)} NW
            </span>
          </div>

          {/* Mortgage Free */}
          {summaryMilestones.mortgageFreeAge && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">Mortgage Free</span>
              <span className="text-base font-bold text-slate-900 font-serif mt-1 block">Age {summaryMilestones.mortgageFreeAge}</span>
              <span className="text-xs text-emerald-700 font-medium block mt-0.5">£0 Debt</span>
            </div>
          )}

          {/* Target Retirement */}
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">Retirement</span>
            <span className="text-base font-bold text-emerald-950 font-serif mt-1 block">Age {retirementAge}</span>
            <span className="text-xs text-emerald-800 font-medium block mt-0.5">
              {formatGbp(summaryMilestones.retirement.netWorth, true)} NW
            </span>
          </div>

          {/* State Pension */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 block">State Pension</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-1 block">Age {summaryMilestones.statePensionAge}</span>
            <span className="text-xs text-indigo-700 font-medium block mt-0.5">
              +{formatGbp(profile.statePension.primaryAnnualAmount)}/yr
            </span>
          </div>

          {/* Age 75 */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Later Life</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-1 block">Age 75</span>
            <span className="text-xs text-slate-600 font-medium block mt-0.5">
              {formatGbp(summaryMilestones.age75.netWorth, true)} NW
            </span>
          </div>

          {/* Legacy at 95 */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Horizon / Legacy</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-1 block">Age 95</span>
            <span className="text-xs text-slate-600 font-medium block mt-0.5">
              {formatGbp(summaryMilestones.planningHorizon.netWorth, true)} NW
            </span>
          </div>
        </div>
      </div>

      {/* 4. Year-by-Year Financial Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <h3 className="text-base font-semibold text-slate-900 font-serif">
              Annual Cashflow & Asset Schedule
            </h3>
            <p className="text-xs text-slate-500">
              Detailed chronological ledger in {isRealTerms ? "Real Terms (Today's £)" : 'Nominal Terms (Future £)'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-white p-1 rounded-xl flex items-center border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setTableFilter('all')}
                className={`px-2.5 py-1 rounded-lg ${tableFilter === 'all' ? 'bg-slate-900 text-white font-medium' : 'text-slate-600 hover:text-slate-900'}`}
              >
                All Years
              </button>
              <button
                type="button"
                onClick={() => setTableFilter('retirement')}
                className={`px-2.5 py-1 rounded-lg ${tableFilter === 'retirement' ? 'bg-slate-900 text-white font-medium' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Retirement Only
              </button>
              <button
                type="button"
                onClick={() => setTableFilter('decade')}
                className={`px-2.5 py-1 rounded-lg ${tableFilter === 'decade' ? 'bg-slate-900 text-white font-medium' : 'text-slate-600 hover:text-slate-900'}`}
              >
                5-Year Jumps
              </button>
            </div>

            <button
              type="button"
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" /> Export CSV
            </button>
          </div>
        </div>

        <div className="overflow-x-auto max-h-96 scrollbar-thin">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-100/80 sticky top-0 z-10 text-slate-600 font-semibold border-b border-slate-200 uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Age</th>
                <th className="py-2.5 px-3">Year</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Gross Inflows</th>
                <th className="py-2.5 px-3 text-right">Tax Paid</th>
                <th className="py-2.5 px-3 text-right">Outflows</th>
                <th className="py-2.5 px-3 text-right">Drawdown</th>
                <th className="py-2.5 px-3 text-right">DC Pension</th>
                <th className="py-2.5 px-3 text-right">ISAs & Cash</th>
                <th className="py-2.5 px-3 text-right font-bold text-slate-900">Total Net Worth</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {years
                .filter((y) => {
                  if (tableFilter === 'retirement') return y.isRetired;
                  if (tableFilter === 'decade') return y.age % 5 === 0 || y.age === retirementAge;
                  return true;
                })
                .map((y) => {
                  const grossInflow = isRealTerms ? y.totalGrossInflowReal : y.totalGrossInflow;
                  const taxPaid = isRealTerms ? y.totalTaxPaid / y.discountFactor : y.totalTaxPaid;
                  const outflows = isRealTerms ? y.totalOutflowsReal : y.totalOutflows;
                  const drawdown = isRealTerms ? y.totalDrawdownReal : y.totalDrawdown;
                  const pension = isRealTerms ? y.pensionPotReal : y.pensionPotNominal;
                  const isasCash = isRealTerms ? y.isaBalanceReal + y.cashBalanceReal : y.isaBalanceNominal + y.cashBalanceNominal;
                  const netWorth = isRealTerms ? y.totalNetWorthReal : y.totalNetWorthNominal;

                  return (
                    <tr
                      key={y.age}
                      className={`hover:bg-slate-50 transition-colors ${
                        y.age === retirementAge ? 'bg-emerald-50/60 font-semibold' : ''
                      }`}
                    >
                      <td className="py-2 px-3">
                        <span className="font-bold text-slate-900">{y.age}</span>
                      </td>
                      <td className="py-2 px-3 text-slate-500">{y.calendarYear}</td>
                      <td className="py-2 px-3">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                            y.isRetired ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {y.isRetired ? 'Retired' : 'Working'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-mono">{formatGbp(grossInflow)}</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-500">{formatGbp(taxPaid)}</td>
                      <td className="py-2 px-3 text-right font-mono text-red-700">{formatGbp(outflows)}</td>
                      <td className="py-2 px-3 text-right font-mono text-emerald-700">
                        {drawdown > 0 ? formatGbp(drawdown) : '—'}
                      </td>
                      <td className="py-2 px-3 text-right font-mono">{formatGbp(pension)}</td>
                      <td className="py-2 px-3 text-right font-mono">{formatGbp(isasCash)}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                        {formatGbp(netWorth)}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
