/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Client-Ready Financial Planning Report
 * Supports both:
 * 1. Full Comprehensive Client Report (Complete sequential audit of all client inputs, asset inventories, assumptions & milestone cashflows)
 * 2. Summary Client Report (Concise executive brief answering the 6 core UK wealth questions)
 */

import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  Printer,
  Compass,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Coins,
  ShieldCheck,
  TrendingUp,
  FileCheck,
  FileText,
  Award,
  ArrowRight,
  Layers,
  User,
  Users,
  Briefcase,
  Home,
  Building,
  PiggyBank,
  Sparkles,
  Scale,
  Percent,
  Check,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { calculateInheritanceTax } from '../../aura/engine/taxEngine';
import { AuraBrandLogo } from '../common/AuraBrandLogo';

export const FinancialReportView: React.FC = () => {
  const { profile, adviserDetails, simulationResult, monteCarloResult, isRealTerms, reportMode, setReportMode } = useCashflow();

  // Interactive Asset Class Layer Visibility
  const [visibleAssets, setVisibleAssets] = useState<{
    pensionPot: boolean;
    isaBalance: boolean;
    giaBalance: boolean;
    cashBalance: boolean;
    propertyEquity: boolean;
    totalNetWorth: boolean;
  }>({
    pensionPot: true,
    isaBalance: true,
    giaBalance: true,
    cashBalance: true,
    propertyEquity: true,
    totalNetWorth: true,
  });

  const toggleAssetKey = (key: keyof typeof visibleAssets) => {
    setVisibleAssets((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const setAllAssets = () => {
    setVisibleAssets({
      pensionPot: true,
      isaBalance: true,
      giaBalance: true,
      cashBalance: true,
      propertyEquity: true,
      totalNetWorth: true,
    });
  };

  const setLiquidOnly = () => {
    setVisibleAssets({
      pensionPot: true,
      isaBalance: true,
      giaBalance: true,
      cashBalance: true,
      propertyEquity: false,
      totalNetWorth: true,
    });
  };

  const isAllAssetsSelected =
    visibleAssets.pensionPot &&
    visibleAssets.isaBalance &&
    visibleAssets.giaBalance &&
    visibleAssets.cashBalance &&
    visibleAssets.propertyEquity;

  const isLiquidOnlySelected =
    visibleAssets.pensionPot &&
    visibleAssets.isaBalance &&
    visibleAssets.giaBalance &&
    visibleAssets.cashBalance &&
    !visibleAssets.propertyEquity;

  const {
    years,
    retirementAge,
    isPlanFullyFunded,
    ageFundsDepleted,
    sustainableAnnualSpendingReal,
    wealthAtRetirementReal,
    wealthAtRetirementNominal,
    legacyWealthAt95Real,
    legacyWealthAt95Nominal,
    totalLifetimeTaxPaidReal,
    totalPensionsSavedTaxNominal,
    projectedIhtLiabilityAtEndReal,
  } = simulationResult;

  const formatGbp = (val: number, compact: boolean = false) => {
    if (compact) {
      if (Math.abs(val) >= 1000000) return `£${(val / 1000000).toFixed(2)}m`;
      if (Math.abs(val) >= 1000) return `£${Math.round(val / 1000)}k`;
    }
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handlePrint = () => {
    window.print();
  };

  const hasPartner = profile.personal.hasPartner;
  const isMarriedOrCivilPartner =
    hasPartner &&
    (profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType);

  // Asset Totals
  const totalDcPension = profile.dcPensions.reduce((sum, p) => sum + p.currentPotValue, 0);
  const primaryDcPension = profile.dcPensions
    .filter((p) => p.owner !== 'partner')
    .reduce((sum, p) => sum + p.currentPotValue, 0);
  const partnerDcPension = profile.dcPensions
    .filter((p) => p.owner === 'partner')
    .reduce((sum, p) => sum + p.currentPotValue, 0);

  const totalIsa = profile.isas.reduce((sum, i) => sum + i.balance, 0);
  const primaryIsa = profile.isas.filter((i) => i.owner !== 'partner').reduce((sum, i) => sum + i.balance, 0);
  const partnerIsa = profile.isas.filter((i) => i.owner === 'partner').reduce((sum, i) => sum + i.balance, 0);

  const totalGia = profile.gias.reduce((sum, g) => sum + g.balance, 0);
  const totalCash = profile.cashAccounts.reduce((sum, c) => sum + c.balance, 0);
  const totalInvestmentBonds = (profile.investmentBonds || []).reduce((sum, b) => sum + b.currentValue, 0);
  const totalOtherInvestments = (profile.otherInvestments || []).reduce((sum, o) => sum + o.balance, 0);
  const totalProperty = profile.properties.reduce((sum, p) => sum + p.currentValue, 0);
  const totalMortgage = profile.mortgages.reduce((sum, m) => sum + m.outstandingBalance, 0);
  const currentNetWorth =
    totalDcPension + totalIsa + totalGia + totalCash + totalInvestmentBonds + totalOtherInvestments + totalProperty - totalMortgage;

  // IHT Calculations for Report
  const ihtPre2027 = calculateInheritanceTax({
    propertyValue: totalProperty,
    liquidAssets: totalIsa + totalGia + totalCash + totalInvestmentBonds + totalOtherInvestments,
    dcPensionPot: totalDcPension,
    mortgageDebt: totalMortgage,
    hasSpouseOrCivilPartner: isMarriedOrCivilPartner,
    isPostApril2027: false,
    includePensionsInIhtPost2027: false,
  });

  const ihtPost2027 = calculateInheritanceTax({
    propertyValue: totalProperty,
    liquidAssets: totalIsa + totalGia + totalCash + totalInvestmentBonds + totalOtherInvestments,
    dcPensionPot: totalDcPension,
    mortgageDebt: totalMortgage,
    hasSpouseOrCivilPartner: isMarriedOrCivilPartner,
    isPostApril2027: true,
    includePensionsInIhtPost2027: true,
  });

  // Chart Data for Report (dynamically computes active layers and filtered total)
  const chartData = years.map((y) => {
    const pensionPotVal = isRealTerms ? y.pensionPotReal : y.pensionPotNominal;
    const isaBalanceVal = isRealTerms ? y.isaBalanceReal : y.isaBalanceNominal;
    const giaBalanceVal = isRealTerms ? y.giaBalanceReal : y.giaBalanceNominal;
    const cashBalanceVal = isRealTerms ? y.cashBalanceReal : y.cashBalanceNominal;
    const propertyEquityVal = isRealTerms
      ? Math.max(0, y.propertyValueReal - y.mortgageDebtReal)
      : Math.max(0, y.propertyValueNominal - y.mortgageDebtNominal);

    const activeFilteredNetWorth =
      (visibleAssets.pensionPot ? pensionPotVal : 0) +
      (visibleAssets.isaBalance ? isaBalanceVal : 0) +
      (visibleAssets.giaBalance ? giaBalanceVal : 0) +
      (visibleAssets.cashBalance ? cashBalanceVal : 0) +
      (visibleAssets.propertyEquity ? propertyEquityVal : 0);

    return {
      age: y.age,
      calendarYear: y.calendarYear,
      pensionPot: pensionPotVal,
      isaBalance: isaBalanceVal,
      giaBalance: giaBalanceVal,
      cashBalance: cashBalanceVal,
      propertyEquity: propertyEquityVal,
      totalNetWorth: isRealTerms ? y.totalNetWorthReal : y.totalNetWorthNominal,
      filteredNetWorth: activeFilteredNetWorth,
    };
  });

  // Milestone years for full report schedule table
  const milestoneYears = years.filter((y) => {
    const isFirst = y.age === profile.personal.currentAge;
    const isRetirement = y.age === profile.personal.targetRetirementAge;
    const isStatePension = y.age === profile.statePension.primaryStatePensionAge;
    const isBenchmarkAge = [70, 75, 80, 85, 90, 95].includes(y.age);
    const isLast = y.age === (profile.personal.planningHorizonAge || 95);
    return isFirst || isRetirement || isStatePension || isBenchmarkAge || isLast;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Action & Mode Selector Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block">
            Executive Document
          </span>
          <h3 className="text-base font-bold text-slate-900 font-serif flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-800" />
            {reportMode === 'full' ? 'Full Comprehensive Client Report' : 'Summary Client Report'}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {reportMode === 'full'
              ? 'Complete, logically sequenced audit of all inputted client data, asset inventories, assumptions & milestone cashflows.'
              : 'Concise executive summary answering the 6 core UK wealth & retirement questions.'}
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto flex-wrap">
          {/* Full vs Summary Segmented Control */}
          <div
            className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200"
            role="group"
            aria-label="Report detail level"
          >
            <button
              type="button"
              onClick={() => setReportMode('full')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                reportMode === 'full'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Full Report</span>
            </button>
            <button
              type="button"
              onClick={() => setReportMode('summary')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                reportMode === 'summary'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Summary Report</span>
            </button>
          </div>

          {/* Print / Save as PDF Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Canvas */}
      <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-sm space-y-10 text-slate-900 print:border-none print:shadow-none print:p-0">
        {/* 1. Header Banner */}
        <div className="border-b-2 border-slate-900 pb-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <div className="mb-2">
                <AuraBrandLogo variant="report-header" showTagline={true} />
                <span className="text-xs text-emerald-800 font-semibold block mt-1">{adviserDetails.firmName || 'Wealth Advisory Practice'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight mt-3">
                {reportMode === 'full' ? 'Comprehensive Financial Planning & Cashflow Report' : 'Executive Wealth & Retirement Plan'}
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Prepared for: <strong>{profile.personal.fullName || 'Private Client'}</strong>
                {hasPartner && ` & ${profile.personal.partnerName || 'Partner'}`} · UK Tax Year 2026/27 Statutory Rules
              </p>
            </div>

            {/* Adviser Practice & Jurisdiction Metadata */}
            <div className="sm:text-right text-xs text-slate-600 space-y-1 sm:min-w-[240px] bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-xl border sm:border-0 border-slate-200">
              <div className="font-serif font-bold text-slate-900 text-sm">{adviserDetails.adviserName}</div>
              <div className="text-slate-500">{adviserDetails.adviserTitle}</div>
              <div className="text-slate-500">{adviserDetails.email} {adviserDetails.phone ? `· ${adviserDetails.phone}` : ''}</div>
              <div className="text-slate-400 text-[11px]">Date: {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</div>
              <div className="font-semibold text-emerald-800 text-[11px] pt-1">
                Figures in {isRealTerms ? "Real Terms (Today's £)" : "Nominal Terms (Future £)"}
              </div>
            </div>
          </div>

          {/* Optional Adviser Preface Notes */}
          {adviserDetails.adviserNotes && (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
              <span className="font-bold text-slate-900 block mb-1">Adviser Planning Preface:</span>
              {adviserDetails.adviserNotes}
            </div>
          )}
        </div>

        {/* 2. Executive Summary Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 block">
              Core Plan Outcome
            </span>
            <span className="text-2xl font-serif font-bold text-emerald-950 mt-1 block">
              {isPlanFullyFunded ? 'Fully Funded' : `Depletion Age ${ageFundsDepleted}`}
            </span>
            <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
              {isPlanFullyFunded
                ? `Comfortably supports desired spending of ${formatGbp(sustainableAnnualSpendingReal)}/yr to age ${profile.personal.planningHorizonAge || 95}.`
                : 'Spending adjustments or contribution increases recommended to bridge shortfall.'}
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              Retirement Target
            </span>
            <span className="text-2xl font-serif font-bold text-slate-900 mt-1 block">
              Age {retirementAge} {hasPartner && profile.personal.partnerTargetRetirementAge ? `(Partner: Age ${profile.personal.partnerTargetRetirementAge})` : ''}
            </span>
            <p className="text-xs text-slate-600 mt-1">
              Projected net worth at retirement:{' '}
              <strong>{formatGbp(isRealTerms ? wealthAtRetirementReal : wealthAtRetirementNominal)}</strong>.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              Monte Carlo Resilience
            </span>
            <span className="text-2xl font-serif font-bold text-slate-900 mt-1 block">
              {monteCarloResult.successProbabilityPercent}% Confidence
            </span>
            <p className="text-xs text-slate-600 mt-1">
              {monteCarloResult.resilienceRating} resilience across 1,000 randomized market sequences.
            </p>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* FULL COMPREHENSIVE REPORT: LOGICAL SEQUENCE OF ALL INPUTTED DATA */}
        {/* ========================================================================= */}
        {reportMode === 'full' && (
          <div className="space-y-10 pt-2 border-t border-slate-200">
            <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between">
              <div>
                <h2 className="font-serif font-bold text-base">Comprehensive Client Data Ledger & Inputs Audit</h2>
                <p className="text-xs text-slate-300">Complete inventory of all verified financial records in logical planning sequence</p>
              </div>
              <span className="px-3 py-1 bg-blue-600 text-white rounded-full text-xs font-bold">
                Part 1: Input Audit
              </span>
            </div>

            {/* Section A: Personal & Household Demographic Profile */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <User className="w-4 h-4 text-emerald-800" />
                A. Personal & Household Demographic Profile
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Primary Client</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">{profile.personal.fullName || 'Client'}</span>
                  <span className="text-slate-600">Age {profile.personal.currentAge} · Retiring Age {profile.personal.targetRetirementAge}</span>
                </div>
                {hasPartner ? (
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block">Partner / Spouse</span>
                    <span className="font-bold text-slate-900 text-sm block mt-0.5">{profile.personal.partnerName || 'Partner'}</span>
                    <span className="text-slate-600">Age {profile.personal.partnerAge || profile.personal.currentAge} · Retiring Age {profile.personal.partnerTargetRetirementAge || profile.personal.targetRetirementAge}</span>
                  </div>
                ) : (
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block">Marital Status</span>
                    <span className="font-bold text-slate-900 text-sm block mt-0.5">Single / Individual</span>
                    <span className="text-slate-600">Individual allowances applied</span>
                  </div>
                )}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Marital Relationship & IHT Status</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">
                    {isMarriedOrCivilPartner ? 'Spouse / Civil Partner' : hasPartner ? 'Cohabiting (Unmarried)' : 'Single'}
                  </span>
                  <span className="text-slate-600">
                    {isMarriedOrCivilPartner
                      ? '100% Spousal Exemption (s.18 IHTA)'
                      : hasPartner
                      ? '⚠️ No Spousal Exemption (Taxable)'
                      : 'Standard £325k NRB'}
                  </span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Planning Horizon & Tax Region</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">
                    Age {profile.personal.planningHorizonAge || 95}
                  </span>
                  <span className="text-slate-600">
                    {profile.personal.taxRegion === 'scotland' ? 'Scottish Income Tax' : 'UK Standard Tax (Rest of UK)'}
                  </span>
                </div>
              </div>
            </section>

            {/* Section B: Earned Incomes & Employment Ledger */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Briefcase className="w-4 h-4 text-emerald-800" />
                B. Earned Incomes, Salary Sacrifice & Employment Ledger
              </h3>
              {profile.employment.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No earned employment incomes active (fully retired or non-earning).</p>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                        <th className="py-2.5 px-3">Earner / Description</th>
                        <th className="py-2.5 px-3">Owner</th>
                        <th className="py-2.5 px-3 text-right">Gross Salary</th>
                        <th className="py-2.5 px-3 text-right">Annual Bonus</th>
                        <th className="py-2.5 px-3 text-right">Employee Pension</th>
                        <th className="py-2.5 px-3 text-right">Employer Pension</th>
                        <th className="py-2.5 px-3 text-right">Growth Rate</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {profile.employment.map((emp) => (
                        <tr key={emp.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-semibold text-slate-900">{emp.label || 'Employment'}</td>
                          <td className="py-2.5 px-3 text-slate-600">
                            {emp.owner === 'partner' ? profile.personal.partnerName || 'Partner' : profile.personal.fullName || 'Primary'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-medium">{formatGbp(emp.annualGross)}</td>
                          <td className="py-2.5 px-3 text-right text-slate-600">{formatGbp(emp.annualBonus || 0)}</td>
                          <td className="py-2.5 px-3 text-right text-emerald-700 font-medium">
                            {emp.employeePensionPercent}% ({formatGbp(emp.annualGross * (emp.employeePensionPercent / 100))})
                            {emp.isSalarySacrifice && ' [Sacrifice]'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-600">
                            {emp.employerPensionPercent}% ({formatGbp(emp.annualGross * (emp.employerPensionPercent / 100))})
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-600">{emp.annualGrowthPercent || 2.5}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            {/* Section C: Household Living Costs & Scheduled Life Events */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Coins className="w-4 h-4 text-emerald-800" />
                C. Household Living Costs, Discretionary Expenditure & Future Life Events
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <h4 className="font-serif font-semibold text-slate-900">Annual Expenditure Breakdown</h4>
                  <div className="space-y-1 text-slate-700">
                    <div className="flex justify-between py-1 border-b border-slate-200">
                      <span>Core Living Outgoings:</span>
                      <span className="font-bold">{formatGbp(profile.expenses.reduce((s, e) => s + e.annualAmount, 0))} / yr</span>
                    </div>
                    {profile.expenses.map((exp) => (
                      <div key={exp.id} className="flex justify-between text-slate-600 py-0.5">
                        <span>{exp.label} ({exp.category}):</span>
                        <span>{formatGbp(exp.annualAmount)}/yr (Retirement: {Math.round(exp.retirementMultiplier * 100)}%)</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <h4 className="font-serif font-semibold text-slate-900">Scheduled Future Life Events & Capital Inflows/Outflows</h4>
                  {(!profile.lifeEvents || profile.lifeEvents.length === 0) ? (
                    <p className="text-slate-500 italic">No future one-off capital life events configured.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {profile.lifeEvents.map((evt) => (
                        <div key={evt.id} className="flex justify-between p-2 rounded bg-white border border-slate-200">
                          <div>
                            <span className="font-semibold text-slate-900 block">{evt.label}</span>
                            <span className="text-[11px] text-slate-500">Target Age {evt.targetAge} ({evt.type})</span>
                          </div>
                          <span className={`font-bold ${evt.direction === 'inflow' ? 'text-emerald-700' : 'text-amber-700'}`}>
                            {evt.direction === 'inflow' ? `+${formatGbp(evt.amount)}` : `-${formatGbp(evt.amount)}`}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </section>

            {/* Section D: Pensions Inventory (DC & DB) */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <PiggyBank className="w-4 h-4 text-emerald-800" />
                D. Defined Contribution (DC) & Defined Benefit (DB) Pensions Inventory
              </h3>
              
              {/* DC Pensions Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                      <th className="py-2.5 px-3">DC Pension Scheme</th>
                      <th className="py-2.5 px-3">Owner</th>
                      <th className="py-2.5 px-3 text-right">Pot Value</th>
                      <th className="py-2.5 px-3 text-right">Monthly Employee</th>
                      <th className="py-2.5 px-3 text-right">Monthly Employer</th>
                      <th className="py-2.5 px-3 text-right">Growth Rate</th>
                      <th className="py-2.5 px-3 text-right">Annual Fee</th>
                      <th className="py-2.5 px-3 text-center">Tax-Free Taken</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {profile.dcPensions.map((dc) => (
                      <tr key={dc.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{dc.label || 'DC Pension'}</td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {dc.owner === 'partner' ? profile.personal.partnerName || 'Partner' : profile.personal.fullName || 'Primary'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-emerald-900">{formatGbp(dc.currentPotValue)}</td>
                        <td className="py-2.5 px-3 text-right">{formatGbp(dc.ongoingMonthlyContribution || 0)}/mo</td>
                        <td className="py-2.5 px-3 text-right">{formatGbp(dc.ongoingEmployerMonthlyContribution || 0)}/mo</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{dc.growthRatePercent}%</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{dc.annualFeePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {dc.taxFreeCashTakenPercent || 0}% Taken
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td className="py-2.5 px-3" colSpan={2}>Total DC Pension Wealth</td>
                      <td className="py-2.5 px-3 text-right text-emerald-950 font-serif text-sm">{formatGbp(totalDcPension)}</td>
                      <td colSpan={5}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* DB Pensions & State Pension */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <h4 className="font-serif font-semibold text-slate-900">Defined Benefit (Final Salary) Schemes</h4>
                  {profile.dbPensions.length === 0 ? (
                    <p className="text-slate-500 italic">No DB pensions recorded.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {profile.dbPensions.map((db) => (
                        <div key={db.id} className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                          <div>
                            <span className="font-semibold text-slate-900 block">{db.label || 'DB Scheme'}</span>
                            <span className="text-[11px] text-slate-500">Commences at age {db.startAge || 65} · {db.annualEscalationPercent || 2.5}% Escalation</span>
                          </div>
                          <span className="font-bold text-slate-900">{formatGbp(db.annualGuaranteedIncome)}/yr</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <h4 className="font-serif font-semibold text-slate-900">UK State Pension Entitlements</h4>
                  <div className="space-y-1.5">
                    <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                      <div>
                        <span className="font-semibold text-slate-900 block">{profile.personal.fullName || 'Primary Client'}</span>
                        <span className="text-[11px] text-slate-500">Starts age {profile.statePension.primaryStatePensionAge} · Full Triple Lock</span>
                      </div>
                      <span className="font-bold text-emerald-800">{formatGbp(profile.statePension.primaryAnnualAmount)}/yr</span>
                    </div>
                    {hasPartner && (
                      <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                        <div>
                          <span className="font-semibold text-slate-900 block">{profile.personal.partnerName || 'Partner'}</span>
                          <span className="text-[11px] text-slate-500">Starts age {profile.statePension.partnerStatePensionAge || 67}</span>
                        </div>
                        <span className="font-bold text-emerald-800">{formatGbp(profile.statePension.partnerAnnualAmount || 12450)}/yr</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </section>

            {/* Section E: Liquid Savings, ISAs, GIAs, Specialist & Cash */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Coins className="w-4 h-4 text-emerald-800" />
                E. Liquid Savings, ISAs, GIAs, Specialist Holdings & Cash Reserves Ledger
              </h3>
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                      <th className="py-2.5 px-3">Account / Holding</th>
                      <th className="py-2.5 px-3">Asset Type</th>
                      <th className="py-2.5 px-3">Owner</th>
                      <th className="py-2.5 px-3 text-right">Balance / Value</th>
                      <th className="py-2.5 px-3 text-right">Cost Basis</th>
                      <th className="py-2.5 px-3 text-right">Growth %</th>
                      <th className="py-2.5 px-3 text-center">Tax Wrapper Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {/* Cash */}
                    {profile.cashAccounts.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{c.label || 'Cash Deposit'}</td>
                        <td className="py-2.5 px-3 text-slate-600">Cash / NS&I</td>
                        <td className="py-2.5 px-3 text-slate-600">{c.owner}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-900">{formatGbp(c.balance)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-500">{formatGbp(c.balance)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{c.interestRatePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 border">
                            {c.isEmergencyFund ? 'Emergency Reserve' : 'Cash Deposit'}
                          </span>
                        </td>
                      </tr>
                    ))}

                    {/* ISAs */}
                    {profile.isas.map((i) => (
                      <tr key={i.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{i.label || 'Stocks & Shares ISA'}</td>
                        <td className="py-2.5 px-3 text-slate-600">ISA Wrapper</td>
                        <td className="py-2.5 px-3 text-slate-600">{i.owner}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-amber-900">{formatGbp(i.balance)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-500">N/A (Exempt)</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{i.growthRatePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                            100% Tax-Free
                          </span>
                        </td>
                      </tr>
                    ))}

                    {/* GIAs */}
                    {profile.gias.map((g) => (
                      <tr key={g.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{g.label || 'GIA Account'}</td>
                        <td className="py-2.5 px-3 text-slate-600">Taxable GIA</td>
                        <td className="py-2.5 px-3 text-slate-600">{g.owner}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-blue-900">{formatGbp(g.balance)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-700 font-medium">
                          {g.costBasis ? formatGbp(g.costBasis) : <span className="text-red-600 font-bold">£0 (Missing)</span>}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{g.growthRatePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-900 border border-blue-200">
                            Taxable (18%/24% CGT)
                          </span>
                        </td>
                      </tr>
                    ))}

                    {/* Investment Bonds (Onshore & Offshore) */}
                    {(profile.investmentBonds || []).map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{b.label || (b.bondType === 'offshore' ? 'Offshore Bond' : 'Onshore Bond')}</td>
                        <td className="py-2.5 px-3 text-slate-600">{b.bondType === 'offshore' ? 'Offshore Life Bond' : 'UK Onshore Bond'}</td>
                        <td className="py-2.5 px-3 text-slate-600">{b.owner}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-emerald-900">{formatGbp(b.currentValue)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-700">
                          {b.originalPremium ? formatGbp(b.originalPremium) : formatGbp(b.currentValue)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{b.growthRatePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200">
                            5% Tax-Deferred ({b.bondType === 'offshore' ? 'Gross Roll-Up' : '20% Credit'})
                          </span>
                        </td>
                      </tr>
                    ))}

                    {/* Specialist Investments */}
                    {(profile.otherInvestments || []).map((o) => (
                      <tr key={o.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{o.label || 'Specialist Holding'}</td>
                        <td className="py-2.5 px-3 text-slate-600">{(o.investmentType || 'specialist').toUpperCase()}</td>
                        <td className="py-2.5 px-3 text-slate-600">{o.owner}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-indigo-900">{formatGbp(o.balance)}</td>
                        <td className="py-2.5 px-3 text-right text-slate-700">
                          {o.costBasis ? formatGbp(o.costBasis) : <span className="text-red-600 font-bold">£0 (Missing)</span>}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{o.growthRatePercent}%</td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-900 border border-teal-200">
                            {o.investmentType === 'vct'
                              ? 'VCT 100% CGT Exempt'
                              : o.investmentType === 'eis'
                              ? 'EIS 30% Relief + IHT Relief'
                              : o.investmentType === 'seis'
                              ? 'SEIS 50% Relief'
                              : 'Specialist Asset'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td className="py-2.5 px-3" colSpan={3}>Total Non-Pension Liquid & Investment Portfolio</td>
                      <td className="py-2.5 px-3 text-right text-slate-900 font-serif text-sm">
                        {formatGbp(totalCash + totalIsa + totalGia + totalInvestmentBonds + totalOtherInvestments)}
                      </td>
                      <td colSpan={3}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </section>

            {/* Section F: Real Estate & Property Assets */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Home className="w-4 h-4 text-emerald-800" />
                F. Real Estate Portfolio, Mortgages & Property Equity
              </h3>
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                      <th className="py-2.5 px-3">Property Asset</th>
                      <th className="py-2.5 px-3">Owner</th>
                      <th className="py-2.5 px-3 text-right">Market Value</th>
                      <th className="py-2.5 px-3 text-right">Cost Basis</th>
                      <th className="py-2.5 px-3 text-right">Attached Mortgage</th>
                      <th className="py-2.5 px-3 text-right">Net Equity</th>
                      <th className="py-2.5 px-3 text-center">Tax Classification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {profile.properties.map((p) => {
                      const mortgage = profile.mortgages.find((m) => m.propertyId === p.id);
                      const mortgageBalance = mortgage ? mortgage.outstandingBalance : 0;
                      const equity = Math.max(0, p.currentValue - mortgageBalance);
                      return (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-semibold text-slate-900">{p.label || 'Property Asset'}</td>
                          <td className="py-2.5 px-3 text-slate-600">{p.owner}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-900">{formatGbp(p.currentValue)}</td>
                          <td className="py-2.5 px-3 text-right text-slate-600">
                            {p.isPrimaryResidence ? 'N/A (PRR)' : p.costBasis ? formatGbp(p.costBasis) : '£0 (Missing)'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-amber-800">{formatGbp(mortgageBalance)}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-900">{formatGbp(equity)}</td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              p.isPrimaryResidence ? 'bg-emerald-100 text-emerald-900' : 'bg-slate-100 text-slate-800'
                            }`}>
                              {p.isPrimaryResidence ? 'Primary Residence (PRR)' : 'Buy-to-Let / Secondary'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td className="py-2.5 px-3" colSpan={2}>Total Real Estate Portfolio</td>
                      <td className="py-2.5 px-3 text-right font-serif text-sm">{formatGbp(totalProperty)}</td>
                      <td></td>
                      <td className="py-2.5 px-3 text-right text-amber-800">{formatGbp(totalMortgage)}</td>
                      <td className="py-2.5 px-3 text-right text-emerald-950 font-serif text-sm">
                        {formatGbp(Math.max(0, totalProperty - totalMortgage))}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </section>

            {/* Section G: Economic Assumptions & Benchmarks */}
            <section className="space-y-3">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Scale className="w-4 h-4 text-emerald-800" />
                G. Core Economic Assumptions & Decumulation Drawdown Strategy
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">General CPI Inflation</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">{profile.assumptions.inflationRatePercent}% / yr</span>
                  <span className="text-slate-500">Benchmark consumer inflation</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Cash Benchmark Yield</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">2.0% / yr</span>
                  <span className="text-slate-500">Liquid reserve return</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Equity Growth (Net)</span>
                  <span className="font-bold text-slate-900 text-sm block mt-0.5">{profile.assumptions.defaultEquityGrowthRatePercent}% / yr</span>
                  <span className="text-slate-500">Net portfolio assumption</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block">Terms of Measurement</span>
                  <span className="font-bold text-emerald-800 text-sm block mt-0.5">
                    {isRealTerms ? "Real Terms (Today's £)" : "Nominal Terms (Future £)"}
                  </span>
                  <span className="text-slate-500">{isRealTerms ? 'Stripped of inflation' : 'Includes future compounding'}</span>
                </div>
              </div>

              {/* Active Drawdown Sequence Breakdown */}
              <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200/80 text-xs">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-800" />
                    Active Decumulation Strategy: {
                      profile.assumptions.drawdownStrategy === 'pension_first'
                        ? 'Pension-First (IHT Minimiser)'
                        : profile.assumptions.drawdownStrategy === 'isa_first'
                        ? 'ISA-First Bridge'
                        : profile.assumptions.drawdownStrategy === 'cash_first'
                        ? 'Cash-First Buffer'
                        : profile.assumptions.drawdownStrategy === 'custom'
                        ? 'Bespoke Custom Sequence'
                        : 'Tax-Optimised Waterfall (Recommended)'
                    }
                  </span>
                  <span className="text-2xs font-semibold text-emerald-800 uppercase tracking-wider bg-white px-2 py-0.5 rounded-md border border-emerald-200">
                    Automated Decumulation Routing
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-2xs">
                  {(() => {
                    const defaultSeq: Record<string, string[]> = {
                      tax_optimised: ['1. Liquid Cash Buffer', '2. Taxable GIAs & CGT', '3. DC Pension Drawdown', '4. ISA Tax-Free Shield'],
                      pension_first: ['1. DC Pension Drawdown', '2. Taxable GIAs & CGT', '3. ISA Tax-Free Shield', '4. Liquid Cash Buffer'],
                      isa_first: ['1. ISA Tax-Free Shield', '2. Liquid Cash Buffer', '3. Taxable GIAs & CGT', '4. DC Pension Drawdown'],
                      cash_first: ['1. Liquid Cash Buffer', '2. ISA Tax-Free Shield', '3. Taxable GIAs & CGT', '4. DC Pension Drawdown'],
                    };
                    const custom = profile.assumptions.customDrawdownOrder;
                    const potNameMap: Record<string, string> = {
                      cash: 'Liquid Cash Buffer',
                      gia: 'Taxable GIAs & CGT',
                      pension: 'DC Pension Drawdown',
                      isa: 'ISA Tax-Free Shield',
                    };
                    const list = profile.assumptions.drawdownStrategy === 'custom' && custom && custom.length === 4
                      ? custom.map((k, idx) => `${idx + 1}. ${potNameMap[k] || k}`)
                      : defaultSeq[profile.assumptions.drawdownStrategy || 'tax_optimised'] || defaultSeq.tax_optimised;

                    return list.map((item, idx) => (
                      <div key={idx} className="p-2 bg-white rounded-lg border border-emerald-100 font-medium text-slate-800">
                        <span className="text-emerald-800 font-bold block">{item.split('. ')[0]}.</span>
                        <span>{item.split('. ')[1]}</span>
                      </div>
                    ));
                  })()}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ========================================================================= */}
        {/* EXECUTIVE ANALYSIS: THE 6 CORE UK WEALTH QUESTIONS (SUMMARY & FULL) */}
        {/* ========================================================================= */}
        <div className="space-y-8 pt-2">
          {reportMode === 'full' && (
            <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between">
              <div>
                <h2 className="font-serif font-bold text-base">Strategic Cashflow Analysis & Modeling Outcomes</h2>
                <p className="text-xs text-slate-300">Evaluating your plan against the 6 core lifetime wealth questions</p>
              </div>
              <span className="px-3 py-1 bg-emerald-700 text-white rounded-full text-xs font-bold">
                Part 2: Planning Analysis
              </span>
            </div>
          )}

          {/* Question 1: Where am I today? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                1
              </span>
              Where am I today?
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              At age {profile.personal.currentAge} {hasPartner ? `(and partner age ${profile.personal.partnerAge || profile.personal.currentAge})` : ''}, your total household net worth is{' '}
              <strong>{formatGbp(currentNetWorth)}</strong>. This comprises{' '}
              <strong>{formatGbp(totalDcPension)}</strong> in defined contribution pensions
              {hasPartner ? ` (${profile.personal.fullName || 'Primary'}: ${formatGbp(primaryDcPension)}, ${profile.personal.partnerName || 'Partner'}: ${formatGbp(partnerDcPension)})` : ''},{' '}
              <strong>{formatGbp(totalIsa + totalCash + totalOtherInvestments)}</strong> in liquid ISAs, cash reserves and specialist assets
              {hasPartner && totalIsa > 0 ? ` (ISAs: ${profile.personal.fullName || 'Primary'} ${formatGbp(primaryIsa)}, ${profile.personal.partnerName || 'Partner'} ${formatGbp(partnerIsa)})` : ''}, and{' '}
              <strong>{formatGbp(Math.max(0, totalProperty - totalMortgage))}</strong> in net property equity ({formatGbp(totalProperty)} gross property value less {formatGbp(totalMortgage)} outstanding mortgage).
            </p>
          </section>

          {/* Question 2: What happens if I continue as I am? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                2
              </span>
              What happens if I continue as I am?
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              Under your current savings trajectory and employer contributions, your liquid investment pot will grow to approximately{' '}
              <strong>{formatGbp(isRealTerms ? wealthAtRetirementReal : wealthAtRetirementNominal)}</strong> by age {retirementAge}. You will capture approximately <strong>{formatGbp(totalPensionsSavedTaxNominal)}</strong> in cumulative income tax relief through your workplace pension contributions.
            </p>
          </section>

          {/* Net Worth & Assets Trajectory Chart */}
          <div className="p-4 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="text-sm font-semibold text-slate-900 font-serif flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-800" /> Projected Net Worth & Asset Class Trajectory
              </h3>
              <div className="flex items-center gap-2 flex-wrap">
                {/* Presets */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={setAllAssets}
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                      isAllAssetsSelected
                        ? 'bg-slate-900 text-white'
                        : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                    }`}
                  >
                    All Assets
                  </button>
                  <button
                    type="button"
                    onClick={setLiquidOnly}
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                      isLiquidOnlySelected
                        ? 'bg-emerald-700 text-white'
                        : 'bg-white text-emerald-800 hover:bg-emerald-50 border border-emerald-300'
                    }`}
                    title="Isolate liquid wealth by removing property"
                  >
                    <span>💧 Liquid Only</span>
                  </button>
                </div>
                <span className="text-[11px] font-medium text-emerald-800 bg-emerald-100/60 px-2 py-0.5 rounded-md">
                  {isRealTerms ? "Real Terms (£ Today)" : "Nominal Terms (£ Future)"}
                </span>
              </div>
            </div>

            {/* DISTINCTIVE RESPONSIVE INTERACTIVE KEY */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:flex lg:flex-wrap gap-2 text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200/80">
              <button
                type="button"
                onClick={() => toggleAssetKey('pensionPot')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.pensionPot
                    ? 'bg-emerald-50/50 border-emerald-200 text-slate-900'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle DC Pensions"
              >
                <span className={`w-2.5 h-2.5 rounded bg-[#10B981] shrink-0 ${!visibleAssets.pensionPot ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] ${!visibleAssets.pensionPot ? 'line-through' : ''}`}>DC Pensions</span>
              </button>

              <button
                type="button"
                onClick={() => toggleAssetKey('isaBalance')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.isaBalance
                    ? 'bg-amber-50/50 border-amber-200 text-slate-900'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle ISAs"
              >
                <span className={`w-2.5 h-2.5 rounded bg-[#F59E0B] shrink-0 ${!visibleAssets.isaBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] ${!visibleAssets.isaBalance ? 'line-through' : ''}`}>ISAs</span>
              </button>

              <button
                type="button"
                onClick={() => toggleAssetKey('giaBalance')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.giaBalance
                    ? 'bg-blue-50/50 border-blue-200 text-slate-900'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle GIAs"
              >
                <span className={`w-2.5 h-2.5 rounded bg-[#3B82F6] shrink-0 ${!visibleAssets.giaBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] ${!visibleAssets.giaBalance ? 'line-through' : ''}`}>GIAs</span>
              </button>

              <button
                type="button"
                onClick={() => toggleAssetKey('cashBalance')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.cashBalance
                    ? 'bg-slate-50 border-slate-300 text-slate-900'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle Cash & NS&I"
              >
                <span className={`w-2.5 h-2.5 rounded bg-[#94A3B8] shrink-0 ${!visibleAssets.cashBalance ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] ${!visibleAssets.cashBalance ? 'line-through' : ''}`}>Cash & NS&I</span>
              </button>

              <button
                type="button"
                onClick={() => toggleAssetKey('propertyEquity')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.propertyEquity
                    ? 'bg-purple-50/60 border-purple-200 text-purple-950 font-bold'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle Property Equity (exclude to view liquid wealth)"
              >
                <span className={`w-2.5 h-2.5 rounded bg-[#8B5CF6] shrink-0 ${!visibleAssets.propertyEquity ? 'opacity-30' : ''}`} />
                <span className={`font-semibold text-[11px] ${!visibleAssets.propertyEquity ? 'line-through' : ''}`}>Property Equity</span>
                {!visibleAssets.propertyEquity && (
                  <span className="text-[9px] bg-purple-100 text-purple-700 px-1 rounded font-bold">Off</span>
                )}
              </button>

              <button
                type="button"
                onClick={() => toggleAssetKey('totalNetWorth')}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all cursor-pointer text-left ${
                  visibleAssets.totalNetWorth
                    ? 'bg-slate-900 border-slate-800 text-white'
                    : 'bg-slate-50 border-dashed border-slate-300 text-slate-400 opacity-60'
                }`}
                title="Toggle Trajectory Line"
              >
                <span className={`w-3.5 h-1 rounded-full bg-emerald-400 shrink-0 ${!visibleAssets.totalNetWorth ? 'opacity-30' : ''}`} />
                <span className={`font-bold text-[11px] ${!visibleAssets.totalNetWorth ? 'line-through text-slate-400' : 'text-white'}`}>
                  {isLiquidOnlySelected ? 'Liquid Wealth Line' : isAllAssetsSelected ? 'Total Net Worth' : 'Filtered Total'}
                </span>
              </button>
            </div>

            <div className="h-64 sm:h-72 lg:h-80 w-full pt-1">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData} margin={{ top: 12, right: 6, left: -16, bottom: 18 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis
                    dataKey="age"
                    tickLine={false}
                    axisLine={{ stroke: '#CBD5E1' }}
                    tick={{ fill: '#64748B', fontSize: 10 }}
                    interval="preserveStartEnd"
                    label={{ value: 'Client Age', position: 'insideBottom', offset: -10, fill: '#64748B', fontSize: 10 }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={{ stroke: '#CBD5E1' }}
                    tick={{ fill: '#64748B', fontSize: 10 }}
                    tickFormatter={(v) => formatGbp(v, true)}
                    width={46}
                  />
                  <Tooltip
                    formatter={(value: any, name: string) => [
                      formatGbp(Number(value)),
                      name === 'pensionPot'
                        ? 'DC Pensions'
                        : name === 'isaBalance'
                        ? 'ISAs'
                        : name === 'giaBalance'
                        ? 'GIAs'
                        : name === 'cashBalance'
                        ? 'Cash & NS&I'
                        : name === 'propertyEquity'
                        ? 'Property Equity'
                        : name === 'filteredNetWorth' || name === 'totalNetWorth'
                        ? isLiquidOnlySelected
                          ? 'Liquid Financial Wealth'
                          : isAllAssetsSelected
                          ? 'Total Net Worth'
                          : 'Filtered Total'
                        : name,
                    ]}
                    labelFormatter={(age) => {
                      const row = chartData.find((d) => d.age === age);
                      const totalVal = row?.filteredNetWorth ?? row?.totalNetWorth ?? 0;
                      return `Age ${age} · ${isLiquidOnlySelected ? 'Liquid Wealth' : isAllAssetsSelected ? 'Net Worth' : 'Filtered Total'}: ${formatGbp(totalVal)}`;
                    }}
                    contentStyle={{ backgroundColor: '#0F172A', color: '#F8FAFC', borderRadius: '8px', border: 'none', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' }}
                  />
                  {visibleAssets.pensionPot && <Bar dataKey="pensionPot" name="DC Pensions" stackId="assets" fill="#10B981" />}
                  {visibleAssets.isaBalance && <Bar dataKey="isaBalance" name="ISAs" stackId="assets" fill="#F59E0B" />}
                  {visibleAssets.giaBalance && <Bar dataKey="giaBalance" name="GIAs" stackId="assets" fill="#3B82F6" />}
                  {visibleAssets.cashBalance && <Bar dataKey="cashBalance" name="Cash & NS&I" stackId="assets" fill="#94A3B8" />}
                  {visibleAssets.propertyEquity && <Bar dataKey="propertyEquity" name="Property Equity" stackId="assets" fill="#8B5CF6" />}
                  {visibleAssets.totalNetWorth && (
                    <Line
                      type="monotone"
                      dataKey="filteredNetWorth"
                      name={isLiquidOnlySelected ? 'Liquid Financial Wealth' : isAllAssetsSelected ? 'Total Net Worth' : 'Filtered Total'}
                      stroke="#0F172A"
                      strokeWidth={2}
                      dot={false}
                    />
                  )}
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Question 3: When can I retire? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                3
              </span>
              When can I retire?
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              Your target retirement age of <strong>{retirementAge}</strong> {hasPartner && profile.personal.partnerTargetRetirementAge ? `(and partner retirement age ${profile.personal.partnerTargetRetirementAge})` : ''} is mathematically viable and sustainable. Between retirement and State Pension Age ({profile.statePension.primaryStatePensionAge}), bridge cashflow is efficiently funded through individual 25% tax-free lump sums (LSA) and ISA drawdowns, before guaranteed State Pension entitlements commence.
            </p>
          </section>

          {/* Question 4: Will my money last? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                4
              </span>
              Will my money last?
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              {isPlanFullyFunded
                ? `Yes. Your capital is projected to endure comfortably past age ${profile.personal.planningHorizonAge || 95}, leaving an estimated legacy estate of ${formatGbp(isRealTerms ? legacyWealthAt95Real : legacyWealthAt95Nominal)} (in today's money).`
                : `Under current spending targets, assets are projected to deplete around age ${ageFundsDepleted}. Adjusting spending by 5-10% or working 1 additional year closes this gap entirely.`}
            </p>
          </section>

          {/* Question 5: What are the major tax & economic risks? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                5
              </span>
              What are the major tax & economic risks?
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <strong className="text-slate-900 block font-semibold">April 2027 Pension IHT Inclusion</strong>
                <p className="text-slate-600">
                  Unspent DC pensions enter the 40% IHT estate from 6 April 2027. Your projected estate tax liability at life expectancy is approximately {formatGbp(isRealTerms ? projectedIhtLiabilityAtEndReal : legacyWealthAt95Nominal * 0.4)}.
                  {hasPartner && !isMarriedOrCivilPartner && (
                    <span className="text-amber-800 font-medium block mt-1">
                      Note: Because you are cohabiting without marriage or civil partnership, transfers between partners are not exempt from 40% IHT under statutory rules (s.18 IHTA 1984).
                    </span>
                  )}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <strong className="text-slate-900 block font-semibold">Sequence of Returns Risk</strong>
                <p className="text-slate-600">
                  A 25% market drawdown during the first 2 years of retirement would reduce your terminal buffer. Maintaining a 2-year cash reserve mitigates this risk.
                </p>
              </div>
            </div>

            {/* April 2027 IHT Derivation Table in Report */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 mt-3">
              <div className="flex items-center justify-between">
                <strong className="text-xs font-semibold text-slate-900">
                  April 2027 DC Pension IHT Inclusion — Exact Derivation
                </strong>
                <span className="text-[10px] text-amber-800 font-semibold bg-amber-100/70 px-2 py-0.5 rounded">
                  40% Statutory Rate
                </span>
              </div>
              <div className="overflow-x-auto text-[11px]">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-600">
                      <th className="py-1.5 px-2">Element</th>
                      <th className="py-1.5 px-2 text-right">Value</th>
                      <th className="py-1.5 px-2">Pre-April 2027</th>
                      <th className="py-1.5 px-2">Post-April 2027</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    <tr>
                      <td className="py-1.5 px-2">Non-Pension Estate (Property + ISAs + GIAs + Cash less Mortgage)</td>
                      <td className="py-1.5 px-2 text-right font-medium">{formatGbp(currentNetWorth - totalDcPension)}</td>
                      <td className="py-1.5 px-2 text-slate-500">In gross estate</td>
                      <td className="py-1.5 px-2 text-slate-900 font-medium">In gross estate</td>
                    </tr>
                    <tr className="bg-amber-50/50">
                      <td className="py-1.5 px-2 font-medium text-amber-900">DC Pension Pot Value (at death)</td>
                      <td className="py-1.5 px-2 text-right font-bold text-amber-950">{formatGbp(totalDcPension)}</td>
                      <td className="py-1.5 px-2 text-emerald-700 font-semibold">Excluded (0% IHT)</td>
                      <td className="py-1.5 px-2 text-amber-800 font-bold">Included (40% IHT)</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 px-2">Nil Rate Band (NRB £325k{isMarriedOrCivilPartner ? ' × 2' : ''}) + RNRB (£175k{isMarriedOrCivilPartner ? ' × 2' : ''})</td>
                      <td className="py-1.5 px-2 text-right text-emerald-700">-{formatGbp(ihtPost2027.totalAllowances)}</td>
                      <td className="py-1.5 px-2 text-slate-500">Applied to estate</td>
                      <td className="py-1.5 px-2 text-slate-700">Applied to aggregate estate</td>
                    </tr>
                    <tr className="font-semibold bg-slate-100 text-slate-900">
                      <td className="py-1.5 px-2">Net Estimated IHT Liability</td>
                      <td className="py-1.5 px-2 text-right text-amber-900 font-bold">{formatGbp(ihtPost2027.ihtLiability)}</td>
                      <td className="py-1.5 px-2 text-slate-600">{formatGbp(ihtPre2027.ihtLiability)}</td>
                      <td className="py-1.5 px-2 text-amber-900 font-bold">{formatGbp(ihtPost2027.ihtLiability)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Question 6: What practical actions should I take? */}
          <section className="space-y-3">
            <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-sans">
                6
              </span>
              Actionable Next Steps
            </h2>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Maximize Salary Sacrifice:</strong> Ensure workplace pension contributions use salary sacrifice to capture both higher rate tax relief and National Insurance savings.
                </span>
              </div>
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Stagger Lump Sum Allowance (LSA):</strong> Take your 25% tax-free pension cash in phased tranches {hasPartner ? 'across both individuals ' : ''}rather than a single lump sum to avoid holding unnecessary cash outside tax-free wrappers.
                </span>
              </div>
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800">
                <CheckCircle2 className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Preserve ISAs for Later Life:</strong> In light of the 2027 IHT rule, draw taxable pension income first within basic rate bands and keep ISAs growing tax-free.
                </span>
              </div>
            </div>
          </section>

          {/* Full Report: Year-by-Year Milestone Cashflow Ledger */}
          {reportMode === 'full' && (
            <section className="space-y-3 pt-4">
              <h3 className="text-base font-serif font-bold text-slate-900 flex items-center gap-2 border-b border-slate-200 pb-2">
                <Calendar className="w-4 h-4 text-emerald-800" />
                Lifetime Cashflow Projections & Drawdown Schedule (Key Milestones)
              </h3>
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                      <th className="py-2.5 px-3">Milestone Age</th>
                      <th className="py-2.5 px-3 text-right">Total Inflow</th>
                      <th className="py-2.5 px-3 text-right">Total Outflows</th>
                      <th className="py-2.5 px-3 text-right">Pension Draw</th>
                      <th className="py-2.5 px-3 text-right">ISA Draw</th>
                      <th className="py-2.5 px-3 text-right">GIA/Cash Draw</th>
                      <th className="py-2.5 px-3 text-right">Tax Paid</th>
                      <th className="py-2.5 px-3 text-right font-bold text-slate-900">Total Net Worth</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {milestoneYears.map((row) => (
                      <tr key={row.year} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-slate-900">Age {row.age} ({row.calendarYear})</div>
                          <span className="text-[10px] text-slate-500">
                            {row.age === profile.personal.currentAge
                              ? 'Today (Start)'
                              : row.age === profile.personal.targetRetirementAge
                              ? 'Target Retirement'
                              : row.age === profile.statePension.primaryStatePensionAge
                              ? 'State Pension Start'
                              : row.age === (profile.personal.planningHorizonAge || 95)
                              ? 'Legacy Horizon'
                              : 'Milestone'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                          {formatGbp(isRealTerms ? row.totalGrossInflowReal : row.totalGrossInflow)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                          {formatGbp(isRealTerms ? row.totalOutflowsReal : row.totalOutflows)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-emerald-800 font-medium">
                          {formatGbp(row.drawdownPensionTaxFree + row.drawdownPensionTaxable)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-amber-800 font-medium">
                          {formatGbp(row.drawdownIsa)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-blue-800 font-medium">
                          {formatGbp(row.drawdownGia + row.drawdownCash)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">
                          {formatGbp(row.totalTaxPaid)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-900 font-serif">
                          {formatGbp(isRealTerms ? row.totalNetWorthReal : row.totalNetWorthNominal)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>

        {/* Practice Contact & Analytical Planning Sign-off */}
        <div className="pt-6 border-t border-slate-200 space-y-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
            <div>
              <div className="font-serif font-bold text-slate-900 text-sm">
                {adviserDetails.firmName}
              </div>
              <div className="text-slate-600">
                {adviserDetails.adviserName} · {adviserDetails.adviserTitle}
              </div>
              {adviserDetails.officeAddress && (
                <div className="text-slate-500 text-[11px] mt-0.5">{adviserDetails.officeAddress}</div>
              )}
            </div>
            <div className="text-left sm:text-right text-slate-600 space-y-0.5 text-xs">
              <div>Email: <a href={`mailto:${adviserDetails.email}`} className="text-emerald-800 font-medium underline">{adviserDetails.email}</a></div>
              {adviserDetails.phone && <div>Tel: <span className="text-slate-900 font-medium">{adviserDetails.phone}</span></div>}
              {adviserDetails.website && <div>Web: <span className="text-slate-700">{adviserDetails.website}</span></div>}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>Aura Cashflow · UK Wealth & Retirement Planning Modeller (2026/27 Tax Engine)</span>
            <span>Confidential Client Document · {reportMode === 'full' ? 'Comprehensive Report' : 'Executive Summary'}</span>
          </div>

          <div className="text-[10px] text-slate-400 leading-relaxed border-t border-slate-100 pt-2">
            <strong>Important Notice:</strong> This cashflow plan is an analytical simulation tool illustrating financial projections under specified growth and inflation assumptions. Cashflow illustration is not a regulated financial intermediation activity under the Financial Services and Markets Act 2000 and does not require an FCA firm reference number. Past performance does not guarantee future results.
          </div>
        </div>
      </div>
    </div>
  );
};
