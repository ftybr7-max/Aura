/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — What-If Scenario Sandbox & Stress-Testing Lab
 * Guarantees 100% calculation consistency across Real Terms & Nominal Terms.
 */

import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  FlaskConical,
  RefreshCw,
  TrendingDown,
  TrendingUp,
  AlertOctagon,
  Home,
  HeartPulse,
  Coins,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  Sparkles,
  Layers,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { DEFAULT_WHAT_IF_MODIFIERS, runCashflowSimulation } from '../../aura/engine/cashflowEngine';

export const WhatIfLab: React.FC = () => {
  const { profile, activeModifiers, setModifiers, resetModifiers, isRealTerms } = useCashflow();

  // Baseline Simulation (No modifiers)
  const baselineResult = useMemo(() => {
    return runCashflowSimulation(profile, DEFAULT_WHAT_IF_MODIFIERS);
  }, [profile]);

  // Scenario Simulation (With active modifiers)
  const scenarioResult = useMemo(() => {
    return runCashflowSimulation(profile, activeModifiers);
  }, [profile, activeModifiers]);

  const formatGbp = (val: number, compact: boolean = false) => {
    if (compact) {
      if (Math.abs(val) >= 1000000) return `£${(val / 1000000).toFixed(2)}m`;
      if (Math.abs(val) >= 1000) return `£${Math.round(val / 1000)}k`;
    }
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Strictly respect isRealTerms for both baseline and scenario!
  const baselineWealthAtRetirement = isRealTerms
    ? baselineResult.wealthAtRetirementReal
    : baselineResult.wealthAtRetirementNominal;

  const scenarioWealthAtRetirement = isRealTerms
    ? scenarioResult.wealthAtRetirementReal
    : scenarioResult.wealthAtRetirementNominal;

  const baselineLegacyAt95 = isRealTerms
    ? baselineResult.legacyWealthAt95Real
    : baselineResult.legacyWealthAt95Nominal;

  const scenarioLegacyAt95 = isRealTerms
    ? scenarioResult.legacyWealthAt95Real
    : scenarioResult.legacyWealthAt95Nominal;

  const deltaRetirementWealth = scenarioWealthAtRetirement - baselineWealthAtRetirement;
  const deltaLegacyWealth = scenarioLegacyAt95 - baselineLegacyAt95;

  // Has any active modification
  const isModified =
    activeModifiers.retirementAgeOffset !== 0 ||
    activeModifiers.spendingChangePercent !== 0 ||
    activeModifiers.marketReturnOffsetPercent !== 0 ||
    activeModifiers.inflationRateOffsetPercent !== 0 ||
    activeModifiers.marketCrashAtRetirement ||
    activeModifiers.earlyDownsize ||
    activeModifiers.longTermCareCostShock;

  // Comparative Trajectory Chart Data
  const trajectoryChartData = baselineResult.years.map((baseYear, idx) => {
    const scenYear = scenarioResult.years[idx] || baseYear;
    return {
      age: baseYear.age,
      calendarYear: baseYear.calendarYear,
      baselineNetWorth: isRealTerms ? baseYear.totalNetWorthReal : baseYear.totalNetWorthNominal,
      scenarioNetWorth: isRealTerms ? scenYear.totalNetWorthReal : scenYear.totalNetWorthNominal,
      baselinePension: isRealTerms ? baseYear.pensionPotReal : baseYear.pensionPotNominal,
      scenarioPension: isRealTerms ? scenYear.pensionPotReal : scenYear.pensionPotNominal,
    };
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Sandbox Header & Quick Reset */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-serif font-semibold text-slate-900 flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-emerald-800" /> What-If Scenario Sandbox & Stress-Testing
            </h3>
            {isModified && (
              <span className="flex items-center gap-1 text-[11px] font-semibold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full border border-emerald-200">
                <Sliders className="w-3 h-3 text-emerald-700" /> Adjustments Active
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Simulate early retirement, spending adjustments, inflation surges, and severe sequence-of-returns market shocks.
          </p>
        </div>

        <button
          type="button"
          onClick={resetModifiers}
          disabled={!isModified}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all self-start sm:self-auto border ${
            isModified
              ? 'text-slate-800 bg-white hover:bg-slate-100 border-slate-300 shadow-2xs'
              : 'text-slate-400 bg-slate-50 border-slate-200 cursor-not-allowed'
          }`}
        >
          <RefreshCw className="w-3.5 h-3.5" /> Reset to Baseline Plan
        </button>
      </div>

      {/* 2. Side-by-Side Comparison KPI Tiles (Strictly Real/Nominal Consistent) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Retirement Age */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2 relative">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Retirement Age
            </span>
            {activeModifiers.retirementAgeOffset !== 0 && (
              <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded font-bold">
                Modified
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-serif text-slate-900">
              Age {scenarioResult.retirementAge}
            </span>
            {activeModifiers.retirementAgeOffset !== 0 && (
              <span className={`text-xs font-semibold ${activeModifiers.retirementAgeOffset < 0 ? 'text-emerald-700' : 'text-slate-500'}`}>
                ({activeModifiers.retirementAgeOffset > 0 ? `+${activeModifiers.retirementAgeOffset}` : activeModifiers.retirementAgeOffset} yrs)
              </span>
            )}
          </div>
          <span className="text-xs text-slate-400 block">
            Baseline: Age {profile.personal.targetRetirementAge}
          </span>
        </div>

        {/* Wealth at Retirement (Strictly consistent!) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Wealth at Retirement
            </span>
            <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded">
              {isRealTerms ? "Real (£ today)" : "Nominal (£ future)"}
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-serif text-slate-900">
              {formatGbp(scenarioWealthAtRetirement)}
            </span>
          </div>
          <div className="text-xs flex items-center justify-between text-slate-500">
            <span>Baseline: {formatGbp(baselineWealthAtRetirement)}</span>
            {deltaRetirementWealth !== 0 && (
              <span className={`font-semibold ${deltaRetirementWealth > 0 ? 'text-emerald-700' : 'text-red-600'}`}>
                {deltaRetirementWealth > 0 ? `+${formatGbp(deltaRetirementWealth)}` : formatGbp(deltaRetirementWealth)}
              </span>
            )}
          </div>
        </div>

        {/* Legacy Wealth at Age 95 (Strictly consistent!) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Legacy Wealth (Age 95)
            </span>
            <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded">
              {isRealTerms ? "Real (£ today)" : "Nominal (£ future)"}
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-serif text-slate-900">
              {formatGbp(scenarioLegacyAt95)}
            </span>
          </div>
          <div className="text-xs flex items-center justify-between text-slate-500">
            <span>Baseline: {formatGbp(baselineLegacyAt95)}</span>
            {deltaLegacyWealth !== 0 && (
              <span className={`font-semibold ${deltaLegacyWealth > 0 ? 'text-emerald-700' : 'text-red-600'}`}>
                {deltaLegacyWealth > 0 ? `+${formatGbp(deltaLegacyWealth)}` : formatGbp(deltaLegacyWealth)}
              </span>
            )}
          </div>
        </div>

        {/* Plan Longevity / Funding Status */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block">
            Plan Resilience
          </span>
          <div className="flex items-center gap-2">
            {scenarioResult.isPlanFullyFunded ? (
              <span className="text-2xl font-bold font-serif text-emerald-800 flex items-center gap-1.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 inline" /> Fully Funded
              </span>
            ) : (
              <span className="text-2xl font-bold font-serif text-amber-800 flex items-center gap-1.5">
                <AlertTriangle className="w-5 h-5 text-amber-600 inline" /> Depletes at {scenarioResult.ageFundsDepleted}
              </span>
            )}
          </div>
          <span className="text-xs text-slate-500 block">
            Modeled to Age {profile.personal.planningHorizonAge || 95}
          </span>
        </div>
      </div>

      {/* 3. STRESS-TEST & EVENT SHOCKS (POSITIONED HIGHER UP, ABOVE TRAJECTORY COMPARISON) */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-red-600" /> Stress-Test & Event Shocks
            </h4>
            <p className="text-xs text-slate-500">
              Apply macroeconomic sequence shocks, equity market downturns, and later-life healthcare events before inspecting trajectory trends.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 1. Market Crash Sequence Risk Shock */}
          <div className={`p-5 rounded-2xl border transition-all space-y-3 ${activeModifiers.marketCrashAtRetirement ? 'bg-red-50/70 border-red-300 shadow-2xs' : 'bg-slate-50 border-slate-200'}`}>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={activeModifiers.marketCrashAtRetirement}
                onChange={(e) => setModifiers((prev) => ({
                  ...prev,
                  marketCrashAtRetirement: e.target.checked,
                  marketCrashTiming: prev.marketCrashTiming || 'next_year',
                  marketCrashYear: prev.marketCrashYear || 2027,
                  marketCrashSeverityPercent: prev.marketCrashSeverityPercent ?? -25,
                }))}
                className="w-4 h-4 mt-0.5 text-red-600 rounded"
              />
              <div className="flex-1">
                <span className="text-xs font-bold text-slate-900 block flex items-center gap-1">
                  <AlertOctagon className="w-3.5 h-3.5 text-red-600" /> Market Crash Sequence Shock
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Simulate an equity downturn at a specific milestone year.
                </span>
              </div>
            </label>

            {activeModifiers.marketCrashAtRetirement && (
              <div className="pt-3 border-t border-red-200/80 space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Crash Timing
                  </label>
                  <select
                    value={activeModifiers.marketCrashTiming || 'next_year'}
                    onChange={(e) => setModifiers((prev) => ({
                      ...prev,
                      marketCrashTiming: e.target.value as any,
                    }))}
                    className="w-full rounded-xl border border-red-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    <option value="next_year">Next Year (2027)</option>
                    <option value="at_retirement">At Retirement (Age {profile.personal.targetRetirementAge})</option>
                    <option value="custom_year">Specific Year (from 2026 onwards)...</option>
                  </select>
                </div>

                {activeModifiers.marketCrashTiming === 'custom_year' && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-700">Specific Crash Year:</span>
                    <input
                      type="number"
                      min={2026}
                      max={2026 + (profile.personal.planningHorizonAge - profile.personal.currentAge)}
                      value={activeModifiers.marketCrashYear || 2027}
                      onChange={(e) => setModifiers((prev) => ({
                        ...prev,
                        marketCrashYear: Math.max(2026, parseInt(e.target.value) || 2027),
                      }))}
                      className="w-24 px-2.5 py-1 text-xs font-bold text-slate-900 bg-white border border-red-200 rounded-lg"
                    />
                  </div>
                )}

                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-slate-600">Crash Severity:</span>
                  <div className="flex gap-1.5">
                    {[-15, -25, -35, -50].map((sev) => (
                      <button
                        key={sev}
                        type="button"
                        onClick={() => setModifiers((prev) => ({ ...prev, marketCrashSeverityPercent: sev }))}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                          (activeModifiers.marketCrashSeverityPercent ?? -25) === sev
                            ? 'bg-red-700 text-white shadow-2xs'
                            : 'bg-white border border-red-200 text-red-900 hover:bg-red-100'
                        }`}
                      >
                        {sev}%
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. Property Downsizing */}
          <div className={`p-5 rounded-2xl border transition-all space-y-2 ${activeModifiers.earlyDownsize ? 'bg-emerald-50/70 border-emerald-300 shadow-2xs' : 'bg-slate-50 border-slate-200'}`}>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={activeModifiers.earlyDownsize}
                onChange={(e) => setModifiers((prev) => ({ ...prev, earlyDownsize: e.target.checked }))}
                className="w-4 h-4 mt-0.5 text-emerald-800 rounded"
              />
              <div>
                <span className="text-xs font-bold text-slate-900 block flex items-center gap-1">
                  <Home className="w-3.5 h-3.5 text-emerald-700" /> Property Downsizing
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Releases 40% equity at retirement age {profile.personal.targetRetirementAge} into liquid cash.
                </span>
              </div>
            </label>
          </div>

          {/* 3. Later Life Care Shock */}
          <div className={`p-5 rounded-2xl border transition-all space-y-2 ${activeModifiers.longTermCareCostShock ? 'bg-amber-50/70 border-amber-300 shadow-2xs' : 'bg-slate-50 border-slate-200'}`}>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={activeModifiers.longTermCareCostShock}
                onChange={(e) => setModifiers((prev) => ({ ...prev, longTermCareCostShock: e.target.checked }))}
                className="w-4 h-4 mt-0.5 text-amber-700 rounded"
              />
              <div>
                <span className="text-xs font-bold text-slate-900 block flex items-center gap-1">
                  <HeartPulse className="w-3.5 h-3.5 text-amber-700" /> Later Life Care Shock
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Adds +£55,000/yr (inflation-adjusted) nursing home fees at age 82–85.
                </span>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* 4. Visual Comparative Trajectory Chart (Baseline vs Scenario Net Worth) */}
      <div className="bg-white p-4 sm:p-6 lg:p-7 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-800 shrink-0" />
              <span>Net Worth Trajectory Comparison: Baseline vs Scenario</span>
            </h4>
            <p className="text-xs text-slate-500">
              Comparing your baseline financial trajectory against simulated What-If adjustments ({isRealTerms ? "Real Terms" : "Nominal Terms"}).
            </p>
          </div>
        </div>

        {/* DISTINCTIVE RESPONSIVE KEY */}
        <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/90 flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-lg border border-slate-200 shadow-2xs">
            <span className="w-5 h-0.5 border-t-2 border-dashed border-slate-400 shrink-0" />
            <span className="font-semibold text-slate-700">Baseline Trajectory</span>
          </div>
          <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-200 shadow-2xs">
            <span className="w-5 h-1 rounded-full bg-[#059669] shrink-0" />
            <span className="font-bold text-emerald-950">What-If Scenario Trajectory</span>
          </div>
        </div>

        <div className="h-72 sm:h-84 md:h-96 w-full pt-1">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={trajectoryChartData} margin={{ top: 12, right: 6, left: -16, bottom: 18 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis
                dataKey="age"
                tickLine={false}
                axisLine={{ stroke: '#CBD5E1' }}
                tick={{ fill: '#64748B', fontSize: 10 }}
                interval="preserveStartEnd"
                label={{ value: 'Client Age', position: 'insideBottom', offset: -12, fill: '#64748B', fontSize: 10 }}
              />
              <YAxis
                tickLine={false}
                axisLine={{ stroke: '#CBD5E1' }}
                tick={{ fill: '#64748B', fontSize: 10 }}
                tickFormatter={(v) => formatGbp(v, true)}
                width={46}
              />
              <Tooltip
                formatter={(value: any, name: string) => [
                  formatGbp(Number(value)),
                  name === 'baselineNetWorth'
                    ? 'Baseline Net Worth'
                    : name === 'scenarioNetWorth'
                    ? 'What-If Scenario Net Worth'
                    : name,
                ]}
                labelFormatter={(age) => `Age ${age}`}
                contentStyle={{ backgroundColor: '#0F172A', color: '#F8FAFC', borderRadius: '10px', border: 'none', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' }}
              />
              <Line
                type="monotone"
                dataKey="baselineNetWorth"
                name="Baseline Net Worth"
                stroke="#94A3B8"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="scenarioNetWorth"
                name="What-If Scenario Net Worth"
                stroke="#059669"
                strokeWidth={3}
                dot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4. Interactive Scenario Sliders & Adjustment Controls */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
          <Sliders className="w-4 h-4 text-emerald-800" /> Interactive Scenario Parameters
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Retirement Age Slider */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-slate-500" /> Retirement Age Adjustment
              </span>
              <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded">
                {activeModifiers.retirementAgeOffset > 0 ? `+${activeModifiers.retirementAgeOffset}` : activeModifiers.retirementAgeOffset} Years (Age {profile.personal.targetRetirementAge + activeModifiers.retirementAgeOffset})
              </span>
            </div>
            <input
              type="range"
              min={-5}
              max={5}
              step={1}
              value={activeModifiers.retirementAgeOffset}
              onChange={(e) =>
                setModifiers((prev) => ({ ...prev, retirementAgeOffset: parseInt(e.target.value) }))
              }
              className="w-full accent-emerald-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>-5 Years (Age {profile.personal.targetRetirementAge - 5})</span>
              <span>Baseline (Age {profile.personal.targetRetirementAge})</span>
              <span>+5 Years (Age {profile.personal.targetRetirementAge + 5})</span>
            </div>
          </div>

          {/* Spending Multiplier Slider */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-slate-500" /> Retirement Spending Adjustment
              </span>
              <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded">
                {activeModifiers.spendingChangePercent > 0 ? `+${activeModifiers.spendingChangePercent}` : activeModifiers.spendingChangePercent}%
              </span>
            </div>
            <input
              type="range"
              min={-30}
              max={30}
              step={5}
              value={activeModifiers.spendingChangePercent}
              onChange={(e) =>
                setModifiers((prev) => ({ ...prev, spendingChangePercent: parseInt(e.target.value) }))
              }
              className="w-full accent-emerald-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>-30% Frugal</span>
              <span>Baseline (0%)</span>
              <span>+30% Luxurious</span>
            </div>
          </div>

          {/* Investment Returns Offset */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <TrendingDown className="w-3.5 h-3.5 text-slate-500" /> Investment Market Returns Shift
              </span>
              <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded">
                {activeModifiers.marketReturnOffsetPercent > 0 ? `+${activeModifiers.marketReturnOffsetPercent}` : activeModifiers.marketReturnOffsetPercent}% / yr
              </span>
            </div>
            <input
              type="range"
              min={-3}
              max={3}
              step={0.5}
              value={activeModifiers.marketReturnOffsetPercent}
              onChange={(e) =>
                setModifiers((prev) => ({ ...prev, marketReturnOffsetPercent: parseFloat(e.target.value) }))
              }
              className="w-full accent-emerald-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>-3% Bear Market</span>
              <span>Baseline ({profile.assumptions.defaultEquityGrowthRatePercent}%)</span>
              <span>+3% Bull Market</span>
            </div>
          </div>

          {/* Inflation Rate Shift */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-500" /> Inflation Rate (CPI) Shift
              </span>
              <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded">
                {activeModifiers.inflationRateOffsetPercent > 0 ? `+${activeModifiers.inflationRateOffsetPercent}` : activeModifiers.inflationRateOffsetPercent}% (Total {(profile.assumptions.inflationRatePercent + activeModifiers.inflationRateOffsetPercent).toFixed(1)}%)
              </span>
            </div>
            <input
              type="range"
              min={-2}
              max={3}
              step={0.5}
              value={activeModifiers.inflationRateOffsetPercent}
              onChange={(e) =>
                setModifiers((prev) => ({ ...prev, inflationRateOffsetPercent: parseFloat(e.target.value) }))
              }
              className="w-full accent-emerald-800"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>-2% Disinflation</span>
              <span>Baseline ({profile.assumptions.inflationRatePercent}%)</span>
              <span>+3% Inflation Surge</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
