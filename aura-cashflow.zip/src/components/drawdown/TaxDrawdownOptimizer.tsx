/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Tax & Drawdown Sequencer & April 2027 IHT Analyzer
 */

import React, { useState } from 'react';
import {
  Coins,
  ShieldCheck,
  TrendingDown,
  Info,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  Sparkles,
  PieChart as PieIcon,
  Scale,
  Building,
  Briefcase,
  Layers,
  RotateCcw,
  Sliders,
  Wallet,
  Check,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { UK_TAX_CONSTANTS, calculateInheritanceTax } from '../../aura/engine/taxEngine';
import { GiftingIhtHub } from '../gifting/GiftingIhtHub';
import { DrawdownPotKey, DrawdownStrategy, SpecialistInvestmentType } from '../../types/cashflow';

export const TaxDrawdownOptimizer: React.FC = () => {
  const { profile, simulationResult, isRealTerms, updateAssumptions } = useCashflow();

  const hasPartner = profile.personal.hasPartner;
  const isMarriedOrCivilPartner = hasPartner && (profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType);

  // Asset Attributions
  const primaryDcPension = profile.dcPensions.filter((p) => p.owner !== 'partner').reduce((sum, p) => sum + p.currentPotValue, 0);
  const partnerDcPension = profile.dcPensions.filter((p) => p.owner === 'partner').reduce((sum, p) => sum + p.currentPotValue, 0);
  const totalDcPension = primaryDcPension + partnerDcPension;

  const primaryIsa = profile.isas.filter((i) => i.owner !== 'partner').reduce((sum, i) => sum + i.balance, 0);
  const partnerIsa = profile.isas.filter((i) => i.owner === 'partner').reduce((sum, i) => sum + i.balance, 0);
  const totalIsa = primaryIsa + partnerIsa;

  const totalGia = profile.gias.reduce((sum, g) => sum + g.balance, 0);
  const totalCash = profile.cashAccounts.reduce((sum, c) => sum + c.balance, 0);
  const totalProperty = profile.properties.reduce((sum, p) => sum + p.currentValue, 0);
  const totalMortgage = profile.mortgages.reduce((sum, m) => sum + m.outstandingBalance, 0);

  // Available 25% Tax-Free Cash under LSA (calculated individually per UK law)
  const primaryLsaTaxFree = Math.min(primaryDcPension * 0.25, UK_TAX_CONSTANTS.LUMP_SUM_ALLOWANCE);
  const partnerLsaTaxFree = hasPartner ? Math.min(partnerDcPension * 0.25, UK_TAX_CONSTANTS.LUMP_SUM_ALLOWANCE) : 0;
  const totalAvailableLsaTaxFree = primaryLsaTaxFree + partnerLsaTaxFree;

  // IHT Comparison (Pre-2027 vs Post-April 2027)
  const ihtUnderCurrentRules = calculateInheritanceTax({
    propertyValue: totalProperty,
    liquidAssets: totalIsa + totalGia + totalCash,
    dcPensionPot: totalDcPension,
    mortgageDebt: totalMortgage,
    hasSpouseOrCivilPartner: isMarriedOrCivilPartner,
    isPostApril2027: false,
    includePensionsInIhtPost2027: false,
  });

  const ihtPostApril2027 = calculateInheritanceTax({
    propertyValue: totalProperty,
    liquidAssets: totalIsa + totalGia + totalCash,
    dcPensionPot: totalDcPension,
    mortgageDebt: totalMortgage,
    hasSpouseOrCivilPartner: isMarriedOrCivilPartner,
    isPostApril2027: true,
    includePensionsInIhtPost2027: true,
  });

  const additionalIhtFrom2027Rule = Math.max(0, ihtPostApril2027.ihtLiability - ihtUnderCurrentRules.ihtLiability);

  const formatGbp = (val: number) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Overview Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-xl font-serif font-semibold text-slate-900 flex items-center gap-2">
              <Coins className="w-5 h-5 text-emerald-800" /> UK Tax-Optimised Drawdown & Estate Strategy
            </h3>
            <p className="text-sm text-slate-600 mt-1 leading-relaxed max-w-3xl">
              Coordinating individual 25% tax-free pension cash (LSA), Personal Allowances (£12,570 each), ISAs, and capital gains across {hasPartner ? 'both individuals' : 'your plan'} to minimize lifetime tax and navigate the April 2027 Pension Inheritance Tax reform.
            </p>
          </div>
          <div className="hidden sm:block text-right">
            <span className="text-xs text-slate-500 block">Lump Sum Allowance (LSA)</span>
            <span className="text-lg font-bold font-serif text-emerald-950">
              {hasPartner ? '2 × £268,275 Cap' : '£268,275 Cap'}
            </span>
          </div>
        </div>

        {/* Key Allowances Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium block">
              {hasPartner ? 'Household Personal Allowance' : 'Personal Allowance'}
            </span>
            <span className="text-base font-bold text-slate-900 font-serif mt-0.5 block">
              {hasPartner ? '£25,140 / yr' : '£12,570 / yr'}
            </span>
            <span className="text-[11px] text-slate-500">
              {hasPartner ? '2 × £12,570 independent zero-rate bands' : '0% tax band on income'}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium block">25% Tax-Free Pension (LSA)</span>
            <span className="text-base font-bold text-emerald-800 font-serif mt-0.5 block">
              {formatGbp(totalAvailableLsaTaxFree)}
            </span>
            <span className="text-[11px] text-emerald-700">
              {hasPartner ? `Primary: ${formatGbp(primaryLsaTaxFree)} · Partner: ${formatGbp(partnerLsaTaxFree)}` : 'Available from current pot'}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium block">Annual ISA Allowance</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-0.5 block">
              {hasPartner ? '£40,000 / yr' : '£20,000 / yr'}
            </span>
            <span className="text-[11px] text-slate-500">
              {hasPartner ? '£20,000 individual capacity each' : '100% tax-free growth'}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium block">IHT Estate Exemption</span>
            <span className="text-base font-bold text-slate-900 font-serif mt-0.5 block">
              {isMarriedOrCivilPartner ? '£1,000,000' : '£500,000'}
            </span>
            <span className="text-[11px] text-slate-500">
              {isMarriedOrCivilPartner
                ? 'NRB (£325k×2) + RNRB (£175k×2)'
                : hasPartner
                ? 'Unmarried: No spousal transfer (s.18)'
                : 'NRB (£325k) + RNRB (£175k)'}
            </span>
          </div>
        </div>
      </div>

      {/* Individual Wealth Allocation Card (when partner is configured) */}
      {hasPartner && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-emerald-800" /> Individual Ownership & Asset Attribution
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200/80 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                {profile.personal.fullName || 'Primary Individual'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div>
                  <span className="text-slate-500 block">DC Pension Pot:</span>
                  <span className="font-semibold text-slate-900">{formatGbp(primaryDcPension)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">ISA Holdings:</span>
                  <span className="font-semibold text-slate-900">{formatGbp(primaryIsa)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">25% LSA Available:</span>
                  <span className="font-semibold text-emerald-800">{formatGbp(primaryLsaTaxFree)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Tax Region:</span>
                  <span className="font-semibold text-slate-900 capitalize">{profile.personal.taxRegion}</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-200/80 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                {profile.personal.partnerName || 'Partner'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div>
                  <span className="text-slate-500 block">DC Pension Pot:</span>
                  <span className="font-semibold text-slate-900">{formatGbp(partnerDcPension)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">ISA Holdings:</span>
                  <span className="font-semibold text-slate-900">{formatGbp(partnerIsa)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">25% LSA Available:</span>
                  <span className="font-semibold text-indigo-800">{formatGbp(partnerLsaTaxFree)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Tax Region:</span>
                  <span className="font-semibold text-slate-900 capitalize">{profile.personal.partnerTaxRegion || profile.personal.taxRegion}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. April 2027 Pension IHT Impact Deep Dive & Detailed Mathematical Derivation */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-slate-900 font-serif">
                April 2027 Pension IHT Reform Analysis & Derivation
              </h4>
              <p className="text-xs text-slate-500">
                UK Autumn Budget 2024 legislated reform (Statutory inclusion effective 6 April 2027)
              </p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 font-medium border border-amber-200 self-start sm:self-auto">
            Statutory 40% IHT Rules
          </span>
        </div>

        <p className="text-sm text-slate-600 leading-relaxed">
          Historically, UK Defined Contribution pensions sat outside the estate for Inheritance Tax. From <strong>6 April 2027</strong>, unspent DC pension pots and death benefits are brought into the gross estate for 40% Inheritance Tax above available statutory allowances.
        </p>

        {/* 3 Core Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block">
              Pre-2027 Historical Rules
            </span>
            <span className="text-2xl font-bold font-serif text-slate-900 block">
              {formatGbp(ihtUnderCurrentRules.ihtLiability)}
            </span>
            <p className="text-xs text-slate-600">
              Pensions excluded from gross taxable estate (£{Math.round(totalDcPension).toLocaleString('en-GB')} pot shielded).
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-800 block">
              Post-April 2027 Legislated Rules
            </span>
            <span className="text-2xl font-bold font-serif text-amber-950 block">
              {formatGbp(ihtPostApril2027.ihtLiability)}
            </span>
            <p className="text-xs text-amber-800">
              Includes unspent DC pension pots within your taxable estate.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-emerald-950 text-white space-y-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300 block">
              Strategic Exposure
            </span>
            <span className="text-xl font-bold font-serif text-emerald-100 block">
              +{formatGbp(additionalIhtFrom2027Rule)} Exposure
            </span>
            <p className="text-xs text-emerald-200/90 leading-relaxed">
              <strong>Optimal Action:</strong> Drawing taxable pension income earlier to fund living costs or gifting strategy preserves your 100% tax-free ISA pot for heirs.
            </p>
          </div>
        </div>

        {/* Step-by-Step Derivation Breakdown Table */}
        <div className="mt-4 pt-4 border-t border-slate-200 space-y-3">
          <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-700">
            Step-by-Step Estate Tax Derivation (Current Snapshot vs April 2027)
          </h5>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                  <th className="py-2.5 px-3 font-semibold">Estate Component</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Value</th>
                  <th className="py-2.5 px-3 font-semibold">Pre-2027 Treatment</th>
                  <th className="py-2.5 px-3 font-semibold">Post-April 2027 Treatment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr>
                  <td className="py-2 px-3 font-medium">Gross Property Value</td>
                  <td className="py-2 px-3 text-right font-semibold">{formatGbp(totalProperty)}</td>
                  <td className="py-2 px-3 text-slate-500">In Gross Estate</td>
                  <td className="py-2 px-3 text-slate-900 font-medium">In Gross Estate</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-medium">Less: Mortgage Debt</td>
                  <td className="py-2 px-3 text-right font-semibold text-red-600">-{formatGbp(totalMortgage)}</td>
                  <td className="py-2 px-3 text-slate-500">Deductible debt</td>
                  <td className="py-2 px-3 text-slate-900 font-medium">Deductible debt</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-medium">Liquid Investments (ISAs, GIAs, Cash)</td>
                  <td className="py-2 px-3 text-right font-semibold">{formatGbp(totalIsa + totalGia + totalCash)}</td>
                  <td className="py-2 px-3 text-slate-500">In Gross Estate</td>
                  <td className="py-2 px-3 text-slate-900 font-medium">In Gross Estate</td>
                </tr>
                <tr className="bg-amber-50/50">
                  <td className="py-2 px-3 font-semibold text-amber-900">Defined Contribution (DC) Pension Pots</td>
                  <td className="py-2 px-3 text-right font-bold text-amber-950">{formatGbp(totalDcPension)}</td>
                  <td className="py-2 px-3 text-emerald-700 font-semibold">100% EXCLUDED (0% IHT)</td>
                  <td className="py-2 px-3 text-amber-800 font-bold">100% INCLUDED in Gross Estate</td>
                </tr>
                <tr className="font-semibold bg-slate-50">
                  <td className="py-2.5 px-3">Total Gross Estate at Death</td>
                  <td className="py-2.5 px-3 text-right font-bold">
                    {formatGbp(totalProperty - totalMortgage + totalIsa + totalGia + totalCash + totalDcPension)}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {formatGbp(totalProperty - totalMortgage + totalIsa + totalGia + totalCash)} (excl. pension)
                  </td>
                  <td className="py-2.5 px-3 text-amber-900 font-bold">
                    {formatGbp(totalProperty - totalMortgage + totalIsa + totalGia + totalCash + totalDcPension)}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3">Less: Nil Rate Band (NRB £325k{isMarriedOrCivilPartner ? ' × 2' : ''})</td>
                  <td className="py-2 px-3 text-right text-emerald-700">-{formatGbp(ihtPostApril2027.nilRateBandAvailable)}</td>
                  <td className="py-2 px-3 text-slate-500">Applied to non-pension estate</td>
                  <td className="py-2 px-3 text-slate-700">Applied across aggregate estate</td>
                </tr>
                <tr>
                  <td className="py-2 px-3">Less: Residence Nil Rate Band (RNRB £175k{isMarriedOrCivilPartner ? ' × 2' : ''})</td>
                  <td className="py-2 px-3 text-right text-emerald-700">-{formatGbp(ihtPostApril2027.residenceNilRateBandAvailable)}</td>
                  <td className="py-2 px-3 text-slate-500">Applied to main residence</td>
                  <td className="py-2 px-3 text-slate-700">Subject to £2m taper threshold</td>
                </tr>
                <tr className="bg-slate-100 font-bold text-slate-900">
                  <td className="py-2.5 px-3">Net Taxable Estate at 40%</td>
                  <td className="py-2.5 px-3 text-right text-amber-900 font-bold">
                    {formatGbp(ihtPostApril2027.taxableEstate)}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatGbp(ihtUnderCurrentRules.taxableEstate)}</td>
                  <td className="py-2.5 px-3 text-amber-900">{formatGbp(ihtPostApril2027.taxableEstate)}</td>
                </tr>
                <tr className="bg-slate-900 text-white font-bold">
                  <td className="py-2.5 px-3">Final Statutory IHT Liability (40%)</td>
                  <td className="py-2.5 px-3 text-right text-emerald-300 text-sm">
                    {formatGbp(ihtPostApril2027.ihtLiability)}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">{formatGbp(ihtUnderCurrentRules.ihtLiability)}</td>
                  <td className="py-2.5 px-3 text-amber-300 font-bold">{formatGbp(ihtPostApril2027.ihtLiability)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 3. Capital Gains Tax (CGT) & Cost Basis Liability Analyzer */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <Scale className="w-5 h-5 text-emerald-800" /> Capital Gains Tax (CGT) & Cost Basis Analyzer
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Pulling through all taxable accounts (GIAs, Direct Shares PLC, Private Shares, Specialist Holdings & Non-Primary Properties). Evaluated against the UK £3,000 annual exemption (£6,000 married) and 18% / 24% tax bands.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
              CGT Allowance: {hasPartner ? '£6,000 (2 × £3,000)' : '£3,000 / yr'}
            </span>
          </div>
        </div>

        {/* Missing Cost Price Red Warning Alert */}
        {(() => {
          // Identify taxable items with missing cost basis
          const missingCostItems = [
            ...profile.gias.filter((g) => g.balance > 0 && (!g.costBasis || g.costBasis === 0)).map((g) => ({
              name: g.label || 'GIA Account',
              type: 'General Investment Account',
              value: g.balance,
            })),
            ...(profile.otherInvestments || [])
              .filter((i) => i.balance > 0 && (!i.costBasis || i.costBasis === 0))
              .map((i) => ({
                name: i.label || 'Specialist Investment',
                type: (i.investmentType || 'Specialist').toUpperCase(),
                value: i.balance,
              })),
            ...profile.properties
              .filter((p) => !p.isPrimaryResidence && p.currentValue > 0 && (!p.costBasis || p.costBasis === 0))
              .map((p) => ({
                name: p.label || 'Secondary Property',
                type: 'Non-Primary Residence / Buy-to-Let',
                value: p.currentValue,
              })),
          ];

          if (missingCostItems.length > 0) {
            return (
              <div className="p-5 rounded-2xl bg-red-50/90 border-2 border-red-300 text-red-950 space-y-3 shadow-xs">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-red-100 rounded-xl text-red-700 shrink-0 mt-0.5">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div className="space-y-1.5 flex-1">
                    <h5 className="font-bold text-red-950 text-sm">
                      ⚠️ Warning: Acquisition Cost Price Missing ({missingCostItems.length} {missingCostItems.length === 1 ? 'account' : 'accounts'} detected)
                    </h5>
                    <p className="text-xs text-red-900 leading-relaxed">
                      No acquisition cost price (cost basis) has been entered for the following taxable holdings. For these accounts, the unrealised capital gain and estimated CGT liability are calculated assuming a <strong>£0 cost base (100% of current value taxable)</strong>, which may significantly overestimate your true tax liability.
                    </p>
                    <div className="pt-2 flex flex-wrap gap-2">
                      {missingCostItems.map((item, idx) => (
                        <span
                          key={idx}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-red-100/90 text-red-900 text-xs font-semibold border border-red-300"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                          {item.name} ({item.type} · {formatGbp(item.value)})
                        </span>
                      ))}
                    </div>
                    <p className="text-[11px] text-red-800 font-medium pt-1">
                      💡 <em>Action required: Head to the <strong>Financial Profile</strong> tab to input original purchase costs or probate base values.</em>
                    </p>
                  </div>
                </div>
              </div>
            );
          }
          return null;
        })()}

        {/* CGT Calculations & High-Level Summary */}
        {(() => {
          // Gather all items
          interface CgtEntry {
            id: string;
            label: string;
            typeLabel: string;
            owner: string;
            currentValue: number;
            costBasis: number;
            hasCostBasis: boolean;
            gain: number;
            isExempt: boolean;
            exemptBadge?: string;
            taxableGain: number;
          }

          const entries: CgtEntry[] = [];

          profile.gias.forEach((g) => {
            const hasCost = g.costBasis !== undefined && g.costBasis !== null && g.costBasis > 0;
            const cost = hasCost ? g.costBasis : 0;
            const gain = Math.max(0, g.balance - cost);
            entries.push({
              id: g.id,
              label: g.label || 'General Investment Account (GIA)',
              typeLabel: 'GIA (Taxable Portfolio)',
              owner: g.owner === 'partner' ? (profile.personal.partnerName || 'Partner') : g.owner === 'joint' ? 'Joint' : (profile.personal.fullName || 'Primary'),
              currentValue: g.balance,
              costBasis: cost,
              hasCostBasis: hasCost,
              gain,
              isExempt: false,
              taxableGain: gain,
            });
          });

          (profile.otherInvestments || []).forEach((item) => {
            const hasCost = item.costBasis !== undefined && item.costBasis !== null && item.costBasis > 0;
            const cost = hasCost ? item.costBasis : 0;
            const gain = Math.max(0, item.balance - cost);
            const type = item.investmentType || 'other';

            let isExempt = false;
            let exemptBadge = '';
            let typeLabel = 'Specialist Investment';

            if (type === 'vct') {
              typeLabel = 'VCT (Venture Capital Trust)';
              isExempt = true;
              exemptBadge = '100% CGT Exempt';
            } else if (type === 'eis') {
              typeLabel = 'EIS (Enterprise Investment Scheme)';
              isExempt = true;
              exemptBadge = '100% CGT Exempt (3+ yrs)';
            } else if (type === 'seis') {
              typeLabel = 'SEIS (Seed Enterprise Scheme)';
              isExempt = true;
              exemptBadge = '100% CGT Exempt + 50% Reinvestment Relief';
            } else if (type === 'direct_shares_plc') {
              typeLabel = 'Direct Shares PLC (Public Equities)';
              isExempt = false;
            } else if (type === 'direct_shares_private') {
              typeLabel = 'Direct Shares Private (Unquoted Equities)';
              isExempt = false;
            } else {
              typeLabel = 'Other Alternative Investment';
              isExempt = false;
            }

            entries.push({
              id: item.id,
              label: item.label || typeLabel,
              typeLabel,
              owner: item.owner === 'partner' ? (profile.personal.partnerName || 'Partner') : item.owner === 'joint' ? 'Joint' : (profile.personal.fullName || 'Primary'),
              currentValue: item.balance,
              costBasis: cost,
              hasCostBasis: hasCost,
              gain,
              isExempt,
              exemptBadge,
              taxableGain: isExempt ? 0 : gain,
            });
          });

          profile.properties
            .filter((p) => !p.isPrimaryResidence)
            .forEach((prop) => {
              const hasCost = prop.costBasis !== undefined && prop.costBasis !== null && prop.costBasis > 0;
              const cost = hasCost ? prop.costBasis : 0;
              const gain = Math.max(0, prop.currentValue - cost);

              entries.push({
                id: prop.id,
                label: prop.label || 'Buy-to-Let Property',
                typeLabel: 'Non-Primary Residential Property',
                owner: prop.owner === 'partner' ? (profile.personal.partnerName || 'Partner') : prop.owner === 'joint' ? 'Joint' : (profile.personal.fullName || 'Primary'),
                currentValue: prop.currentValue,
                costBasis: cost,
                hasCostBasis: hasCost,
                gain,
                isExempt: false,
                taxableGain: gain,
              });
            });

          const totalCurrentValue = entries.reduce((s, e) => s + e.currentValue, 0);
          const totalCostBasis = entries.reduce((s, e) => s + e.costBasis, 0);
          const totalGrossGain = entries.reduce((s, e) => s + e.gain, 0);
          const totalTaxableGain = entries.reduce((s, e) => s + e.taxableGain, 0);

          const cgtAnnualAllowance = hasPartner ? 6000 : 3000;
          const netTaxableGainAfterAllowance = Math.max(0, totalTaxableGain - cgtAnnualAllowance);

          const estTaxBasicRate18 = netTaxableGainAfterAllowance * 0.18;
          const estTaxHigherRate24 = netTaxableGainAfterAllowance * 0.24;

          if (entries.length === 0) {
            return (
              <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-2">
                <p className="text-sm font-semibold text-slate-700">No Taxable Unwrapped Assets Configured</p>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  You currently have no General Investment Accounts (GIAs), Direct Shares, Specialist Investments, or Non-Primary Properties. All your wealth is held in 100% CGT-exempt structures (Pensions, ISAs, or Primary UK Residence with Private Residence Relief).
                </p>
              </div>
            );
          }

          return (
            <div className="space-y-6">
              {/* Metric Summary Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-xs text-slate-500 font-medium block">Total Taxable Asset Value</span>
                  <span className="text-lg font-bold text-slate-900 font-serif mt-1 block">
                    {formatGbp(totalCurrentValue)}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Cost Base: {formatGbp(totalCostBasis)}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-xs text-emerald-800 font-medium block">Total Unrealised Capital Gain</span>
                  <span className="text-lg font-bold text-emerald-950 font-serif mt-1 block">
                    {formatGbp(totalGrossGain)}
                  </span>
                  <span className="text-[11px] text-emerald-700">
                    Exempt gains: {formatGbp(totalGrossGain - totalTaxableGain)}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-xs text-amber-800 font-medium block">Net Taxable (Post-Allowance)</span>
                  <span className="text-lg font-bold text-amber-950 font-serif mt-1 block">
                    {formatGbp(netTaxableGainAfterAllowance)}
                  </span>
                  <span className="text-[11px] text-amber-700">
                    After £{cgtAnnualAllowance.toLocaleString('en-GB')} annual exemption
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 text-white">
                  <span className="text-xs text-slate-400 font-medium block">Est. CGT Liability (Disposal)</span>
                  <span className="text-lg font-bold text-emerald-300 font-serif mt-1 block">
                    {formatGbp(estTaxHigherRate24)}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Basic: {formatGbp(estTaxBasicRate18)} (18%) · Higher: {formatGbp(estTaxHigherRate24)} (24%)
                  </span>
                </div>
              </div>

              {/* Detailed Breakdown Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-3.5">Asset / Holding Name</th>
                      <th className="py-3 px-3">Type</th>
                      <th className="py-3 px-3">Owner</th>
                      <th className="py-3 px-3 text-right">Current Value</th>
                      <th className="py-3 px-3 text-right">Cost Basis</th>
                      <th className="py-3 px-3 text-right">Unrealised Gain</th>
                      <th className="py-3 px-3 text-center">Tax Status</th>
                      <th className="py-3 px-3 text-right">Est. CGT (24%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    {entries.map((entry) => {
                      const estTax = entry.isExempt ? 0 : entry.taxableGain * 0.24;
                      return (
                        <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-2.5 px-3.5">
                            <div className="font-semibold text-slate-900">{entry.label}</div>
                            {!entry.hasCostBasis && (
                              <span className="text-[10px] text-red-600 font-bold">
                                ⚠️ No cost basis entered (assumed £0)
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-slate-600 text-[11px]">{entry.typeLabel}</td>
                          <td className="py-2.5 px-3 text-slate-600">{entry.owner}</td>
                          <td className="py-2.5 px-3 text-right font-semibold text-slate-900">
                            {formatGbp(entry.currentValue)}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            {entry.hasCostBasis ? (
                              formatGbp(entry.costBasis)
                            ) : (
                              <span className="text-red-600 font-bold">£0 (Missing)</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-800">
                            +{formatGbp(entry.gain)}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            {entry.isExempt ? (
                              <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 border border-teal-200">
                                {entry.exemptBadge || 'Exempt'}
                              </span>
                            ) : (
                              <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-900 border border-amber-200">
                                Taxable (18%/24%)
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                            {entry.isExempt ? '£0 (Exempt)' : formatGbp(estTax)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t-2 border-slate-300 text-slate-900">
                      <td className="py-3 px-3.5" colSpan={3}>
                        Total Unrealised Gains & Portfolio CGT Exposure
                      </td>
                      <td className="py-3 px-3 text-right">{formatGbp(totalCurrentValue)}</td>
                      <td className="py-3 px-3 text-right">{formatGbp(totalCostBasis)}</td>
                      <td className="py-3 px-3 text-right text-emerald-800">+{formatGbp(totalGrossGain)}</td>
                      <td className="py-3 px-3 text-center text-xs text-slate-500">
                        Less £{cgtAnnualAllowance.toLocaleString('en-GB')} Exemption
                      </td>
                      <td className="py-3 px-3 text-right text-amber-950 text-sm">
                        {formatGbp(estTaxHigherRate24)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Statutory Tax Advice & Optimization Strategies */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs text-slate-600 leading-relaxed">
                <h5 className="font-semibold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                  Statutory UK CGT Planning Strategies (2026/27 Tax Year)
                </h5>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <li className="p-3 rounded-lg bg-white border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-semibold">1. Bed & ISA Annual Allowance Transfer</strong>
                    <span>
                      Crystallise up to £3,000 of gains annually (£6,000 for couples) within the nil-rate CGT allowance and transfer the proceeds directly into your ISAs to shelter future growth from both CGT and dividend tax forever.
                    </span>
                  </li>
                  <li className="p-3 rounded-lg bg-white border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-semibold">2. Inter-Spousal Transfer (s.58 TCGA 1992)</strong>
                    <span>
                      Married couples and civil partners can transfer assets at "no gain, no loss" prior to disposal, effectively doubling your annual exemption (£6,000) and utilizing the lower 18% basic rate band of the lower-earning partner.
                    </span>
                  </li>
                  <li className="p-3 rounded-lg bg-white border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-semibold">3. EIS / SEIS Capital Gains Deferral & Reinvestment</strong>
                    <span>
                      Gains realized from shares or residential property can be deferred into Enterprise Investment Schemes (EIS) or receive 50% exemption via Seed EIS (SEIS) reinvestment relief.
                    </span>
                  </li>
                  <li className="p-3 rounded-lg bg-white border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-semibold">4. Staged Disposal Tranching</strong>
                    <span>
                      Spread large disposals across multiple tax years (e.g. across 5th/6th April tax year-ends) to utilize multiple annual exempt amounts and prevent pushing income into the 24% higher CGT bracket.
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          );
        })()}
      </div>

      {/* 4. Bespoke Drawdown Sequence Strategy Selector */}
      {(() => {
        const activeStrategy: DrawdownStrategy = profile.assumptions.drawdownStrategy || 'tax_optimised';

        const defaultSequenceMap: Record<DrawdownStrategy, DrawdownPotKey[]> = {
          tax_optimised: ['cash', 'gia', 'pension', 'isa'],
          pension_first: ['pension', 'gia', 'isa', 'cash'],
          isa_first: ['isa', 'cash', 'gia', 'pension'],
          cash_first: ['cash', 'isa', 'gia', 'pension'],
          pro_rata: ['cash', 'gia', 'pension', 'isa'],
          custom: ['cash', 'gia', 'pension', 'isa'],
        };

        const activeSequence: DrawdownPotKey[] =
          activeStrategy === 'custom' && profile.assumptions.customDrawdownOrder && profile.assumptions.customDrawdownOrder.length === 4
            ? profile.assumptions.customDrawdownOrder
            : defaultSequenceMap[activeStrategy] || ['cash', 'gia', 'pension', 'isa'];

        // Handler to switch preset strategy
        const handleSelectPreset = (stratId: DrawdownStrategy) => {
          const newOrder = defaultSequenceMap[stratId] || ['cash', 'gia', 'pension', 'isa'];
          updateAssumptions({
            ...profile.assumptions,
            drawdownStrategy: stratId,
            customDrawdownOrder: newOrder,
          });
        };

        // Handler to reorder pots (move pot at index up or down)
        const handleMovePot = (index: number, direction: 'up' | 'down') => {
          const targetIndex = direction === 'up' ? index - 1 : index + 1;
          if (targetIndex < 0 || targetIndex >= activeSequence.length) return;

          const updated = [...activeSequence];
          const temp = updated[index];
          updated[index] = updated[targetIndex];
          updated[targetIndex] = temp;

          // Check if new sequence matches any standard preset
          let detectedStrategy: DrawdownStrategy = 'custom';
          for (const [key, seq] of Object.entries(defaultSequenceMap)) {
            if (key !== 'custom' && key !== 'pro_rata' && seq.join(',') === updated.join(',')) {
              detectedStrategy = key as DrawdownStrategy;
              break;
            }
          }

          updateAssumptions({
            ...profile.assumptions,
            drawdownStrategy: detectedStrategy,
            customDrawdownOrder: updated,
          });
        };

        // Pot metadata definitions
        const potMetadata: Record<
          DrawdownPotKey,
          {
            title: string;
            subtitle: string;
            icon: React.ComponentType<{ className?: string }>;
            balance: number;
            taxBadge: string;
            badgeColor: string;
            cardBg: string;
            borderAccent: string;
            pillColor: string;
            rationales: Record<DrawdownStrategy, string>;
          }
        > = {
          cash: {
            title: 'Liquid Cash Buffer',
            subtitle: 'Bank Accounts & Cash ISAs',
            icon: Coins,
            balance: totalCash,
            taxBadge: '0% Tax / PSA Interest',
            badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
            cardBg: 'bg-blue-50/40 border-blue-200 hover:border-blue-300',
            borderAccent: 'border-blue-300',
            pillColor: 'bg-blue-700',
            rationales: {
              tax_optimised: 'Drawdown surplus cash above minimum emergency reserve first to eliminate cash drag and protect invested growth assets.',
              pension_first: 'Preserved as a final safety reserve once pension and investment pots are spent down.',
              isa_first: 'Drawn second after ISAs to provide supplementary tax-free living bridge.',
              cash_first: 'Exhausted first to delay having to sell any stock market or pension assets.',
              pro_rata: 'Drawn proportionately alongside other portfolios.',
              custom: 'Positioned in bespoke sequence to meet specific liquidity and cash-holding preferences.',
            },
          },
          gia: {
            title: 'Taxable GIAs & CGT',
            subtitle: 'General Investment Accounts',
            icon: Scale,
            balance: totalGia,
            taxBadge: '£3k/£6k CGT Nil-Rate',
            badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
            cardBg: 'bg-amber-50/40 border-amber-200 hover:border-amber-300',
            borderAccent: 'border-amber-300',
            pillColor: 'bg-amber-700',
            rationales: {
              tax_optimised: 'Harvest £3,000 (£6,000 joint) annual CGT exemptions and clear unwrapped taxable accounts before sheltered pots.',
              pension_first: 'Liquidated after DC pensions are depleted to minimize ongoing dividend and capital gains taxes.',
              isa_first: 'Liquidated after tax-free ISAs and cash to fund ongoing retirement living.',
              cash_first: 'Drawn after cash and ISAs to delay crystallizing taxable pension income.',
              pro_rata: 'Drawn proportionately to harvest annual gains.',
              custom: 'Decumulated at chosen sequence stage to manage capital gains tax timing.',
            },
          },
          pension: {
            title: 'DC Pension Drawdown',
            subtitle: 'SIPPs & Master Trusts',
            icon: Briefcase,
            balance: totalDcPension,
            taxBadge: '25% Tax-Free + PAYE',
            badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
            cardBg: 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-300',
            borderAccent: 'border-emerald-300',
            pillColor: 'bg-emerald-800',
            rationales: {
              tax_optimised: 'Draw within the £12,570 Personal Allowance and 20% basic band; take 25% tax-free lump sums in tranches to smooth tax brackets.',
              pension_first: 'Aggressively spent down first to eliminate exposure to the 40% Pension IHT charge legislated from 6 April 2027.',
              isa_first: 'Preserved to allow DC pensions to compound undisturbed until later retirement.',
              cash_first: 'Preserved until later retirement to maintain tax-deferred compounding.',
              pro_rata: 'Drawn in annual tranches across basic tax bands.',
              custom: 'Positioned in bespoke sequence to control marginal income tax brackets and IHT exposure.',
            },
          },
          isa: {
            title: 'ISA Tax-Free Shield',
            subtitle: 'Stocks & Shares / Cash ISAs',
            icon: ShieldCheck,
            balance: totalIsa,
            taxBadge: '100% Tax-Free Shield',
            badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
            cardBg: 'bg-purple-50/40 border-purple-200 hover:border-purple-300',
            borderAccent: 'border-purple-300',
            pillColor: 'bg-purple-800',
            rationales: {
              tax_optimised: 'Preserved until last to compound 100% tax-free and provide an unencumbered buffer for late-life care or tax-free inheritance.',
              pension_first: 'Sheltered and compounded while pensions are spent down for IHT mitigation.',
              isa_first: 'Drawn down first as a 100% tax-free income bridge in early retirement.',
              cash_first: 'Drawn after cash to defer taxable pension withdrawals.',
              pro_rata: 'Drawn proportionately to keep income within lower tax brackets.',
              custom: 'Positioned to provide flexible, 100% tax-free income at your chosen decumulation stage.',
            },
          },
        };

        // Summary Simulation Metrics for active strategy
        const isFullyFunded = simulationResult.isPlanFullyFunded;
        const depletionAge = simulationResult.ageFundsDepleted;
        const totalTaxPaid = isRealTerms
          ? simulationResult.totalLifetimeTaxPaidReal
          : simulationResult.totalLifetimeTaxPaidNominal;
        const finalLegacy = isRealTerms
          ? simulationResult.legacyWealthAt95Real
          : simulationResult.legacyWealthAt95Nominal;
        const finalYear = simulationResult.years[simulationResult.years.length - 1];
        const finalPensionPot = isRealTerms ? (finalYear?.pensionPotReal || 0) : (finalYear?.pensionPotNominal || 0);

        return (
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-800" /> Bespoke Retirement Drawdown Sequence
                  </h4>
                  {activeStrategy === 'custom' && (
                    <span className="px-2 py-0.5 rounded-full text-2xs font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300">
                      Bespoke Active
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Choose a proven UK decumulation strategy or use the arrow controls on each card to arrange your exact custom drawdown priority. The cashflow model updates instantly.
                </p>
              </div>

              {/* Strategy Selector Buttons */}
              <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs">
                {[
                  { id: 'tax_optimised' as DrawdownStrategy, label: '🌟 Tax-Optimised (Recommended)' },
                  { id: 'pension_first' as DrawdownStrategy, label: '💼 Pension-First (IHT Minimiser)' },
                  { id: 'isa_first' as DrawdownStrategy, label: '🛡️ ISA-First Bridge' },
                  { id: 'cash_first' as DrawdownStrategy, label: '💵 Cash-First Buffer' },
                ].map((strat) => {
                  const isSelected = activeStrategy === strat.id;
                  return (
                    <button
                      key={strat.id}
                      type="button"
                      onClick={() => handleSelectPreset(strat.id)}
                      className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'text-slate-700 hover:text-slate-950 hover:bg-slate-200/70'
                      }`}
                    >
                      {strat.label}
                    </button>
                  );
                })}

                {activeStrategy === 'custom' && (
                  <button
                    type="button"
                    onClick={() => handleSelectPreset('tax_optimised')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-semibold text-2xs bg-amber-200/80 text-amber-950 hover:bg-amber-300 transition-all cursor-pointer border border-amber-300"
                    title="Reset sequence to recommended Tax-Optimised order"
                  >
                    <RotateCcw className="w-3 h-3" /> Reset
                  </button>
                )}
              </div>
            </div>

            {/* 4 Priority Cards (Arranged by Active Sequence) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {activeSequence.map((potKey, index) => {
                const pot = potMetadata[potKey];
                const IconComponent = pot.icon;
                const rationaleText = pot.rationales[activeStrategy] || pot.rationales.tax_optimised;
                const isFirst = index === 0;
                const isLast = index === activeSequence.length - 1;

                return (
                  <div
                    key={potKey}
                    className={`p-5 rounded-2xl border transition-all duration-200 shadow-2xs flex flex-col justify-between space-y-4 ${pot.cardBg}`}
                  >
                    <div className="space-y-3">
                      {/* Priority Tag and Reorder Controls */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-6 h-6 rounded-full text-white flex items-center justify-center text-xs font-bold shadow-2xs ${pot.pillColor}`}
                          >
                            {index + 1}
                          </span>
                          <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                            {index === 0 ? '1st Priority' : index === 1 ? '2nd Priority' : index === 2 ? '3rd Priority' : '4th Priority'}
                          </span>
                        </div>

                        {/* Interactive Move Earlier / Later Buttons */}
                        <div className="flex items-center gap-1 bg-white/90 p-0.5 rounded-lg border border-slate-200 shadow-2xs">
                          <button
                            type="button"
                            disabled={isFirst}
                            onClick={() => handleMovePot(index, 'up')}
                            className={`p-1 rounded transition-colors ${
                              isFirst
                                ? 'text-slate-300 cursor-not-allowed'
                                : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100 cursor-pointer'
                            }`}
                            title={`Move ${pot.title} earlier in sequence`}
                            aria-label={`Move ${pot.title} earlier`}
                          >
                            <ArrowLeft className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={isLast}
                            onClick={() => handleMovePot(index, 'down')}
                            className={`p-1 rounded transition-colors ${
                              isLast
                                ? 'text-slate-300 cursor-not-allowed'
                                : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100 cursor-pointer'
                            }`}
                            title={`Move ${pot.title} later in sequence`}
                            aria-label={`Move ${pot.title} later`}
                          >
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Pot Header & Balance */}
                      <div>
                        <div className="flex items-center gap-1.5">
                          <IconComponent className="w-4 h-4 text-slate-700 shrink-0" />
                          <h5 className="font-semibold text-slate-900 text-sm">{pot.title}</h5>
                        </div>
                        <div className="flex items-baseline gap-1.5 mt-1">
                          <span className="text-base font-bold font-serif text-slate-900">
                            £{Math.round(pot.balance).toLocaleString('en-GB')}
                          </span>
                          <span className="text-2xs text-slate-500 font-medium">available</span>
                        </div>
                      </div>

                      {/* Tax Treatment Pill */}
                      <div>
                        <span
                          className={`inline-flex items-center gap-1 text-2xs font-semibold px-2 py-0.5 rounded-md border ${pot.badgeColor}`}
                        >
                          <ShieldCheck className="w-3 h-3 shrink-0" /> {pot.taxBadge}
                        </span>
                      </div>

                      {/* Strategy Rationale */}
                      <p className="text-xs text-slate-600 leading-relaxed pt-1">
                        {rationaleText}
                      </p>
                    </div>

                    {/* Step Flow Footer */}
                    <div className="pt-3 border-t border-slate-200/70 flex items-center justify-between text-2xs text-slate-500 font-medium">
                      <span>{isFirst ? 'Drawdown Start' : isLast ? 'Final Reserve' : `Step ${index + 1} of 4`}</span>
                      <span className="text-slate-400 font-mono">#{index + 1}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Real-Time Strategy Impact Dashboard Bar */}
            <div className="p-4 rounded-xl bg-slate-900 text-white border border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold text-slate-300">Live Simulation Impact for Selected Sequence:</span>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {activeStrategy === 'tax_optimised'
                      ? 'Tax-Optimised Waterfall'
                      : activeStrategy === 'pension_first'
                      ? 'Pension-First (IHT Minimiser)'
                      : activeStrategy === 'isa_first'
                      ? 'ISA-First Bridge'
                      : activeStrategy === 'cash_first'
                      ? 'Cash-First Buffer'
                      : 'Bespoke Custom Sequence'}
                  </span>
                </div>
                <span className="text-2xs text-slate-400 font-medium">
                  Assessing {profile.personal.planningHorizonAge || 95}-Year Planning Horizon
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2 border-t border-slate-800 text-xs">
                <div>
                  <span className="text-2xs text-slate-400 block">Plan Longevity</span>
                  <span
                    className={`font-semibold flex items-center gap-1 mt-0.5 ${
                      isFullyFunded ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {isFullyFunded ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Fully Funded to Age {profile.personal.planningHorizonAge || 95}
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-3.5 h-3.5" /> Depleted at Age {depletionAge}
                      </>
                    )}
                  </span>
                </div>

                <div>
                  <span className="text-2xs text-slate-400 block">Total Lifetime Tax Paid</span>
                  <span className="font-semibold text-white mt-0.5 block">
                    £{Math.round(totalTaxPaid).toLocaleString('en-GB')}{' '}
                    <span className="text-2xs text-slate-400 font-normal">
                      ({isRealTerms ? 'Real' : 'Nominal'})
                    </span>
                  </span>
                </div>

                <div>
                  <span className="text-2xs text-slate-400 block">Projected Horizon Legacy</span>
                  <span className="font-semibold text-emerald-300 mt-0.5 block">
                    £{Math.round(finalLegacy).toLocaleString('en-GB')}
                  </span>
                </div>

                <div>
                  <span className="text-2xs text-slate-400 block">Post-2027 Pension IHT Pot</span>
                  <span className="font-semibold text-white mt-0.5 block">
                    {finalPensionPot <= 100 ? (
                      <span className="text-emerald-400 font-medium flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> £0 (Eliminated)
                      </span>
                    ) : (
                      <span className="text-amber-300 font-medium">
                        £{Math.round(finalPensionPot).toLocaleString('en-GB')} remaining
                      </span>
                    )}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 5. Comprehensive Gifting, Excess Income & IHT Hub */}
      <GiftingIhtHub />
    </div>
  );
};
