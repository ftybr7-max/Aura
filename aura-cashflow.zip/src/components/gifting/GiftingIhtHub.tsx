/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Gifting & IHT Mitigation Hub
 * Fully models HMRC Section 21 Normal Expenditure Out of Income,
 * Historic PETs/CLTs with Donor/Donee attributions, 7-Year Taper Relief, and IHT Estate Impact.
 */

import React, { useState, useMemo } from 'react';
import {
  Gift,
  ShieldCheck,
  Calendar,
  User,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Coins,
  TrendingDown,
  Info,
  Layers,
  Sparkles,
  ArrowRight,
  Clock,
  Sliders,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { CurrencyInput } from '../common/PrivacyModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { HistoricGift, GiftClassification, IndividualOwner } from '../../types/cashflow';
import {
  UK_TAX_CONSTANTS,
  calculateGiftTaperRelief,
  evaluateHistoricGiftsPortfolio,
  calculateInheritanceTax,
  calculateExcessIncomeGiftingCapacity,
} from '../../aura/engine/taxEngine';

interface GiftingIhtHubProps {
  compact?: boolean;
}

export const GiftingIhtHub: React.FC<GiftingIhtHubProps> = ({ compact = false }) => {
  const {
    profile,
    saveHistoricGift,
    deleteHistoricGift,
    updateExcessIncomeGifting,
    simulationResult,
    isRealTerms,
  } = useCashflow();

  const primaryName = profile.personal.fullName?.trim() || 'Client';
  const partnerName = profile.personal.partnerName?.trim() || 'Partner';
  const hasPartner = profile.personal.hasPartner;
  const isMarriedOrCivilPartner = hasPartner && (profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType);

  // Form State for Adding New Historic/Planned Gift
  const [newGift, setNewGift] = useState<Omit<HistoricGift, 'id'>>({
    donor: 'primary',
    doneeName: '',
    doneeRelationship: 'Child / Grandchild',
    giftDate: new Date().toISOString().split('T')[0],
    amount: 10000,
    type: 'PET',
    description: '',
    exemptReason: '',
  });

  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    title: string;
  }>({
    isOpen: false,
    id: '',
    title: '',
  });

  // Calculate live excess income capacity from current profile
  const capacity = useMemo(() => {
    return calculateExcessIncomeGiftingCapacity(profile);
  }, [profile]);

  const excessPlan = profile.excessIncomeGifting || {
    isEnabled: false,
    annualAmount: 0,
    donor: 'joint',
    habitualFrequency: 'annual',
    doneeDescription: '',
    documentationInPlace: true,
  };

  const isExcessEnabled = excessPlan.isEnabled ?? excessPlan.enabled ?? false;
  const excessAnnualAmount = excessPlan.annualAmount ?? excessPlan.annualGiftAmount ?? 0;

  // Evaluate the historic gifts portfolio under HMRC rules
  const portfolioEval = useMemo(() => {
    return evaluateHistoricGiftsPortfolio(profile.historicGifts || []);
  }, [profile.historicGifts]);

  // Aggregate Estate Balance for IHT
  const totalProperty = profile.properties.reduce((s, p) => s + p.currentValue, 0);
  const totalIsa = profile.isas.reduce((s, i) => s + i.balance, 0);
  const totalGia = profile.gias.reduce((s, g) => s + g.balance, 0);
  const totalCash = profile.cashAccounts.reduce((s, c) => s + c.balance, 0);
  const totalDc = profile.dcPensions.reduce((s, d) => s + d.currentPotValue, 0);
  const totalMortgage = profile.mortgages.reduce((s, m) => s + m.outstandingBalance, 0);

  // Calculate IHT with and without gifting
  const ihtSummary = useMemo(() => {
    return calculateInheritanceTax({
      propertyValue: totalProperty,
      liquidAssets: totalIsa + totalGia + totalCash,
      dcPensionPot: totalDc,
      mortgageDebt: totalMortgage,
      hasSpouseOrCivilPartner: isMarriedOrCivilPartner,
      isPostApril2027: true,
      includePensionsInIhtPost2027: true,
      historicGifts: profile.historicGifts,
    });
  }, [totalProperty, totalIsa, totalGia, totalCash, totalDc, totalMortgage, isMarriedOrCivilPartner, profile.historicGifts]);

  const formatGbp = (val: number) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handleAddGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGift.amount || newGift.amount <= 0) return;
    saveHistoricGift({
      ...newGift,
      id: crypto.randomUUID(),
    });
    setNewGift({
      donor: 'primary',
      doneeName: '',
      doneeRelationship: 'Child / Grandchild',
      giftDate: new Date().toISOString().split('T')[0],
      amount: 10000,
      type: 'PET',
      description: '',
      exemptReason: '',
    });
  };

  // Slider change for excess income gifting
  const handleSliderChange = (pct: number) => {
    const amount = Math.round((capacity.totalNetExcessCapacity * pct) / 100);
    updateExcessIncomeGifting({
      ...excessPlan,
      isEnabled: amount > 0,
      enabled: amount > 0,
      annualAmount: amount,
      annualGiftAmount: amount,
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-serif font-semibold text-slate-900 flex items-center gap-2">
                <Gift className="w-5 h-5 text-emerald-800" /> UK Gifting & Inheritance Tax (IHT) Hub
              </h3>
              <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full border border-emerald-200">
                HMRC s.21 & PETs
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 max-w-3xl leading-relaxed">
              Model Potentially Exempt Transfers (PETs), 7-year taper relief, donor/donee records, and HMRC Section 21 “Normal Expenditure Out of Income” capacity to systematically reduce taxable estate liabilities.
            </p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-right flex sm:flex-col justify-between items-center sm:items-end gap-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              Taxable Estate
            </span>
            <span className="text-lg font-bold font-serif text-slate-900">
              {formatGbp(ihtSummary.taxableEstate)}
            </span>
            <span className="text-xs font-semibold text-red-600">
              Est. IHT: {formatGbp(ihtSummary.ihtLiability)}
            </span>
          </div>
        </div>
      </div>

      {/* 2. SECTION 21 HMRC "NORMAL EXPENDITURE OUT OF INCOME" CAPACITY ENGINE */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-800" /> Gifting Out of Excess Income (HMRC s.21 IHTA 1984)
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Gifts made from surplus net income are <strong>immediately exempt from IHT</strong> with NO 7-year survival requirement, provided they are habitual and do not diminish living standards.
            </p>
          </div>
        </div>

        {/* Capacity Breakdown KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Annual Net Income
            </span>
            <span className="text-xl font-bold font-serif text-slate-900">
              {formatGbp(capacity.annualNetIncome)}
            </span>
            <span className="text-[10px] text-slate-500 block">
              Salary, Pensions & Rental
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Annual Living Costs
            </span>
            <span className="text-xl font-bold font-serif text-slate-900">
              {formatGbp(capacity.annualLivingExpenses)}
            </span>
            <span className="text-[10px] text-slate-500 block">
              Essential & Lifestyle Outflows
            </span>
          </div>

          <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-900 block">
              Available Surplus Capacity
            </span>
            <span className="text-xl font-bold font-serif text-emerald-950">
              {formatGbp(capacity.totalNetExcessCapacity)} / yr
            </span>
            <span className="text-[10px] text-emerald-700 block">
              HMRC Qualifying Max
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 text-white space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-300 block">
              Active Gift Outflow
            </span>
            <span className="text-xl font-bold font-serif text-emerald-400">
              {isExcessEnabled ? formatGbp(excessAnnualAmount) : '£0'} / yr
            </span>
            <span className="text-[10px] text-slate-300 block">
              {isExcessEnabled ? 'Exempt IHT Deduction' : 'Plan Disabled'}
            </span>
          </div>
        </div>

        {/* Interactive Surplus Allocation Slider */}
        {capacity.totalNetExcessCapacity > 0 ? (
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
            {/* Top Bar above slider: Enable Plan Toggle on the LEFT, Selected Gift amount on the RIGHT */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2.5 cursor-pointer bg-white px-3.5 py-2 rounded-xl border border-emerald-300 shadow-2xs hover:bg-emerald-50/50 transition-all font-semibold text-xs text-slate-900">
                  <input
                    type="checkbox"
                    checked={isExcessEnabled}
                    onChange={(e) =>
                      updateExcessIncomeGifting({
                        ...excessPlan,
                        isEnabled: e.target.checked,
                        enabled: e.target.checked,
                        annualAmount: e.target.checked && excessAnnualAmount === 0 ? Math.round(capacity.totalNetExcessCapacity * 0.5) : excessAnnualAmount,
                        annualGiftAmount: e.target.checked && excessAnnualAmount === 0 ? Math.round(capacity.totalNetExcessCapacity * 0.5) : excessAnnualAmount,
                      })
                    }
                    className="w-4 h-4 text-emerald-800 rounded focus:ring-emerald-700 accent-emerald-800"
                  />
                  <span className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900">Enable plan</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${isExcessEnabled ? 'bg-emerald-100 text-emerald-900' : 'bg-slate-200 text-slate-600'}`}>
                      {isExcessEnabled ? 'Active' : 'Off'}
                    </span>
                  </span>
                </label>
                <span className="text-slate-500 font-medium hidden md:inline">
                  (Allocate surplus to regular gifting)
                </span>
              </div>

              <div className="flex items-center gap-2 font-semibold">
                <span className="text-slate-600">Selected Annual Gift:</span>
                <span className="text-sm font-bold text-emerald-900 bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200">
                  {formatGbp(excessAnnualAmount)} ({Math.round((excessAnnualAmount / (capacity.totalNetExcessCapacity || 1)) * 100)}% of Surplus)
                </span>
              </div>
            </div>

            <input
              type="range"
              min={0}
              max={100}
              step={5}
              disabled={!isExcessEnabled}
              value={capacity.totalNetExcessCapacity > 0 ? Math.min(100, Math.round((excessAnnualAmount / capacity.totalNetExcessCapacity) * 100)) : 0}
              onChange={(e) => handleSliderChange(parseInt(e.target.value))}
              className={`w-full accent-emerald-800 ${!isExcessEnabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
            />

            <div className="flex justify-between text-[11px] text-slate-500 font-medium">
              <span>0% (£0)</span>
              <span>25% ({formatGbp(capacity.totalNetExcessCapacity * 0.25)})</span>
              <span>50% ({formatGbp(capacity.totalNetExcessCapacity * 0.5)})</span>
              <span>75% ({formatGbp(capacity.totalNetExcessCapacity * 0.75)})</span>
              <span>100% ({formatGbp(capacity.totalNetExcessCapacity)})</span>
            </div>

            {/* Plan Configuration Details */}
            {isExcessEnabled && (
              <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Gifting Donor
                  </label>
                  <select
                    value={excessPlan.donor || 'joint'}
                    onChange={(e) =>
                      updateExcessIncomeGifting({
                        ...excessPlan,
                        donor: e.target.value as any,
                      })
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-white"
                  >
                    <option value="primary">{primaryName}</option>
                    {hasPartner && <option value="partner">{partnerName}</option>}
                    {hasPartner && <option value="joint">Joint (Both)</option>}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Frequency
                  </label>
                  <select
                    value={excessPlan.habitualFrequency || excessPlan.fundingFrequency || 'monthly'}
                    onChange={(e) =>
                      updateExcessIncomeGifting({
                        ...excessPlan,
                        habitualFrequency: e.target.value as any,
                        fundingFrequency: e.target.value as any,
                      })
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-white"
                  >
                    <option value="monthly">Monthly ({formatGbp(excessAnnualAmount / 12)}/mo)</option>
                    <option value="quarterly">Quarterly ({formatGbp(excessAnnualAmount / 4)}/qtr)</option>
                    <option value="annual">Annual Lump Sum ({formatGbp(excessAnnualAmount)}/yr)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Donee / Purpose Note
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Children school fees / Grandchildren ISAs"
                    value={excessPlan.doneeDescription || excessPlan.recipientName || ''}
                    onChange={(e) =>
                      updateExcessIncomeGifting({
                        ...excessPlan,
                        doneeDescription: e.target.value,
                        recipientName: e.target.value,
                      })
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-white"
                  />
                </div>
              </div>
            )}

            {/* HMRC Compliance Checklist */}
            <div className="p-3.5 rounded-xl bg-emerald-50/50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 mt-0.5 shrink-0" />
              <div>
                <span className="font-bold block">HMRC Statutory Exemption Compliance (Form IHT403):</span>
                <span>
                  By documenting this pattern of regular gifts and maintaining records of net surplus income, these transfers are <strong>100% exempt on death with zero 7-year clock</strong>, reducing your estate liability by <strong>{formatGbp(excessAnnualAmount * 0.40)} every year</strong>.
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              Your current annual living outflows exceed or equal net income. Under HMRC rules, gifts made from capital or savings withdrawals do NOT qualify for Section 21 exemption and will be treated as Potentially Exempt Transfers (PETs).
            </span>
          </div>
        )}
      </div>

      {/* 3. HISTORIC & PLANNED GIFTS PORTFOLIO (PETS, CLTS, 7-YEAR CLOCK) */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-800" /> Historic & Planned Gifts Register (7-Year PET Clock)
            </h4>
            <p className="text-xs text-slate-500">
              Track lifetime gifts to evaluate Nil Rate Band erosion, active 7-year survival timers, and statutory taper relief.
            </p>
          </div>
        </div>

        {/* Existing Gifts Table / Cards */}
        {(!profile.historicGifts || profile.historicGifts.length === 0) ? (
          <div className="p-8 text-center rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <Gift className="w-8 h-8 text-slate-400 mx-auto" />
            <span className="text-sm font-semibold text-slate-700 block">No Historic Gifts Logged</span>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Add gifts made over the last 7 years (or planned large gifts) to accurately calculate your available Nil Rate Band and taper relief.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {portfolioEval.processedGifts.map((gift) => {
              const donorName = gift.donor === 'partner' ? partnerName : gift.donor === 'joint' ? 'Joint' : primaryName;
              return (
                <div
                  key={gift.id}
                  className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                    gift.isExempt
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-slate-50/80 border-slate-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900">
                        {formatGbp(gift.amount)}
                      </span>
                      <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-700">
                        Donor: {donorName}
                      </span>
                      <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-200/80 text-slate-800">
                        To: {gift.doneeName || 'Recipient'} ({gift.doneeRelationship || 'Donee'})
                      </span>
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        gift.isExempt
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}>
                        {gift.isExempt ? 'Fully Exempt (>7 yrs)' : `Active PET (${gift.yearsElapsed} yrs)`}
                      </span>
                    </div>

                    <div className="text-xs text-slate-500 flex items-center gap-3">
                      <span>Date: {gift.giftDate}</span>
                      {gift.description && <span>· {gift.description}</span>}
                      <span>· Taper Relief: {gift.taperReductionPercent}%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 self-stretch sm:self-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block uppercase">NRB Erosion</span>
                      <span className="text-xs font-bold text-slate-800">
                        {gift.isExempt ? '£0 (Restored)' : formatGbp(gift.netTaxableAmount)}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          id: gift.id,
                          title: `${formatGbp(gift.amount)} gift to ${gift.doneeName || 'Donee'}`,
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label="Delete gift"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Add New Gift Form */}
        <form onSubmit={handleAddGift} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
            + Log New Historic or Planned Gift
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <CurrencyInput
              label="Gift Amount (£)"
              value={newGift.amount}
              onChange={(val) => setNewGift({ ...newGift, amount: val })}
              step={1000}
            />

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Donor
              </label>
              <select
                value={newGift.donor}
                onChange={(e) => setNewGift({ ...newGift, donor: e.target.value as any })}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white"
              >
                <option value="primary">{primaryName} (Primary)</option>
                {hasPartner && <option value="partner">{partnerName} (Partner)</option>}
                {hasPartner && <option value="joint">Joint (50/50 Split)</option>}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Donee Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Sophie (Daughter)"
                value={newGift.doneeName}
                onChange={(e) => setNewGift({ ...newGift, doneeName: e.target.value })}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Date of Gift
              </label>
              <input
                type="date"
                required
                value={newGift.giftDate}
                onChange={(e) => setNewGift({ ...newGift, giftDate: e.target.value })}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Gift Classification
              </label>
              <select
                value={newGift.type}
                onChange={(e) => setNewGift({ ...newGift, type: e.target.value as GiftClassification })}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white"
              >
                <option value="PET">Potentially Exempt Transfer (PET - 7 yr clock)</option>
                <option value="CLT">Chargeable Lifetime Transfer (CLT - Trust)</option>
                <option value="EXEMPT_ANNUAL">Annual Exemption (£3,000 allowance)</option>
                <option value="EXEMPT_MARRIAGE">Wedding / Civil Partnership Gift</option>
                <option value="EXEMPT_SMALL">Small Gift (£250 allowance)</option>
                <option value="EXEMPT_EXCESS_INCOME">s.21 Normal Expenditure Out of Income</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Purpose / Notes (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. House deposit contribution / Wedding gift"
                value={newGift.description || ''}
                onChange={(e) => setNewGift({ ...newGift, description: e.target.value })}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Save Gift to Register
          </button>
        </form>
      </div>

      {/* 4. POST-APRIL 2027 ESTATE & IHT TAX IMPACT SUMMARY */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-800" /> Inheritance Tax (IHT) Estate Audit & Gifting Benefit
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Gross Estate
            </span>
            <span className="text-xl font-bold font-serif text-slate-900">
              {formatGbp(ihtSummary.grossEstate)}
            </span>
            <span className="text-[10px] text-slate-500 block">
              Includes DC Pensions post-2027
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Available NRB & RNRB
            </span>
            <span className="text-xl font-bold font-serif text-emerald-950">
              {formatGbp(ihtSummary.availableNrb + ihtSummary.availableRnrb)}
            </span>
            <span className="text-[10px] text-slate-500 block">
              NRB: {formatGbp(ihtSummary.availableNrb)} (Eroded: {formatGbp(ihtSummary.nrbErodedByHistoricGifts)})
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Taxable Estate
            </span>
            <span className="text-xl font-bold font-serif text-slate-900">
              {formatGbp(ihtSummary.taxableEstate)}
            </span>
            <span className="text-[10px] text-slate-500 block">
              After Spousal & NRB Reliefs
            </span>
          </div>

          <div className="p-4 rounded-xl bg-red-50 border border-red-200 space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-red-900 block">
              Estimated 40% IHT Due
            </span>
            <span className="text-xl font-bold font-serif text-red-700">
              {formatGbp(ihtSummary.ihtLiability)}
            </span>
            <span className="text-[10px] text-red-600 block">
              Payable by Estate Executors
            </span>
          </div>
        </div>

        {/* 7-Year Taper Schedule Reference */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-2">
          <span className="font-bold text-slate-900 block flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-slate-500" /> HMRC 7-Year Taper Relief Schedule (on tax exceeding NRB):
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-[11px]">
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="block text-slate-400">0–3 Years</span>
              <span className="font-bold text-slate-800">0% Relief (40% Tax)</span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="block text-slate-400">3–4 Years</span>
              <span className="font-bold text-emerald-800">20% Relief (32% Tax)</span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="block text-slate-400">4–5 Years</span>
              <span className="font-bold text-emerald-800">40% Relief (24% Tax)</span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="block text-slate-400">5–6 Years</span>
              <span className="font-bold text-emerald-800">60% Relief (16% Tax)</span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="block text-slate-400">6–7 Years</span>
              <span className="font-bold text-emerald-800">80% Relief (8% Tax)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        onCancel={() => setDeleteModal({ isOpen: false, id: '', title: '' })}
        onConfirm={() => {
          deleteHistoricGift(deleteModal.id);
          setDeleteModal({ isOpen: false, id: '', title: '' });
        }}
        itemTitle={deleteModal.title}
        itemCategory="gift"
      />
    </div>
  );
};
