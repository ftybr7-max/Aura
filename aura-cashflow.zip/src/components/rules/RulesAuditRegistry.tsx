/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — UK Tax & Pension Rules Transparency Registry
 */

import React, { useState } from 'react';
import {
  BookOpen,
  ExternalLink,
  ShieldCheck,
  Calendar,
  Search,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { UK_RULES_REGISTRY, UKRuleRecord } from '../../aura/engine/ukRulesRegistry';

export const RulesAuditRegistry: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    'All',
    'Income Tax & NI',
    'Pensions & LSA',
    'ISAs & Capital Gains',
    'Inheritance Tax',
    'State Pension',
  ];

  const filteredRules = UK_RULES_REGISTRY.filter((rule) => {
    const matchesCat = selectedCategory === 'All' || rule.category === selectedCategory;
    const matchesSearch =
      rule.ruleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.primaryAuthority.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.notes.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div>
          <h3 className="text-xl font-serif font-semibold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-800" /> UK Financial Rules & Authorities Registry
          </h3>
          <p className="text-sm text-slate-600 mt-1 leading-relaxed max-w-3xl">
            Aura Cashflow is built on explicit, verifiable statutory references from HM Revenue & Customs (HMRC), the Department for Work and Pensions (DWP), and official UK primary legislation.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-100">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tax allowances, legislation, or rules..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 text-slate-900"
            />
          </div>

          <div className="flex flex-wrap gap-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedCategory === cat
                    ? 'bg-emerald-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredRules.map((rule) => (
          <div
            key={rule.id}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                  {rule.category}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    rule.status === 'current'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-amber-50 text-amber-900 border-amber-200'
                  }`}
                >
                  {rule.status === 'current' ? 'Current Statutory Law' : 'Enacted Future Legislation'}
                </span>
              </div>

              <div>
                <h4 className="text-base font-serif font-bold text-slate-900">{rule.ruleName}</h4>
                <div className="mt-1 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 font-mono text-xs font-semibold text-slate-800">
                  {rule.currentValue}
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">{rule.notes}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-500">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-700">Authority:</span>
                <span>{rule.primaryAuthority}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-700">Effective:</span>
                <span>{rule.effectiveDate}</span>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <a
                  href={rule.primaryUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-emerald-800 hover:text-emerald-950 font-medium hover:underline text-[11px]"
                >
                  Primary Authority (GOV.UK) <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-slate-300">·</span>
                <a
                  href={rule.technicalInterpretationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 font-medium hover:underline text-[11px]"
                >
                  Technical Manual / Guidance <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
