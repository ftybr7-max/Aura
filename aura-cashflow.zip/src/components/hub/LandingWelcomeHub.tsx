/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Dedicated Client Entry & Welcome Hub (Step 3)
 * Full landing hub featuring authentic Aura Cashflow branding, quick start fact-finds,
 * saved plan restorers, and canonical UK wealth case studies.
 */

import React, { useState, useRef } from 'react';
import {
  Sparkles,
  FileSpreadsheet,
  Upload,
  FolderOpen,
  Users,
  ShieldCheck,
  Building2,
  ArrowRight,
  CheckCircle2,
  Lock,
  ChevronRight,
  TrendingUp,
  FileText,
  UserCheck,
  AlertCircle
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { AuraBrandLogo } from '../common/AuraBrandLogo';
import { LiteFactFindModal } from './LiteFactFindModal';
import { OverwriteConfirmModal } from '../common/OverwriteConfirmModal';
import { AdviserProfileModal } from '../common/AdviserProfileModal';

interface LandingWelcomeHubProps {
  onEnterSession: () => void;
}

export const LandingWelcomeHub: React.FC<LandingWelcomeHubProps> = ({
  onEnterSession,
}) => {
  const {
    profile,
    adviserDetails,
    loadPresetProfile,
    importProfileJson,
    resetToBlankProfile,
    resetToDefault,
    setActiveTab,
  } = useCashflow();

  const [isLiteModalOpen, setIsLiteModalOpen] = useState(false);
  const [isAdviserModalOpen, setIsAdviserModalOpen] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Overwrite Safety Modal State
  const [overwriteModal, setOverwriteModal] = useState<{
    isOpen: boolean;
    title: string;
    description?: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    onConfirm: () => {},
  });

  const hasActiveSessionData = Boolean(profile?.personal?.fullName);
  const activeClientName = profile?.personal?.fullName || 'Current Client';

  const handleStartLite = () => {
    if (hasActiveSessionData) {
      setOverwriteModal({
        isOpen: true,
        title: 'New Client: Lite Fact-Find (3-Min Quickstart)',
        description: 'Open a blank 3-minute quickstart snapshot for a new client household.',
        onConfirm: () => {
          setIsLiteModalOpen(true);
        },
      });
    } else {
      setIsLiteModalOpen(true);
    }
  };

  const handleStartComprehensive = () => {
    if (hasActiveSessionData) {
      setOverwriteModal({
        isOpen: true,
        title: 'New Blank Comprehensive Fact-Find',
        description: 'Initialize a clean, blank slate fact-find for a new client household.',
        onConfirm: () => {
          resetToBlankProfile();
          setActiveTab('profile');
          onEnterSession();
        },
      });
    } else {
      resetToBlankProfile();
      setActiveTab('profile');
      onEnterSession();
    }
  };

  const handleSelectCaseStudy = (presetId: string, caseTitle: string, description: string) => {
    if (hasActiveSessionData) {
      setOverwriteModal({
        isOpen: true,
        title: `Case Study: ${caseTitle}`,
        description,
        onConfirm: () => {
          loadPresetProfile(presetId);
          setActiveTab('modeller');
          onEnterSession();
        },
      });
    } else {
      loadPresetProfile(presetId);
      setActiveTab('modeller');
      onEnterSession();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        if (hasActiveSessionData) {
          setOverwriteModal({
            isOpen: true,
            title: `Imported Plan (${file.name})`,
            description: 'Restore client profile from JSON backup file.',
            onConfirm: () => {
              const success = importProfileJson(content);
              if (success) {
                setActiveTab('modeller');
                onEnterSession();
              }
            },
          });
        } else {
          const success = importProfileJson(content);
          if (success) {
            setActiveTab('modeller');
            onEnterSession();
          }
        }
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        if (hasActiveSessionData) {
          setOverwriteModal({
            isOpen: true,
            title: `Imported Plan (${file.name})`,
            description: 'Restore client profile from dropped JSON backup.',
            onConfirm: () => {
              const success = importProfileJson(content);
              if (success) {
                setActiveTab('modeller');
                onEnterSession();
              }
            },
          });
        } else {
          const success = importProfileJson(content);
          if (success) {
            setActiveTab('modeller');
            onEnterSession();
          }
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-[#060D1B] text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Ambient Glow / Header Bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          <AuraBrandLogo variant="compact-header" showTagline={false} />

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsAdviserModalOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/80 text-xs font-semibold text-slate-200 transition-all cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Practice Branding:</span>
              <span className="text-amber-300 font-bold">{adviserDetails.firmName || 'Configure'}</span>
            </button>

            {hasActiveSessionData && (
              <button
                type="button"
                onClick={() => {
                  setActiveTab('modeller');
                  onEnterSession();
                }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-950/50 transition-all cursor-pointer"
              >
                <span>Resume Session: {activeClientName}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Landing Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14 space-y-12">
        {/* Brand Display Hero */}
        <section className="text-center relative py-6">
          <AuraBrandLogo variant="full" showTagline={true} />

          <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300/90 leading-relaxed mt-4">
            Institutional-grade UK cashflow forecasting, tax drawdown optimization, and retirement modeling under the <strong>2026/27 tax year rules</strong>.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 mt-6 text-xs text-slate-300">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/90 border border-slate-700/80">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              2026/27 Tax Bands & Allowances
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/90 border border-slate-700/80">
              <Lock className="w-3 h-3 text-amber-400" />
              100% Client-Side Local Privacy
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/90 border border-slate-700/80">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              IFA White-Label Export Ready
            </span>
          </div>
        </section>

        {/* 3 Core Interactive Entry Pillars */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {/* Pillar 1: Start New Client Fact-Find */}
          <div className="relative rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800/90 p-6 lg:p-7 flex flex-col justify-between shadow-xl group hover:border-emerald-500/50 transition-all">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-950/90 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
                <FileSpreadsheet className="w-6 h-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">
                  1. Start New Client Fact-Find
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed mt-1">
                  Begin a new UK client planning case with choice of rapid or comprehensive fact-finding.
                </p>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={handleStartLite}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-500/30 text-left transition-all cursor-pointer group/btn"
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-xs font-bold text-emerald-200 group-hover/btn:text-white">
                        Lite Fact-Find (3-Min Quickstart)
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Fast retirement runway, pension pot & target spend snapshot.
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-emerald-400 group-hover/btn:translate-x-1 transition-transform" />
                </button>

                <button
                  type="button"
                  onClick={handleStartComprehensive}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/80 text-left transition-all cursor-pointer group/btn"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-200 group-hover/btn:text-white">
                      Comprehensive Fact-Find Studio
                    </span>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Full multi-wrapper, partner, DB/DC, property & estate model.
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 text-[11px] text-slate-500">
              ✓ Supports single & joint partner households
            </div>
          </div>

          {/* Pillar 2: Open / Restore Saved Plan */}
          <div className="relative rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800/90 p-6 lg:p-7 flex flex-col justify-between shadow-xl group hover:border-blue-500/50 transition-all">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-950/90 border border-blue-500/30 flex items-center justify-center text-blue-400 shadow-inner">
                <FolderOpen className="w-6 h-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">
                  2. Open / Restore Saved Plan
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed mt-1">
                  Import a client backup JSON file or resume an autosaved browser session.
                </p>
              </div>

              {/* Drag and Drop Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`p-4 rounded-2xl border-2 border-dashed transition-all cursor-pointer text-center ${
                  dragOver
                    ? 'border-blue-400 bg-blue-950/40 text-blue-200'
                    : 'border-slate-700/80 hover:border-blue-400/80 bg-slate-800/40 hover:bg-slate-800/80 text-slate-400'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Upload className="w-6 h-6 mx-auto mb-1.5 text-blue-400" />
                <span className="text-xs font-bold text-slate-200 block">
                  Click or Drop .JSON Client File
                </span>
                <span className="text-[10px] text-slate-400">
                  Instant restoration with full calculations
                </span>
              </div>

              {hasActiveSessionData && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('modeller');
                    onEnterSession();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-left transition-all cursor-pointer"
                >
                  <div className="min-w-0 pr-2">
                    <span className="text-[11px] font-bold text-amber-300 block truncate">
                      Resume Autosave: {activeClientName}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Age {profile.personal.currentAge} · Retires {profile.personal.targetRetirementAge}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-amber-400 shrink-0" />
                </button>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 text-[11px] text-slate-500">
              ✓ Encrypted client-side portable JSON formats
            </div>
          </div>

          {/* Pillar 3: Canonical UK Case Studies */}
          <div className="relative rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800/90 p-6 lg:p-7 flex flex-col justify-between shadow-xl group hover:border-amber-500/50 transition-all">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-950/90 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
                <Users className="w-6 h-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">
                  3. Explore UK Case Studies
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed mt-1">
                  Load benchmark UK household profiles to evaluate models and strategies.
                </p>
              </div>

              <div className="space-y-2 pt-1">
                {/* Case 1: Eleanor & David */}
                <button
                  type="button"
                  onClick={() =>
                    handleSelectCaseStudy(
                      'mid-career-professional',
                      'Eleanor & David (Mid-Career Family)',
                      'Age 44 & 42 · £85k gross salary, workplace pension, mortgage & ISA portfolio'
                    )
                  }
                  className="w-full text-left p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/80 transition-all cursor-pointer group/card"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 group-hover/card:text-amber-300">
                      Eleanor & David
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700">
                      Age 44/42
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    Mid-career family in Bristol, mortgage & ISA accumulation.
                  </p>
                </button>

                {/* Case 2: Robert & Fiona */}
                <button
                  type="button"
                  onClick={() =>
                    handleSelectCaseStudy(
                      'approaching-retirement',
                      'Robert & Fiona (Approaching Retirement)',
                      'Age 58 & 57 · £800k DC pensions, debt-free, drawdown sequencing & IHT planning'
                    )
                  }
                  className="w-full text-left p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/80 transition-all cursor-pointer group/card"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 group-hover/card:text-amber-300">
                      Robert & Fiona
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-700">
                      Age 58/57
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    Approaching retirement, £800k DC pots & April 2027 IHT planning.
                  </p>
                </button>

                {/* Case 3: Marcus */}
                <button
                  type="button"
                  onClick={() =>
                    handleSelectCaseStudy(
                      'young-accumulator',
                      'Marcus (Young Wealth Accumulator / Scotland)',
                      'Age 32 · FIRE Target 55, Scottish tax bands, aggressive salary sacrifice'
                    )
                  }
                  className="w-full text-left p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/80 transition-all cursor-pointer group/card"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 group-hover/card:text-amber-300">
                      Marcus (Scottish FIRE)
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-700">
                      Age 32
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    Tech professional in Edinburgh, Scottish tax & early retirement.
                  </p>
                </button>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 text-[11px] text-slate-500">
              ✓ Pre-configured realistic UK scenarios
            </div>
          </div>
        </section>

        {/* Practice White-Labeling Footer Banner */}
        <section className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-950/80 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">
                Adviser Practice & Client Report Header: <span className="text-amber-300">{adviserDetails.adviserName || 'Lead Adviser'}</span> ({adviserDetails.firmName || 'Practice Name'})
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Contact: {adviserDetails.email || 'adviser@practice.co.uk'} · {adviserDetails.phone || '020 7946 0000'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsAdviserModalOpen(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-colors cursor-pointer shrink-0"
          >
            Edit Practice Branding & Report Preface
          </button>
        </section>
      </main>

      {/* Modals */}
      <LiteFactFindModal
        isOpen={isLiteModalOpen}
        onClose={() => setIsLiteModalOpen(false)}
        onComplete={() => {
          setIsLiteModalOpen(false);
          onEnterSession();
        }}
      />

      <AdviserProfileModal
        isOpen={isAdviserModalOpen}
        onClose={() => setIsAdviserModalOpen(false)}
      />

      <OverwriteConfirmModal
        isOpen={overwriteModal.isOpen}
        onClose={() => setOverwriteModal((prev) => ({ ...prev, isOpen: false }))}
        onConfirm={overwriteModal.onConfirm}
        targetActionTitle={overwriteModal.title}
        targetActionDescription={overwriteModal.description}
      />
    </div>
  );
};
