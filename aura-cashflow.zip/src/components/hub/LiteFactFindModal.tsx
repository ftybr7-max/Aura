/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Lite Fact-Find Quick Start Wizard
 * Allows financial advisers and clients to enter a 3-minute rapid retirement snapshot.
 */

import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  User,
  PoundSterling,
  Building,
  TrendingUp,
  Home,
  CreditCard,
  X,
  CheckCircle2,
  Info
} from 'lucide-react';
import { useCashflow, createBlankProfile } from '../../aura/context/CashflowContext';
import { CurrencyInput } from '../common/PrivacyModal';
import { CashflowProfile } from '../../types/cashflow';

interface LiteFactFindModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export const LiteFactFindModal: React.FC<LiteFactFindModalProps> = ({
  isOpen,
  onClose,
  onComplete,
}) => {
  const { setFullProfile, setActiveTab } = useCashflow();

  // 1. Client & Demographics State (All blank for pristine new client entry)
  const [fullName, setFullName] = useState('');
  const [currentAge, setCurrentAge] = useState<number | ''>('');
  const [targetRetirementAge, setTargetRetirementAge] = useState<number | ''>('');
  const [isAlreadyRetired, setIsAlreadyRetired] = useState(false);

  // Partner State
  const [hasPartner, setHasPartner] = useState(false);
  const [partnerName, setPartnerName] = useState('');
  const [partnerAge, setPartnerAge] = useState<number | ''>('');
  const [partnerRetirementAge, setPartnerRetirementAge] = useState<number | ''>('');
  const [partnerIsAlreadyRetired, setPartnerIsAlreadyRetired] = useState(false);

  // 2. Incomes & Living Spend
  const [grossAnnualTaxableIncome, setGrossAnnualTaxableIncome] = useState<number | ''>('');
  const [currentAnnualLivingSpend, setCurrentAnnualLivingSpend] = useState<number | ''>('');
  const [desiredRetirementLivingSpend, setDesiredRetirementLivingSpend] = useState<number | ''>('');

  // 3. DC Pensions
  const [pensionPot, setPensionPot] = useState<number | ''>('');

  // 4. Investments Portfolio (ISAs, GIAs, Investment Bonds, VCT/EIS) & Growth Rate (Default 4.0%)
  const [investmentsBalance, setInvestmentsBalance] = useState<number | ''>('');
  const [investmentsGrowthRate, setInvestmentsGrowthRate] = useState(4.0);

  // 5. Cash Savings & NS&I Funds & Growth Rate (Default 2.0%)
  const [cashSavingsBalance, setCashSavingsBalance] = useState<number | ''>('');
  const [cashGrowthRate, setCashGrowthRate] = useState(2.0);

  // 6. Total Property Holdings, Downsizing / Equity Release & Mortgages
  const [propertyHoldingsValue, setPropertyHoldingsValue] = useState<number | ''>('');
  const [isDownsizingPlanned, setIsDownsizingPlanned] = useState(false);
  const [downsizeReleasedAmount, setDownsizeReleasedAmount] = useState<number | ''>('');
  const [downsizeYear, setDownsizeYear] = useState(new Date().getFullYear() + 5);

  // Mortgage & Property Debt
  const [hasMortgage, setHasMortgage] = useState(false);
  const [mortgageBalance, setMortgageBalance] = useState<number | ''>('');
  const [mortgageRate, setMortgageRate] = useState<number | ''>(4.5);
  const [mortgageType, setMortgageType] = useState<'repayment' | 'interest_only'>('repayment');

  if (!isOpen) return null;

  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 30 }, (_, i) => currentYear + i);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Start with a completely pristine blank profile
    const blank = createBlankProfile();

    const effectiveCurrentAge = Number(currentAge) || 45;
    const effectiveRetirementAge = isAlreadyRetired
      ? effectiveCurrentAge
      : Number(targetRetirementAge) || 65;

    const numGrossIncome = Number(grossAnnualTaxableIncome) || 0;
    const numCurrentLiving = Number(currentAnnualLivingSpend) || 0;
    const numDesiredLiving = Number(desiredRetirementLivingSpend) || 0;
    const numPensionPot = Number(pensionPot) || 0;
    const numInvestments = Number(investmentsBalance) || 0;
    const numCash = Number(cashSavingsBalance) || 0;
    const numProperty = Number(propertyHoldingsValue) || 0;
    const numDownsizeAmt = Number(downsizeReleasedAmount) || 0;
    const numMortgageBal = Number(mortgageBalance) || 0;
    const numMortgageRate = Number(mortgageRate) || 0;

    // 1. Personal Details
    blank.personal = {
      fullName: fullName.trim() || 'New Client',
      currentAge: effectiveCurrentAge,
      targetRetirementAge: effectiveRetirementAge,
      planningHorizonAge: 95,
      hasPartner,
      partnerName: hasPartner ? partnerName.trim() || 'Partner' : '',
      partnerAge: hasPartner ? (partnerAge === '' ? undefined : Number(partnerAge)) : undefined,
      partnerTargetRetirementAge: hasPartner
        ? partnerIsAlreadyRetired
          ? (partnerAge === '' ? effectiveCurrentAge : Number(partnerAge))
          : (partnerRetirementAge === '' ? 65 : Number(partnerRetirementAge))
        : undefined,
      taxRegion: 'england_wales_ni',
      isAlreadyRetired,
      partnerIsAlreadyRetired: hasPartner ? partnerIsAlreadyRetired : false,
      relationshipType: 'spouse_civil_partner',
    };

    // 2. Gross Annual Taxable Income
    if (numGrossIncome > 0) {
      if (isAlreadyRetired) {
        // Modelled as ongoing taxable retirement income (annuity / pension / drawdown)
        blank.otherIncomes.push({
          id: 'lite-inc-1',
          owner: 'primary',
          jointSplitPercent: 50,
          label: 'Annual Taxable Income (Retirement / Other)',
          annualAmount: numGrossIncome,
          startAge: effectiveCurrentAge,
          endAge: 95,
          isTaxable: true,
          isInflationLinked: true,
        });
      } else {
        // Modelled as pre-retirement employment salary
        blank.employment.push({
          id: 'lite-emp-1',
          owner: 'primary',
          label: 'Gross Annual Taxable Income',
          annualGross: numGrossIncome,
          annualBonus: 0,
          employeePensionPercent: 5,
          employerPensionPercent: 5,
          isSalarySacrifice: false,
          annualGrowthPercent: 2.5,
        });
      }
    }

    // 3. Living Expenses
    if (isAlreadyRetired) {
      // Single continuous living expense through lifetime
      if (numCurrentLiving > 0) {
        blank.expenses.push({
          id: 'lite-exp-1',
          owner: 'joint',
          category: 'essential',
          label: 'Annual Living Expenditure',
          annualAmount: numCurrentLiving,
          startAge: effectiveCurrentAge,
          endAge: 95,
          retirementMultiplier: 1.0,
          isInflationLinked: true,
        });
      }
    } else {
      // Pre-retirement phase
      if (numCurrentLiving > 0 && effectiveRetirementAge > effectiveCurrentAge) {
        blank.expenses.push({
          id: 'lite-exp-pre',
          owner: 'joint',
          category: 'essential',
          label: 'Current Annual Living Spend (Pre-Retirement)',
          annualAmount: numCurrentLiving,
          startAge: effectiveCurrentAge,
          endAge: effectiveRetirementAge - 1,
          retirementMultiplier: 1.0,
          isInflationLinked: true,
        });
      }
      // Post-retirement phase
      if (numDesiredLiving > 0) {
        blank.expenses.push({
          id: 'lite-exp-post',
          owner: 'joint',
          category: 'lifestyle',
          label: 'Desired Retirement Annual Living Spend',
          annualAmount: numDesiredLiving,
          startAge: effectiveRetirementAge,
          endAge: 95,
          retirementMultiplier: 1.0,
          isInflationLinked: true,
        });
      }
    }

    // 4. Defined Contribution Pension Pot
    if (numPensionPot > 0) {
      blank.dcPensions.push({
        id: 'lite-dc-1',
        owner: 'primary',
        label: 'Workplace / SIPP Pension Pot',
        currentPotValue: numPensionPot,
        ongoingMonthlyContribution: isAlreadyRetired ? 0 : Math.round((numGrossIncome * 0.05) / 12),
        ongoingEmployerMonthlyContribution: isAlreadyRetired ? 0 : Math.round((numGrossIncome * 0.05) / 12),
        growthRatePercent: 4.5,
        annualFeePercent: 0.45,
        taxFreeCashTakenPercent: isAlreadyRetired ? 25 : 0,
        isTargetForDrawdown: true,
      });
    }

    // 5. Investments Portfolio (ISAs, GIAs, Bonds, VCT/EIS)
    if (numInvestments > 0) {
      blank.isas.push({
        id: 'lite-isa-1',
        owner: 'primary',
        label: 'Investments Portfolio (ISAs / GIAs / Bonds)',
        balance: numInvestments,
        ongoingMonthlyContribution: isAlreadyRetired ? 0 : 250,
        growthRatePercent: investmentsGrowthRate,
        annualFeePercent: 0.35,
      });
    }

    // 6. Cash Savings & NS&I Funds
    if (numCash > 0) {
      blank.cashAccounts.push({
        id: 'lite-cash-1',
        owner: 'joint',
        jointSplitPercent: 50,
        label: 'Cash Savings & NS&I Funds',
        balance: numCash,
        interestRatePercent: cashGrowthRate,
        isEmergencyFund: true,
        minimumReserve: 5000,
      });
    }

    // 7. Property Holdings & Downsizing / Equity Release
    if (numProperty > 0) {
      const propId = 'lite-prop-1';
      blank.properties.push({
        id: propId,
        owner: 'joint',
        jointSplitPercent: 50,
        label: 'Main Residential Property',
        isPrimaryResidence: true,
        currentValue: numProperty,
        annualGrowthPercent: 3.0,
        rentalIncomeAnnual: 0,
        isDownsizingPlanned,
        downsizeYear: isDownsizingPlanned ? downsizeYear : undefined,
        downsizeReleasedAmount: isDownsizingPlanned ? numDownsizeAmt : undefined,
        downsizeReleaseToSavings: true,
      });

      // Mortgages & Property Debt
      if (hasMortgage && numMortgageBal > 0) {
        const monthlyPmt = mortgageType === 'interest_only'
          ? Math.round(numMortgageBal * ((numMortgageRate || 4.5) / 100 / 12))
          : Math.round((numMortgageBal * ((numMortgageRate || 4.5) / 100 / 12)) / (1 - Math.pow(1 + (numMortgageRate || 4.5) / 100 / 12, -240)));

        blank.mortgages.push({
          id: 'lite-mort-1',
          propertyId: propId,
          owner: 'joint',
          jointSplitPercent: 50,
          label: 'Residential Property Mortgage',
          outstandingBalance: numMortgageBal,
          interestRatePercent: numMortgageRate || 4.5,
          remainingTermYears: Math.max(5, Math.min(30, effectiveRetirementAge - effectiveCurrentAge)),
          monthlyPayment: monthlyPmt,
          mortgageType: mortgageType,
        });
      }
    }

    // Update assumptions
    blank.assumptions.defaultEquityGrowthRatePercent = investmentsGrowthRate;
    blank.assumptions.defaultBondCashGrowthRatePercent = cashGrowthRate;

    // Set full pristine profile
    setFullProfile(blank);
    setActiveTab('modeller');
    onComplete();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lite-modal-title"
    >
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in zoom-in-95 duration-150 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 px-6 py-4.5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-emerald-300 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 id="lite-modal-title" className="text-base font-bold text-white tracking-tight">
                Lite Fact-Find (3-Minute Rapid Snapshot)
              </h2>
              <p className="text-xs text-emerald-200">
                Enter key household assets, income, cash & property to model cashflow runway
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-700">
          {/* Section 1: Demographics & Retirement Status */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
                <User className="w-4 h-4 text-emerald-700" /> 1. Client & Retirement Horizon
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5 items-end">
              <div className="sm:col-span-5">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Client Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. John & Sarah Davies"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs font-semibold border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Current Age *
                </label>
                <input
                  type="number"
                  min={18}
                  max={100}
                  required
                  placeholder="e.g. 45"
                  value={currentAge}
                  onChange={(e) => setCurrentAge(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-semibold border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-4">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">
                    Target Retirement Age
                  </label>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 hover:bg-emerald-100 transition-colors shrink-0">
                    <input
                      type="checkbox"
                      checked={isAlreadyRetired}
                      onChange={(e) => setIsAlreadyRetired(e.target.checked)}
                      className="rounded text-emerald-700 focus:ring-emerald-600 w-3.5 h-3.5 accent-emerald-700"
                    />
                    <span>Retired or N/A</span>
                  </label>
                </div>
                <input
                  type="number"
                  min={18}
                  max={100}
                  disabled={isAlreadyRetired}
                  value={isAlreadyRetired ? '' : targetRetirementAge}
                  placeholder={isAlreadyRetired ? 'Retired / N/A' : 'e.g. 65'}
                  onChange={(e) => setTargetRetirementAge(e.target.value === '' ? '' : Number(e.target.value))}
                  className={`w-full px-3.5 py-2 text-xs font-semibold border rounded-xl focus:outline-none transition-colors ${
                    isAlreadyRetired
                      ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed italic'
                      : 'bg-white border-slate-300 text-slate-900 focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-700'
                  }`}
                />
              </div>
            </div>

            {/* Partner Toggle */}
            <div className="pt-2 border-t border-slate-200/70">
              <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800">
                <input
                  type="checkbox"
                  checked={hasPartner}
                  onChange={(e) => setHasPartner(e.target.checked)}
                  className="rounded text-emerald-700 focus:ring-emerald-600 w-4 h-4 accent-emerald-700"
                />
                <span>Include Spouse / Civil Partner in this model</span>
              </label>

              {hasPartner && (
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mt-3 p-3.5 rounded-xl bg-white border border-slate-200 animate-in fade-in items-end">
                  <div className="sm:col-span-5">
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Partner Full Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Sarah Davies"
                      value={partnerName}
                      onChange={(e) => setPartnerName(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-slate-50 focus:bg-white"
                    />
                  </div>
                  <div className="sm:col-span-3">
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Partner Age
                    </label>
                    <input
                      type="number"
                      min={18}
                      max={100}
                      placeholder="e.g. 43"
                      value={partnerAge}
                      onChange={(e) => setPartnerAge(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-slate-50 focus:bg-white"
                    />
                  </div>
                  <div className="sm:col-span-4">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">
                        Partner Retirement
                      </label>
                      <label className="inline-flex items-center gap-1.5 cursor-pointer text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 hover:bg-emerald-100 transition-colors shrink-0">
                        <input
                          type="checkbox"
                          checked={partnerIsAlreadyRetired}
                          onChange={(e) => setPartnerIsAlreadyRetired(e.target.checked)}
                          className="rounded text-emerald-700 w-3 h-3 accent-emerald-700"
                        />
                        <span>Retired</span>
                      </label>
                    </div>
                    <input
                      type="number"
                      disabled={partnerIsAlreadyRetired}
                      value={partnerIsAlreadyRetired ? '' : partnerRetirementAge}
                      placeholder={partnerIsAlreadyRetired ? 'Retired / N/A' : 'e.g. 65'}
                      onChange={(e) => setPartnerRetirementAge(e.target.value === '' ? '' : Number(e.target.value))}
                      className={`w-full px-3 py-1.5 text-xs font-semibold border rounded-lg ${
                        partnerIsAlreadyRetired
                          ? 'bg-slate-100 border-slate-200 text-slate-400 italic'
                          : 'bg-slate-50 border-slate-300 text-slate-900'
                      }`}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Income & Living Spend */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900 pb-2 border-b border-slate-200">
              <PoundSterling className="w-4 h-4 text-emerald-700" /> 2. Annual Income & Living Spend
            </div>

            <div className="space-y-4">
              <CurrencyInput
                label="Gross Annual Taxable Income"
                value={grossAnnualTaxableIncome}
                onChange={setGrossAnnualTaxableIncome}
                step={2500}
                helperText="Pre-tax annual income from all sources (e.g. salary, self-employment, pensions in payment, or other taxable income). Breakdown can be expanded later in Full Profile."
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <CurrencyInput
                  label="Current Annual Living Spend"
                  value={currentAnnualLivingSpend}
                  onChange={setCurrentAnnualLivingSpend}
                  step={1000}
                  helperText="Current annual household living & lifestyle expenses prior to retirement"
                />

                <div>
                  <CurrencyInput
                    label="Desired Retirement Annual Living Spend"
                    value={desiredRetirementLivingSpend}
                    onChange={setDesiredRetirementLivingSpend}
                    step={1000}
                    disabled={isAlreadyRetired}
                    helperText={
                      isAlreadyRetired
                        ? 'Greyed out because client is marked as Retired or N/A (Current Living Spend applies)'
                        : 'Desired annual living & lifestyle spend once in retirement (net)'
                    }
                  />
                  {isAlreadyRetired && (
                    <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-amber-800 font-medium bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                      <Info className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                      <span>Retired status active: Current annual living spend will be projected.</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Pensions & Liquid Portfolio (Investments vs Cash Split) */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900 pb-2 border-b border-slate-200">
              <TrendingUp className="w-4 h-4 text-emerald-700" /> 3. Pensions, Investments & Cash Savings
            </div>

            <div className="space-y-4">
              {/* Defined Contribution Pension Pot */}
              <CurrencyInput
                label="Total Defined Contribution (DC) Pension Pot"
                value={pensionPot}
                onChange={setPensionPot}
                step={5000}
                helperText="Accumulated personal, SIPP, or workplace pension pot"
              />

              {/* Investments Portfolio with Custom Growth Rate Dropdown (Default 4%) */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Investments Portfolio (S&S ISAs, GIAs, Bonds, VCT/EIS)
                  </span>
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-medium text-slate-600">
                      Default Growth Rate:
                    </label>
                    <select
                      value={investmentsGrowthRate}
                      onChange={(e) => setInvestmentsGrowthRate(parseFloat(e.target.value))}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg border border-slate-300 bg-slate-50 text-emerald-900 focus:outline-none focus:ring-1 focus:ring-emerald-700"
                    >
                      <option value={1.0}>1.0% p.a.</option>
                      <option value={2.0}>2.0% p.a.</option>
                      <option value={3.0}>3.0% p.a.</option>
                      <option value={4.0}>4.0% p.a. (Default Benchmark)</option>
                      <option value={5.0}>5.0% p.a.</option>
                      <option value={6.0}>6.0% p.a.</option>
                      <option value={7.0}>7.0% p.a.</option>
                      <option value={8.0}>8.0% p.a.</option>
                    </select>
                  </div>
                </div>

                <CurrencyInput
                  label="Investments Valuation"
                  value={investmentsBalance}
                  onChange={setInvestmentsBalance}
                  step={5000}
                  helperText="Stocks & Shares ISAs, General Investment Accounts, Onshore/Offshore Investment Bonds, VCT and EIS assets"
                />
              </div>

              {/* Cash Savings & NS&I Funds with Custom Growth Rate Dropdown (Default 2%) */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Cash Savings & NS&I Funds
                  </span>
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-medium text-slate-600">
                      Default Growth Rate:
                    </label>
                    <select
                      value={cashGrowthRate}
                      onChange={(e) => setCashGrowthRate(parseFloat(e.target.value))}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg border border-slate-300 bg-slate-50 text-emerald-900 focus:outline-none focus:ring-1 focus:ring-emerald-700"
                    >
                      <option value={0.5}>0.5% p.a.</option>
                      <option value={1.0}>1.0% p.a.</option>
                      <option value={1.5}>1.5% p.a.</option>
                      <option value={2.0}>2.0% p.a. (Default Cash/NS&I)</option>
                      <option value={2.5}>2.5% p.a.</option>
                      <option value={3.0}>3.0% p.a.</option>
                      <option value={4.0}>4.0% p.a.</option>
                      <option value={5.0}>5.0% p.a.</option>
                    </select>
                  </div>
                </div>

                <CurrencyInput
                  label="Cash Savings & NS&I Balance"
                  value={cashSavingsBalance}
                  onChange={setCashSavingsBalance}
                  step={2500}
                  helperText="Cash ISAs, instant access savings, fixed-term deposits, Premium Bonds, and NS&I accounts"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Property Holdings, Downsizing / Equity Release & Mortgages */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900 pb-2 border-b border-slate-200">
              <Home className="w-4 h-4 text-emerald-700" /> 4. Property Holdings, Downsizing & Mortgages
            </div>

            <div className="space-y-4">
              <CurrencyInput
                label="Total Property Holdings Valuation"
                value={propertyHoldingsValue}
                onChange={setPropertyHoldingsValue}
                step={10000}
                helperText="Estimated current market valuation of main residence and any residential property holdings"
              />

              {/* Downsizing / Equity Release Option */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800">
                  <input
                    type="checkbox"
                    checked={isDownsizingPlanned}
                    onChange={(e) => setIsDownsizingPlanned(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-emerald-700 accent-emerald-800 focus:ring-emerald-600"
                  />
                  <span>Plan to Downsize / Release Equity from Property</span>
                </label>

                {isDownsizingPlanned && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 animate-in fade-in">
                    <CurrencyInput
                      label="Net Capital / Equity Released (£)"
                      value={downsizeReleasedAmount}
                      onChange={setDownsizeReleasedAmount}
                      step={5000}
                      helperText="Net proceeds credited directly to Cash reserves"
                    />

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Target Year of Downsizing / Release
                      </label>
                      <select
                        value={downsizeYear}
                        onChange={(e) => setDownsizeYear(parseInt(e.target.value, 10))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                      >
                        {yearOptions.map((yr) => (
                          <option key={yr} value={yr}>
                            {yr} {yr === currentYear ? '(Current Year)' : `(in ${yr - currentYear} yrs)`}
                          </option>
                        ))}
                      </select>
                      <p className="text-[11px] text-slate-500 mt-1">
                        In {downsizeYear}, £{downsizeReleasedAmount.toLocaleString('en-GB')} will feed into liquid Cash reserves.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Mortgage / Debt Option under Property */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800">
                    <input
                      type="checkbox"
                      checked={hasMortgage}
                      onChange={(e) => setHasMortgage(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-300 text-emerald-700 accent-emerald-800 focus:ring-emerald-600"
                    />
                    <span>Outstanding Mortgage or Property Debt on Holdings</span>
                  </label>
                </div>

                {hasMortgage && (
                  <div className="space-y-3 pt-2 border-t border-slate-100 animate-in fade-in">
                    {/* Mortgage Type Selector */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        Mortgage Repayment Structure
                      </label>
                      <div className="flex items-center gap-4 text-xs font-semibold text-slate-800 bg-slate-50 p-2 rounded-xl border border-slate-200">
                        <label className="inline-flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="radio"
                            name="lite-mortgage-type"
                            value="repayment"
                            checked={mortgageType === 'repayment'}
                            onChange={() => setMortgageType('repayment')}
                            className="w-3.5 h-3.5 text-emerald-700 accent-emerald-800"
                          />
                          <span>Repayment (Capital & Interest)</span>
                        </label>
                        <label className="inline-flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="radio"
                            name="lite-mortgage-type"
                            value="interest_only"
                            checked={mortgageType === 'interest_only'}
                            onChange={() => setMortgageType('interest_only')}
                            className="w-3.5 h-3.5 text-emerald-700 accent-emerald-800"
                          />
                          <span>Interest-Only</span>
                        </label>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <CurrencyInput
                        label="Mortgage Balance Outstanding"
                        value={mortgageBalance}
                        onChange={setMortgageBalance}
                        step={5000}
                        placeholder="e.g. 150,000"
                        helperText={
                          mortgageType === 'interest_only'
                            ? 'Principal loan balance (remains constant until capital redemption)'
                            : 'Total remaining repayment mortgage debt balance'
                        }
                      />

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Interest Rate (% p.a.)
                        </label>
                        <input
                          type="number"
                          step={0.1}
                          min={0}
                          max={15}
                          value={mortgageRate}
                          onChange={(e) => setMortgageRate(e.target.value === '' ? '' : parseFloat(e.target.value))}
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                        />
                        <p className="text-[11px] text-slate-500 mt-1">
                          {mortgageType === 'interest_only'
                            ? 'Borrowing rate for monthly interest charges'
                            : 'Current borrowing interest rate'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-500 hover:text-slate-800 rounded-xl"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950/20 transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span>Build Client Cashflow Model</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
