/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Monte Carlo Probability & Resilience Simulation View
 */

import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  Info,
  CheckCircle2,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';

export const MonteCarloView: React.FC = () => {
  const { monteCarloResult, profile, isRealTerms } = useCashflow();

  const {
    trialsCount,
    successProbabilityPercent,
    medianTerminalWealthReal,
    p10TerminalWealthReal,
    p90TerminalWealthReal,
    medianDepletionAge,
    yearlyPercentilesReal,
    resilienceRating,
    verdictPlainEnglish,
  } = monteCarloResult;

  const formatGbp = (val: number, compact: boolean = false) => {
    if (compact) {
      if (Math.abs(val) >= 1000000) {
        return `£${(val / 1000000).toFixed(2)}m`;
      }
      if (Math.abs(val) >= 1000) {
        return `£${Math.round(val / 1000)}k`;
      }
    }
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const getResilienceBadgeColor = () => {
    switch (resilienceRating) {
      case 'Very High':
      case 'High':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'Moderate':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'Vulnerable':
      case 'Critical':
        return 'bg-red-100 text-red-900 border-red-300';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Executive Summary & Probability Badge */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Stochastic Risk Analysis
              </span>
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${getResilienceBadgeColor()}`}>
                {resilienceRating} Resilience
              </span>
            </div>
            <h3 className="text-2xl font-serif font-bold text-slate-900">
              {successProbabilityPercent}% Probability of Plan Success
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Based on {trialsCount.toLocaleString()} randomized market sequence simulations to age {profile.personal.planningHorizonAge || 95}
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div className="text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Worst 10% Outcome</span>
              <span className="text-sm font-bold font-serif text-slate-800 mt-0.5 block">
                {formatGbp(p10TerminalWealthReal, true)}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div className="text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Median Outcome</span>
              <span className="text-sm font-bold font-serif text-emerald-800 mt-0.5 block">
                {formatGbp(medianTerminalWealthReal, true)}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div className="text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Best 10% Outcome</span>
              <span className="text-sm font-bold font-serif text-slate-800 mt-0.5 block">
                {formatGbp(p90TerminalWealthReal, true)}
              </span>
            </div>
          </div>
        </div>

        {/* Plain-English Meaning ("So What?") */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/90 text-slate-700 text-sm leading-relaxed flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
          <div>
            <strong className="text-slate-900 block mb-0.5">What does this mean in practice?</strong>
            {verdictPlainEnglish}
          </div>
        </div>
      </div>

      {/* 2. Percentile Fan Chart */}
      <div className="bg-white p-4 sm:p-6 lg:p-7 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h4 className="text-base font-semibold text-slate-900 font-serif flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-800 shrink-0" />
              <span>Liquid Wealth Percentile Distribution (In Today's £)</span>
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              The shaded band captures 80% of all projected historical market pathways (10th to 90th percentiles).
            </p>
          </div>
        </div>

        {/* DISTINCTIVE RESPONSIVE KEY */}
        <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/90 flex flex-wrap items-center gap-2.5 text-xs">
          <div className="flex items-center gap-2 bg-emerald-50/80 px-3 py-1 rounded-lg border border-emerald-200 shadow-2xs">
            <span className="w-3 h-3 rounded bg-[#10B981] opacity-70 shrink-0" />
            <span className="font-semibold text-emerald-950">90th Percentile (Optimistic)</span>
          </div>
          <div className="flex items-center gap-2 bg-emerald-100/90 px-3 py-1 rounded-lg border border-emerald-300 shadow-2xs">
            <span className="w-4 h-1 rounded-full bg-[#047857] shrink-0" />
            <span className="font-bold text-emerald-950">50th Percentile (Expected Median)</span>
          </div>
          <div className="flex items-center gap-2 bg-rose-50 px-3 py-1 rounded-lg border border-rose-200 shadow-2xs">
            <span className="w-4 h-0.5 border-t-2 border-dashed border-[#E11D48] shrink-0" />
            <span className="font-bold text-rose-950">10th Percentile (Adverse Sequence)</span>
          </div>
        </div>

        <div className="h-80 sm:h-96 lg:h-[420px] w-full pt-1">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={yearlyPercentilesReal} margin={{ top: 12, right: 6, left: -16, bottom: 18 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis
                dataKey="age"
                tickLine={false}
                axisLine={{ stroke: '#CBD5E1' }}
                tick={{ fill: '#64748B', fontSize: 10 }}
                interval="preserveStartEnd"
                label={{ value: 'Client Age', position: 'insideBottom', offset: -12, fill: '#64748B', fontSize: 10 }}
              />
              <YAxis
                tickLine={false}
                axisLine={{ stroke: '#CBD5E1' }}
                tick={{ fill: '#64748B', fontSize: 10 }}
                tickFormatter={(v) => formatGbp(v, true)}
                width={46}
              />
              <Tooltip
                formatter={(value: any, name: string) => [
                  formatGbp(Number(value)),
                  name === 'p90'
                    ? '90th Percentile (Optimistic Market)'
                    : name === 'p50'
                    ? '50th Percentile (Median Expected)'
                    : name === 'p10'
                    ? '10th Percentile (Adverse Market)'
                    : name,
                ]}
                labelFormatter={(age) => `Age ${age} (Liquid Net Worth)`}
                contentStyle={{ backgroundColor: '#0F172A', color: '#F8FAFC', borderRadius: '12px', border: 'none', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.3)' }}
              />
              <Area type="monotone" dataKey="p90" name="90th Percentile" stroke="#10B981" fill="#10B981" fillOpacity={0.15} />
              <Area type="monotone" dataKey="p50" name="50th Percentile (Median)" stroke="#047857" strokeWidth={2.5} fill="#047857" fillOpacity={0.3} />
              <Area type="monotone" dataKey="p10" name="10th Percentile" stroke="#E11D48" strokeDasharray="4 4" fill="#E11D48" fillOpacity={0.1} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
