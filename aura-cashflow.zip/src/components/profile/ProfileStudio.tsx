/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Financial Profile Input Studio
 */

import React, { useState } from 'react';
import {
  User,
  Briefcase,
  Receipt,
  PiggyBank,
  ShieldCheck,
  Building,
  Sliders,
  Plus,
  Trash2,
  Edit2,
  Check,
  Percent,
  HeartHandshake,
  Scale,
  Users,
  Info,
  Calendar,
  Gift,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { CurrencyInput } from '../common/PrivacyModal';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { OwnershipSelector } from '../common/OwnershipSelector';
import { GrowthRateSelector } from '../common/GrowthRateSelector';
import { LifeEventsManager } from './LifeEventsManager';
import { GiftingIhtHub } from '../gifting/GiftingIhtHub';
import { calculateComprehensiveTaxYear, calculateInvestmentBondTaxSummary } from '../../aura/engine/taxEngine';
import {
  EmploymentIncome,
  ExpenseItem,
  DefinedContributionPension,
  DefinedBenefitPension,
  IsaAccount,
  GiaAccount,
  CashAccount,
  InvestmentBondAccount,
  InvestmentBondType,
  BondTrustType,
  OtherInvestmentAccount,
  SpecialistInvestmentType,
  PropertyAsset,
  MortgageLiability,
  IndividualOwner,
  OwnershipType,
  LegalRelationshipType,
} from '../../types/cashflow';

export const ProfileStudio: React.FC = () => {
  const {
    profile,
    updatePersonal,
    saveEmployment,
    deleteEmployment,
    saveExpense,
    deleteExpense,
    saveDcPension,
    deleteDcPension,
    saveDbPension,
    deleteDbPension,
    saveIsa,
    deleteIsa,
    saveGia,
    deleteGia,
    saveCash,
    deleteCash,
    saveInvestmentBond,
    deleteInvestmentBond,
    saveOtherInvestment,
    deleteOtherInvestment,
    saveProperty,
    deleteProperty,
    saveMortgage,
    deleteMortgage,
    updateStatePension,
    updateAssumptions,
  } = useCashflow();

  const [activeSection, setActiveSection] = useState<
    'personal' | 'employment' | 'expenses' | 'lifeEvents' | 'pensions' | 'investments' | 'properties' | 'gifting' | 'assumptions'
  >('personal');

  // Deletion Modal State
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    title: string;
    category: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    category: '',
    onConfirm: () => {},
  });

  // Calculate live tax previews using real UK 2026/27 engine!
  const primaryEmp = profile.employment.find((e) => e.owner === 'primary');
  const partnerEmp = profile.employment.find((e) => e.owner === 'partner');

  const primaryTaxPreview = primaryEmp
    ? calculateComprehensiveTaxYear({
        grossSalary: primaryEmp.annualGross,
        grossBonus: primaryEmp.annualBonus,
        employeePensionContribSalarySacrifice: primaryEmp.isSalarySacrifice
          ? (primaryEmp.annualGross * primaryEmp.employeePensionPercent) / 100
          : 0,
        employeePensionContribReliefAtSource: !primaryEmp.isSalarySacrifice
          ? (primaryEmp.annualGross * primaryEmp.employeePensionPercent) / 100
          : 0,
        taxRegion: profile.personal.taxRegion,
      })
    : null;

  const partnerTaxPreview = (profile.personal.hasPartner && partnerEmp)
    ? calculateComprehensiveTaxYear({
        grossSalary: partnerEmp.annualGross,
        grossBonus: partnerEmp.annualBonus,
        employeePensionContribSalarySacrifice: partnerEmp.isSalarySacrifice
          ? (partnerEmp.annualGross * partnerEmp.employeePensionPercent) / 100
          : 0,
        employeePensionContribReliefAtSource: !partnerEmp.isSalarySacrifice
          ? (partnerEmp.annualGross * partnerEmp.employeePensionPercent) / 100
          : 0,
        taxRegion: profile.personal.partnerTaxRegion || profile.personal.taxRegion,
      })
    : null;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Sub-Navigation Tabs */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap gap-1">
        {[
          { id: 'personal', label: '1. Personal Details', icon: User },
          { id: 'employment', label: '2. Incomes & Salaries', icon: Briefcase },
          { id: 'expenses', label: '3. Expenses & Budget', icon: Receipt },
          { id: 'lifeEvents', label: '4. Life Events Timeline', icon: Calendar },
          { id: 'pensions', label: '5. DC & DB Pensions', icon: PiggyBank },
          { id: 'investments', label: '6. Cash, ISAs & Investments', icon: ShieldCheck },
          { id: 'properties', label: '7. Property & Mortgages', icon: Building },
          { id: 'gifting', label: '8. Gifting & IHT Mitigation', icon: Gift },
          { id: 'assumptions', label: '9. State Pension & Rates', icon: Sliders },
        ].map((sec) => {
          const Icon = sec.icon;
          const isActive = activeSection === sec.id;
          return (
            <button
              key={sec.id}
              onClick={() => setActiveSection(sec.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                isActive
                  ? 'bg-emerald-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {sec.label}
            </button>
          );
        })}
      </div>

      {/* SECTION 1: PERSONAL DETAILS */}
      {activeSection === 'personal' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-serif font-semibold text-slate-900">Personal Details & Tax Jurisdiction</h3>
            <p className="text-xs text-slate-500 mt-1">
              Configure primary individual and optional partner age milestones, legal relationship, and UK tax jurisdictions.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5">
                Primary Client Full Name
              </label>
              <input
                type="text"
                value={profile.personal.fullName}
                onChange={(e) => updatePersonal({ ...profile.personal, fullName: e.target.value })}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 focus:outline-none"
              />
            </div>

            <CurrencyInput
              label="Current Age"
              value={profile.personal.currentAge}
              onChange={(val) => updatePersonal({ ...profile.personal, currentAge: val })}
              prefix=""
              step={1}
              min={18}
              max={90}
            />

            <CurrencyInput
              label="Target Retirement Age"
              value={profile.personal.targetRetirementAge}
              onChange={(val) => updatePersonal({ ...profile.personal, targetRetirementAge: val })}
              prefix=""
              step={1}
              min={profile.personal.currentAge}
              max={85}
              helperText="Age employment income ceases"
            />

            <CurrencyInput
              label="Planning Horizon (End Age)"
              value={profile.personal.planningHorizonAge}
              onChange={(val) => updatePersonal({ ...profile.personal, planningHorizonAge: val })}
              prefix=""
              step={1}
              min={70}
              max={105}
              helperText="Standard UK wealth modeling age is 95 or 100"
            />

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1.5">
                Primary Tax Region
              </label>
              <select
                value={profile.personal.taxRegion}
                onChange={(e) => updatePersonal({ ...profile.personal, taxRegion: e.target.value as any })}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 focus:outline-none"
              >
                <option value="england_wales_ni">England, Wales & Northern Ireland (Standard UK)</option>
                <option value="scotland">Scotland (Scottish 19%-48% Income Tax Bands)</option>
              </select>
              <p className="mt-1 text-xs text-slate-500">
                Scottish taxpayers pay Scottish income tax on non-savings non-dividend income.
              </p>
            </div>

            <div className="flex items-center pt-6">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={profile.personal.hasPartner}
                  onChange={(e) => updatePersonal({ ...profile.personal, hasPartner: e.target.checked })}
                  className="w-4 h-4 text-emerald-700 rounded border-slate-300 focus:ring-emerald-700"
                />
                <span className="text-sm font-medium text-slate-800 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-800" /> Model with Partner / Second Individual
                </span>
              </label>
            </div>
          </div>

          {profile.personal.hasPartner && (
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 mt-6 space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-200">
                <HeartHandshake className="w-5 h-5 text-emerald-800" />
                <h4 className="text-sm font-bold text-slate-900">Partner & Legal Relationship Details</h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Partner Name
                  </label>
                  <input
                    type="text"
                    value={profile.personal.partnerName || ''}
                    placeholder="Partner Name"
                    onChange={(e) => updatePersonal({ ...profile.personal, partnerName: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm font-medium text-slate-900 bg-white"
                  />
                </div>

                <CurrencyInput
                  label="Partner Current Age"
                  value={profile.personal.partnerAge || profile.personal.currentAge}
                  onChange={(val) => updatePersonal({ ...profile.personal, partnerAge: val })}
                  prefix=""
                  step={1}
                />

                <CurrencyInput
                  label="Partner Retirement Age"
                  value={profile.personal.partnerTargetRetirementAge || profile.personal.targetRetirementAge}
                  onChange={(val) => updatePersonal({ ...profile.personal, partnerTargetRetirementAge: val })}
                  prefix=""
                  step={1}
                />

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Partner Tax Region
                  </label>
                  <select
                    value={profile.personal.partnerTaxRegion || profile.personal.taxRegion}
                    onChange={(e) => updatePersonal({ ...profile.personal, partnerTaxRegion: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 font-medium bg-white"
                  >
                    <option value="england_wales_ni">England, Wales & NI</option>
                    <option value="scotland">Scotland</option>
                  </select>
                </div>
              </div>

              {/* Legal Relationship Selector for Statutory IHT & Tax Rules */}
              <div className="pt-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-emerald-800" /> Legal Relationship Status (UK Statutory Tax & IHT Rules)
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <label
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                      (profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType)
                        ? 'bg-emerald-50/70 border-emerald-500 shadow-2xs'
                        : 'bg-white border-slate-200 hover:bg-slate-100/50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="relationshipType"
                      checked={profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType}
                      onChange={() => updatePersonal({ ...profile.personal, relationshipType: 'spouse_civil_partner' })}
                      className="mt-1 text-emerald-800 focus:ring-emerald-700"
                    />
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-900 block">
                        Married / Registered Civil Partner
                      </span>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        ✓ <strong>100% Spousal IHT Exemption</strong> (s.18 IHTA 1984) on transfers.<br />
                        ✓ <strong>Transferable Nil-Rate Band</strong> & RNRB (up to £1,000,000 combined threshold).<br />
                        ✓ Capital Gains Tax no-gain-no-loss inter-spousal transfers.
                      </p>
                    </div>
                  </label>

                  <label
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                      profile.personal.relationshipType === 'unmarried_partner'
                        ? 'bg-amber-50/70 border-amber-500 shadow-2xs'
                        : 'bg-white border-slate-200 hover:bg-slate-100/50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="relationshipType"
                      checked={profile.personal.relationshipType === 'unmarried_partner'}
                      onChange={() => updatePersonal({ ...profile.personal, relationshipType: 'unmarried_partner' })}
                      className="mt-1 text-amber-600 focus:ring-amber-500"
                    />
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-900 block">
                        Unmarried Cohabiting Partner
                      </span>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        ⚠️ <strong>No Spousal IHT Exemption</strong> under UK law. Transferred assets in excess of individual £325k NRB are subject to 40% IHT.<br />
                        ⚠️ No transferable nil-rate band on death.
                      </p>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: EMPLOYMENT INCOMES */}
      {activeSection === 'employment' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">Employment & Salary Incomes</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Taxed under individual UK PAYE rules with automatic Personal Allowance tapering & Class 1 National Insurance.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveEmployment({
                    id: `emp-${Date.now()}`,
                    owner: 'primary',
                    label: '',
                    annualGross: 0,
                    annualBonus: 0,
                    employeePensionPercent: 0,
                    employerPensionPercent: 0,
                    isSalarySacrifice: false,
                    annualGrowthPercent: 2.0,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add Income Stream
              </button>
            </div>

            <div className="space-y-4">
              {profile.employment.map((emp) => (
                <div key={emp.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. Primary Salary / Employer Name"
                      value={emp.label}
                      onChange={(e) => saveEmployment({ ...emp, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: emp.label || 'Income Stream',
                          category: 'income stream',
                          onConfirm: () => deleteEmployment(emp.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${emp.label || 'income stream'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={emp.owner || 'primary'}
                    onChangeOwner={(o) => saveEmployment({ ...emp, owner: o as IndividualOwner })}
                    supportsJoint={false}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <CurrencyInput
                      label="Annual Gross Salary"
                      value={emp.annualGross}
                      onChange={(val) => saveEmployment({ ...emp, annualGross: val })}
                      step={1000}
                    />
                    <CurrencyInput
                      label="Annual Bonus"
                      value={emp.annualBonus}
                      onChange={(val) => saveEmployment({ ...emp, annualBonus: val })}
                      step={500}
                    />
                    <CurrencyInput
                      label="Employee Pension Contrib"
                      value={emp.employeePensionPercent}
                      onChange={(val) => saveEmployment({ ...emp, employeePensionPercent: val })}
                      prefix=""
                      suffix="%"
                      step={1}
                      max={80}
                    />
                    <CurrencyInput
                      label="Employer Pension Match"
                      value={emp.employerPensionPercent}
                      onChange={(val) => saveEmployment({ ...emp, employerPensionPercent: val })}
                      prefix=""
                      suffix="%"
                      step={1}
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-200/80 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={emp.isSalarySacrifice}
                        onChange={(e) => saveEmployment({ ...emp, isSalarySacrifice: e.target.checked })}
                        className="w-4 h-4 text-emerald-700 rounded border-slate-300"
                      />
                      <span className="font-medium text-slate-700">
                        Salary Sacrifice (Saves Employee & Employer NI)
                      </span>
                    </label>
                    <div className="flex items-center gap-2 text-slate-600">
                      <span>Annual Career Growth:</span>
                      <input
                        type="number"
                        value={emp.annualGrowthPercent}
                        onChange={(e) => saveEmployment({ ...emp, annualGrowthPercent: parseFloat(e.target.value) || 0 })}
                        className="w-16 px-2 py-1 bg-white border border-slate-200 rounded-lg text-center font-medium"
                        step={0.5}
                      />
                      <span>%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Real UK Tax Engine Breakdown Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {primaryTaxPreview && (
              <div className="bg-emerald-950 text-emerald-100 p-6 rounded-2xl shadow-xs space-y-4 border border-emerald-900">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                      {profile.personal.fullName || 'Primary Client'} — Tax & Take-Home
                    </h4>
                    <p className="text-[11px] text-emerald-400/80 mt-0.5">
                      2026/27 Tax Bands ({profile.personal.taxRegion === 'scotland' ? 'Scotland' : 'England/Wales/NI'})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-emerald-300 block">Take-Home Pay</span>
                    <span className="text-lg font-bold font-serif text-white">
                      £{Math.round(primaryTaxPreview.netIncome).toLocaleString('en-GB')}{' '}
                      <span className="text-xs font-normal text-emerald-400">
                        (£{Math.round(primaryTaxPreview.netIncome / 12).toLocaleString('en-GB')}/mo)
                      </span>
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-emerald-900 text-xs">
                  <div>
                    <span className="text-emerald-400 block">Income Tax</span>
                    <span className="font-semibold text-white">£{Math.round(primaryTaxPreview.totalIncomeTax).toLocaleString('en-GB')}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block">National Insurance</span>
                    <span className="font-semibold text-white">£{Math.round(primaryTaxPreview.nationalInsurance).toLocaleString('en-GB')}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block">Effective Rate</span>
                    <span className="font-semibold text-white">{primaryTaxPreview.effectiveTaxRatePercent.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block">Marginal Rate</span>
                    <span className="font-semibold text-white">{primaryTaxPreview.marginalTaxRatePercent}%</span>
                  </div>
                </div>
              </div>
            )}

            {partnerTaxPreview && (
              <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl shadow-xs space-y-4 border border-slate-800">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-teal-300">
                      {profile.personal.partnerName || 'Partner'} — Tax & Take-Home
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      2026/27 Tax Bands ({profile.personal.partnerTaxRegion === 'scotland' ? 'Scotland' : 'England/Wales/NI'})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-teal-300 block">Take-Home Pay</span>
                    <span className="text-lg font-bold font-serif text-white">
                      £{Math.round(partnerTaxPreview.netIncome).toLocaleString('en-GB')}{' '}
                      <span className="text-xs font-normal text-teal-400">
                        (£{Math.round(partnerTaxPreview.netIncome / 12).toLocaleString('en-GB')}/mo)
                      </span>
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-400 block">Income Tax</span>
                    <span className="font-semibold text-white">£{Math.round(partnerTaxPreview.totalIncomeTax).toLocaleString('en-GB')}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">National Insurance</span>
                    <span className="font-semibold text-white">£{Math.round(partnerTaxPreview.nationalInsurance).toLocaleString('en-GB')}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Effective Rate</span>
                    <span className="font-semibold text-white">{partnerTaxPreview.effectiveTaxRatePercent.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Marginal Rate</span>
                    <span className="font-semibold text-white">{partnerTaxPreview.marginalTaxRatePercent}%</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 3: EXPENSES & BUDGETS */}
      {activeSection === 'expenses' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-serif font-semibold text-slate-900">Expenses & Living Budget</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Model essential living costs, discretionary holidays, one-off single year outgoings, and custom retirement multipliers.
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                saveExpense({
                  id: `exp-${Date.now()}`,
                  owner: 'joint',
                  jointSplitPercent: 50,
                  label: '',
                  category: 'essential',
                  annualAmount: 0,
                  startAge: profile.personal.currentAge,
                  endAge: profile.personal.planningHorizonAge,
                  retirementMultiplier: 1.0,
                  isInflationLinked: true,
                  isSingleYear: false,
                })
              }
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add Expense Category
            </button>
          </div>

          <div className="space-y-4">
            {profile.expenses.map((exp) => {
              const isSingle = !!exp.isSingleYear;
              const currentAge = profile.personal.currentAge;
              const horizonAge = profile.personal.planningHorizonAge;
              const retAge = profile.personal.targetRetirementAge;
              const partnerRetAge = profile.personal.partnerTargetRetirementAge || 65;
              const clientName = profile.personal.fullName?.trim() || 'Client';
              const partnerName = profile.personal.partnerName?.trim() || 'Partner';

              // Calculate valid future milestone ages (multiples of 5 strictly >= currentAge)
              const firstMilestoneAge = Math.ceil(currentAge / 5) * 5 === currentAge ? currentAge + 5 : Math.ceil(currentAge / 5) * 5;
              const milestoneAges: number[] = [];
              for (let a = firstMilestoneAge; a <= Math.min(100, horizonAge); a += 5) {
                milestoneAges.push(a);
              }

              // End age milestones strictly >= currentAge and >= exp.startAge
              const minEndMilestone = Math.ceil(Math.max(currentAge, exp.startAge) / 5) * 5;
              const endMilestoneAges: number[] = [];
              for (let a = minEndMilestone; a <= Math.min(100, horizonAge); a += 5) {
                if (a > exp.startAge) {
                  endMilestoneAges.push(a);
                }
              }

              return (
                <div key={exp.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 flex-1">
                      <input
                        type="text"
                        placeholder="e.g. Essential Groceries & Utilities / Travel"
                        value={exp.label}
                        onChange={(e) => saveExpense({ ...exp, label: e.target.value })}
                        className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                      />
                      {isSingle && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 whitespace-nowrap">
                          Single Year Outflow
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: exp.label || 'Expense',
                          category: 'expense',
                          onConfirm: () => deleteExpense(exp.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${exp.label || 'expense'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={exp.owner || 'joint'}
                    onChangeOwner={(o) => saveExpense({ ...exp, owner: o })}
                    supportsJoint={true}
                    jointSplitPercent={exp.jointSplitPercent ?? 50}
                    onChangeJointSplit={(pct) => saveExpense({ ...exp, jointSplitPercent: pct })}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <CurrencyInput
                      label="Annual Outflow (£)"
                      value={exp.annualAmount}
                      onChange={(val) => saveExpense({ ...exp, annualAmount: val })}
                      step={500}
                    />

                    {/* Start Age Dropdown */}
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Start Age
                      </label>
                      <select
                        value={
                          isSingle
                            ? 'single'
                            : exp.startAge === currentAge
                            ? 'current'
                            : exp.startAge === retAge && retAge >= currentAge
                            ? 'ret_primary'
                            : profile.personal.hasPartner && exp.startAge === partnerRetAge && partnerRetAge >= currentAge
                            ? 'ret_partner'
                            : milestoneAges.includes(exp.startAge)
                            ? String(exp.startAge)
                            : 'custom'
                        }
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === 'single') {
                            saveExpense({
                              ...exp,
                              isSingleYear: true,
                              startAge: currentAge,
                              endAge: currentAge,
                            });
                          } else if (val === 'current') {
                            saveExpense({
                              ...exp,
                              isSingleYear: false,
                              startAge: currentAge,
                            });
                          } else if (val === 'ret_primary') {
                            saveExpense({
                              ...exp,
                              isSingleYear: false,
                              startAge: retAge,
                            });
                          } else if (val === 'ret_partner') {
                            saveExpense({
                              ...exp,
                              isSingleYear: false,
                              startAge: partnerRetAge,
                            });
                          } else if (val === 'custom') {
                            saveExpense({
                              ...exp,
                              isSingleYear: false,
                            });
                          } else {
                            saveExpense({
                              ...exp,
                              isSingleYear: false,
                              startAge: Number(val),
                            });
                          }
                        }}
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                      >
                        <option value="current">Current Age ({currentAge})</option>
                        {retAge >= currentAge && (
                          <option value="ret_primary">{clientName} Retirement Age ({retAge})</option>
                        )}
                        {profile.personal.hasPartner && partnerRetAge >= currentAge && (
                          <option value="ret_partner">{partnerName} Retirement Age ({partnerRetAge})</option>
                        )}
                        <option value="single">SINGLE (One-Off Single Year)</option>
                        {milestoneAges.map((ageOption) => (
                          <option key={ageOption} value={String(ageOption)}>
                            Age {ageOption}
                          </option>
                        ))}
                        <option value="custom">Custom Age...</option>
                      </select>
                      {!isSingle && (
                        <div className="mt-1 flex items-center gap-1.5">
                          <span className="text-[11px] text-slate-500">Exact Age:</span>
                          <input
                            type="number"
                            min={currentAge}
                            max={horizonAge}
                            value={exp.startAge}
                            onChange={(e) => saveExpense({ ...exp, startAge: Math.max(currentAge, Number(e.target.value) || currentAge) })}
                            className="w-16 rounded-lg border border-slate-300 px-2 py-0.5 text-xs text-slate-900 font-semibold bg-white"
                          />
                        </div>
                      )}
                    </div>

                    {/* End Age Dropdown (Hidden if isSingleYear) */}
                    {!isSingle ? (
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                          End Age
                        </label>
                        <select
                          value={
                            exp.endAge === horizonAge
                              ? 'horizon'
                              : exp.endAge === retAge && retAge >= currentAge
                              ? 'ret_primary'
                              : profile.personal.hasPartner && exp.endAge === partnerRetAge && partnerRetAge >= currentAge
                              ? 'ret_partner'
                              : endMilestoneAges.includes(exp.endAge)
                              ? String(exp.endAge)
                              : 'custom'
                          }
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === 'horizon') {
                              saveExpense({ ...exp, endAge: horizonAge });
                            } else if (val === 'ret_primary') {
                              saveExpense({ ...exp, endAge: retAge });
                            } else if (val === 'ret_partner') {
                              saveExpense({ ...exp, endAge: partnerRetAge });
                            } else if (val !== 'custom') {
                              saveExpense({ ...exp, endAge: Number(val) });
                            }
                          }}
                          className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                        >
                          <option value="horizon">Life Expectancy ({horizonAge})</option>
                          {retAge >= currentAge && (
                            <option value="ret_primary">{clientName} Retirement Age ({retAge})</option>
                          )}
                          {profile.personal.hasPartner && partnerRetAge >= currentAge && (
                            <option value="ret_partner">{partnerName} Retirement Age ({partnerRetAge})</option>
                          )}
                          {endMilestoneAges.map((ageOption) => (
                            <option key={ageOption} value={String(ageOption)}>
                              Age {ageOption}
                            </option>
                          ))}
                          <option value="custom">Custom Age...</option>
                        </select>
                        <div className="mt-1 flex items-center gap-1.5">
                          <span className="text-[11px] text-slate-500">Exact Age:</span>
                          <input
                            type="number"
                            min={exp.startAge}
                            max={horizonAge}
                            value={exp.endAge}
                            onChange={(e) => saveExpense({ ...exp, endAge: Math.max(exp.startAge, Number(e.target.value) || horizonAge) })}
                            className="w-16 rounded-lg border border-slate-300 px-2 py-0.5 text-xs text-slate-900 font-semibold bg-white"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200 flex flex-col justify-center">
                        <span className="text-xs font-semibold text-slate-700">Duration: Single Year</span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Occurs only at Age {exp.startAge} and does not recur.
                        </p>
                      </div>
                    )}

                    {!isSingle ? (
                      <CurrencyInput
                        label="Retirement Multiplier"
                        value={Math.round(exp.retirementMultiplier * 100)}
                        onChange={(val) => saveExpense({ ...exp, retirementMultiplier: val / 100 })}
                        prefix=""
                        suffix="%"
                        step={5}
                        helperText="e.g. 80% for reduced costs in retirement"
                      />
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200 flex flex-col justify-center">
                        <span className="text-xs font-semibold text-slate-700">Pre/Post Retirement</span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Multiplier fixed at 100% for single-year events.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 4: KEY ONE-OFF LIFE EVENTS TIMELINE */}
      {activeSection === 'lifeEvents' && <LifeEventsManager />}

      {/* SECTION 5: DEFINED CONTRIBUTION & DEFINED BENEFIT PENSIONS */}
      {activeSection === 'pensions' && (
        <div className="space-y-6">
          {/* DC Pensions */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">Defined Contribution (DC) Pensions & SIPPs</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Tax-free growth with 25% tax-free lump sum up to the £268,275 Lump Sum Allowance (LSA). Default growth rate: 4.0% (after fees).
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveDcPension({
                    id: `pen-${Date.now()}`,
                    owner: 'primary',
                    label: '',
                    currentPotValue: 0,
                    ongoingMonthlyContribution: 0,
                    ongoingEmployerMonthlyContribution: 0,
                    growthRatePercent: 4.0,
                    annualFeePercent: 0.0,
                    taxFreeCashTakenPercent: 0,
                    isTargetForDrawdown: true,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add DC Pension
              </button>
            </div>

            <div className="space-y-4">
              {profile.dcPensions.map((pen) => (
                <div key={pen.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. Provider / SIPP Scheme Name"
                      value={pen.label}
                      onChange={(e) => saveDcPension({ ...pen, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: pen.label || 'Pension Pot',
                          category: 'pension pot',
                          onConfirm: () => deleteDcPension(pen.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${pen.label || 'pension pot'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={pen.owner || 'primary'}
                    onChangeOwner={(o) => saveDcPension({ ...pen, owner: o as IndividualOwner })}
                    supportsJoint={false}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <CurrencyInput
                      label="Current Pot Value"
                      value={pen.currentPotValue}
                      onChange={(val) => saveDcPension({ ...pen, currentPotValue: val })}
                      step={5000}
                    />
                    <GrowthRateSelector
                      label="Expected Annual Growth"
                      value={pen.growthRatePercent}
                      onChange={(val) => saveDcPension({ ...pen, growthRatePercent: val })}
                      defaultRate={4.0}
                      helperText="Default 4.0% (after fees)"
                    />
                    <CurrencyInput
                      label="Platform & Fund Fee"
                      value={pen.annualFeePercent}
                      onChange={(val) => saveDcPension({ ...pen, annualFeePercent: val })}
                      prefix=""
                      suffix="%"
                      step={0.05}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* DB Pensions */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">Defined Benefit (DB) / Final Salary Pensions</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Guaranteed indexed annual income in retirement (e.g. NHS, Teachers, Civil Service, USS).
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveDbPension({
                    id: `db-${Date.now()}`,
                    owner: 'primary',
                    label: '',
                    annualGuaranteedIncome: 0,
                    startAge: profile.personal.targetRetirementAge || 65,
                    annualEscalationPercent: 2.0,
                    lumpSumOption: 0,
                    spousesBenefitPercent: 50,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add DB Pension
              </button>
            </div>

            <div className="space-y-4">
              {profile.dbPensions.map((db) => (
                <div key={db.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. DB Final Salary Scheme (NHS, USS, Civil Service)"
                      value={db.label}
                      onChange={(e) => saveDbPension({ ...db, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: db.label || 'DB pension',
                          category: 'DB pension',
                          onConfirm: () => deleteDbPension(db.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${db.label || 'DB pension'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={db.owner || 'primary'}
                    onChangeOwner={(o) => saveDbPension({ ...db, owner: o as IndividualOwner })}
                    supportsJoint={false}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <CurrencyInput
                      label="Annual Guaranteed Income"
                      value={db.annualGuaranteedIncome}
                      onChange={(val) => saveDbPension({ ...db, annualGuaranteedIncome: val })}
                      step={500}
                    />
                    <CurrencyInput
                      label="Payment Start Age"
                      value={db.startAge}
                      onChange={(val) => saveDbPension({ ...db, startAge: val })}
                      prefix=""
                      step={1}
                    />
                    <CurrencyInput
                      label="Annual Escalation Rate"
                      value={db.annualEscalationPercent}
                      onChange={(val) => saveDbPension({ ...db, annualEscalationPercent: val })}
                      prefix=""
                      suffix="%"
                      step={0.1}
                      helperText="Default CPI 2.0%"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 6: CASH, ISAS, GIAS & SPECIALIST INVESTMENTS */}
      {activeSection === 'investments' && (
        <div className="space-y-6">
          {/* 1. Cash Reserves & NS&I - Displayed FIRST */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">Cash Accounts, NS&I & Premium Bonds</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Liquid cash bank accounts, fixed-term cash deposits, National Savings & Investments (NS&I), and Premium Bonds. Can be held solely or jointly. Default cash benchmark: 2.0%.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveCash({
                    id: `cash-${Date.now()}`,
                    owner: 'primary',
                    jointSplitPercent: 50,
                    label: '',
                    balance: 0,
                    interestRatePercent: 2.0,
                    isEmergencyFund: false,
                    minimumReserve: 0,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add Cash / NS&I Account
              </button>
            </div>

            <div className="space-y-4">
              {profile.cashAccounts.map((cash) => (
                <div key={cash.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. Bank Savings / Premium Bonds / NS&I Direct Saver"
                      value={cash.label}
                      onChange={(e) => saveCash({ ...cash, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: cash.label || 'Cash Account',
                          category: 'cash account',
                          onConfirm: () => deleteCash(cash.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${cash.label || 'cash account'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={cash.owner || 'primary'}
                    onChangeOwner={(o) => saveCash({ ...cash, owner: o })}
                    supportsJoint={true}
                    jointSplitPercent={cash.jointSplitPercent ?? 50}
                    onChangeJointSplit={(pct) => saveCash({ ...cash, jointSplitPercent: pct })}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <CurrencyInput
                      label="Cash Balance"
                      value={cash.balance}
                      onChange={(val) => saveCash({ ...cash, balance: val })}
                      step={1000}
                    />
                    <GrowthRateSelector
                      label="Interest / Yield Rate"
                      value={cash.interestRatePercent}
                      onChange={(val) => saveCash({ ...cash, interestRatePercent: val })}
                      defaultRate={2.0}
                      presets={[0, 1, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0]}
                      helperText="Default 2.0% benchmark for cash / NS&I"
                    />
                    <CurrencyInput
                      label="Minimum Reserve Protection"
                      value={cash.minimumReserve}
                      onChange={(val) => saveCash({ ...cash, minimumReserve: val })}
                      step={1000}
                      helperText="Never drawn down below this level"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 2. Stocks & Shares ISAs */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">Stocks & Shares ISAs</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  100% Tax-Free growth and withdrawals (Annual Allowance: £20,000 per person). ISAs are strictly individual under UK law. Default growth rate: 4.0% (after fees).
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveIsa({
                    id: `isa-${Date.now()}`,
                    owner: 'primary',
                    label: '',
                    balance: 0,
                    ongoingMonthlyContribution: 0,
                    growthRatePercent: 4.0,
                    annualFeePercent: 0.0,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add ISA Account
              </button>
            </div>

            <div className="space-y-4">
              {profile.isas.map((isa) => (
                <div key={isa.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. Stocks & Shares ISA (Provider / Platform)"
                      value={isa.label}
                      onChange={(e) => saveIsa({ ...isa, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: isa.label || 'ISA Account',
                          category: 'ISA account',
                          onConfirm: () => deleteIsa(isa.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${isa.label || 'ISA account'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={isa.owner || 'primary'}
                    onChangeOwner={(o) => saveIsa({ ...isa, owner: o as IndividualOwner })}
                    supportsJoint={false}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <CurrencyInput
                      label="Current Balance"
                      value={isa.balance}
                      onChange={(val) => saveIsa({ ...isa, balance: val })}
                      step={2000}
                    />
                    <CurrencyInput
                      label="Monthly Ongoing Contribution"
                      value={isa.ongoingMonthlyContribution}
                      onChange={(val) => saveIsa({ ...isa, ongoingMonthlyContribution: val })}
                      step={50}
                    />
                    <GrowthRateSelector
                      label="Annual Growth Rate"
                      value={isa.growthRatePercent}
                      onChange={(val) => saveIsa({ ...isa, growthRatePercent: val })}
                      defaultRate={4.0}
                      helperText="Default 4.0% (after fees)"
                    />
                  </div>

                  {/* Bed & ISA Funding Source */}
                  {isa.ongoingMonthlyContribution > 0 && (
                    <div className="pt-2 border-t border-slate-200">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Contribution Funding Source (Bed & ISA Transfer)
                      </label>
                      <select
                        value={isa.fundingSource || 'cash'}
                        onChange={(e) => saveIsa({ ...isa, fundingSource: e.target.value })}
                        className="w-full sm:w-auto min-w-[320px] rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                      >
                        <option value="cash">From Cash Funds / Surplus Monthly Income</option>
                        {profile.gias.map((g) => (
                          <option key={g.id} value={g.id}>
                            Transfer from {g.label || 'GIA Account'} (Bed & ISA)
                          </option>
                        ))}
                      </select>
                      <p className="text-[11px] text-slate-500 mt-1">
                        {isa.fundingSource && isa.fundingSource !== 'cash'
                          ? `✓ Bed & ISA active: £${(isa.ongoingMonthlyContribution * 12).toLocaleString('en-GB')}/yr is drawn annually from the selected GIA (realising capital gains if applicable) to max out this ISA.`
                          : 'Standard funding from earned surplus cash flow.'}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 3. GIAs - General Investment Accounts */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">General Investment Accounts (GIAs)</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Taxable unwrapped investment accounts subject to UK CGT (£3,000 allowance) and Dividend Tax (£500 allowance). Can be held solely or jointly.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveGia({
                    id: `gia-${Date.now()}`,
                    owner: 'primary',
                    jointSplitPercent: 50,
                    label: '',
                    balance: 0,
                    costBasis: 0,
                    ongoingMonthlyContribution: 0,
                    growthRatePercent: 4.0,
                    dividendYieldPercent: 0.0,
                    annualFeePercent: 0.0,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add GIA Account
              </button>
            </div>

            <div className="space-y-4">
              {profile.gias.map((gia) => (
                <div key={gia.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="e.g. General Investment Account (Platform)"
                      value={gia.label}
                      onChange={(e) => saveGia({ ...gia, label: e.target.value })}
                      className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: gia.label || 'GIA Account',
                          category: 'GIA account',
                          onConfirm: () => deleteGia(gia.id),
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${gia.label || 'GIA account'}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <OwnershipSelector
                    owner={gia.owner || 'primary'}
                    onChangeOwner={(o) => saveGia({ ...gia, owner: o })}
                    supportsJoint={true}
                    jointSplitPercent={gia.jointSplitPercent ?? 50}
                    onChangeJointSplit={(pct) => saveGia({ ...gia, jointSplitPercent: pct })}
                    primaryName={profile.personal.fullName}
                    partnerName={profile.personal.partnerName}
                    hasPartner={profile.personal.hasPartner}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <CurrencyInput
                      label="Current Balance"
                      value={gia.balance}
                      onChange={(val) => saveGia({ ...gia, balance: val })}
                      step={2000}
                    />
                    <CurrencyInput
                      label="Cost Basis (Purchase Price)"
                      value={gia.costBasis}
                      onChange={(val) => saveGia({ ...gia, costBasis: val })}
                      step={2000}
                      helperText="Original acquisition base for CGT"
                    />
                    <GrowthRateSelector
                      label="Annual Growth Rate"
                      value={gia.growthRatePercent}
                      onChange={(val) => saveGia({ ...gia, growthRatePercent: val })}
                      defaultRate={4.0}
                      helperText="Default 4.0% (after fees)"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Onshore & Offshore Investment Bonds (5% Tax-Deferred Allowance) */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900 flex items-center gap-2">
                  Onshore & Offshore Investment Bonds
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                    5% Tax-Deferred Allowance
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed max-w-3xl">
                  UK Onshore Life Assurance Bonds (with 20% internal notional tax credit treated as paid) and International Offshore Life Assurance Bonds (gross roll-up). Both provide statutory 5% cumulative annual tax-deferred withdrawals of original capital for up to 20 years (100% total) with Top Slicing Relief across policy years.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() =>
                    saveInvestmentBond({
                      id: `bond-${Date.now()}`,
                      owner: 'primary',
                      jointSplitPercent: 50,
                      label: '',
                      bondType: 'onshore',
                      originalPremium: 0,
                      currentValue: 0,
                      yearsHeld: 0,
                      cumulativeWithdrawalsTaken: 0,
                      annualWithdrawalPercent: 0,
                      annualWithdrawalAmount: 0,
                      growthRatePercent: 4.0,
                      annualFeePercent: 0.5,
                      heldInTrust: false,
                      trustType: 'none',
                    })
                  }
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors whitespace-nowrap shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Onshore Bond
                </button>
                <button
                  type="button"
                  onClick={() =>
                    saveInvestmentBond({
                      id: `bond-${Date.now()}`,
                      owner: 'primary',
                      jointSplitPercent: 50,
                      label: '',
                      bondType: 'offshore',
                      originalPremium: 0,
                      currentValue: 0,
                      yearsHeld: 0,
                      cumulativeWithdrawalsTaken: 0,
                      annualWithdrawalPercent: 0,
                      annualWithdrawalAmount: 0,
                      growthRatePercent: 4.0,
                      annualFeePercent: 0.5,
                      heldInTrust: false,
                      trustType: 'none',
                    })
                  }
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-teal-800 text-white rounded-xl hover:bg-teal-900 transition-colors whitespace-nowrap shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Offshore Bond
                </button>
              </div>
            </div>

            {(!profile.investmentBonds || profile.investmentBonds.length === 0) ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-2">
                <p className="text-xs text-slate-600 font-medium">
                  No Onshore or Offshore Investment Bonds added yet.
                </p>
                <p className="text-[11px] text-slate-400 max-w-xl mx-auto">
                  Add a UK Onshore Bond (e.g. Prudential, Quilter, Aviva) or International Offshore Bond (e.g. Utmost, Quilter International, Canada Life) to model 5% tax-deferred income streams, trust assignments, and top-slicing relief.
                </p>
              </div>
            ) : (
              <div className="space-y-5">
                {profile.investmentBonds.map((bond) => {
                  const taxSummary = calculateInvestmentBondTaxSummary({
                    bondType: bond.bondType,
                    originalPremium: bond.originalPremium,
                    currentValue: bond.currentValue,
                    yearsHeld: bond.yearsHeld,
                    cumulativeWithdrawalsTaken: bond.cumulativeWithdrawalsTaken,
                    annualWithdrawalAmount: bond.annualWithdrawalAmount,
                    annualWithdrawalPercent: bond.annualWithdrawalPercent,
                    investorMarginalTaxRatePercent: 40,
                  });

                  const isOffshore = bond.bondType === 'offshore';

                  return (
                    <div
                      key={bond.id}
                      className="p-5 sm:p-6 rounded-2xl bg-slate-50/90 border border-slate-200 space-y-5 shadow-2xs"
                    >
                      {/* Header & Delete */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                        <div className="flex items-center gap-3 flex-1">
                          <input
                            type="text"
                            placeholder={isOffshore ? 'e.g. Quilter International Executive Bond' : 'e.g. Prudential Onshore Investment Bond'}
                            value={bond.label}
                            onChange={(e) => saveInvestmentBond({ ...bond, label: e.target.value })}
                            className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                          />
                          <span
                            className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border ${
                              isOffshore
                                ? 'bg-teal-50 text-teal-800 border-teal-200'
                                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            }`}
                          >
                            {isOffshore ? '🌐 Offshore Bond (Gross Roll-Up)' : '🇬🇧 Onshore UK Bond (20% Notional Credit)'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setDeleteModal({
                              isOpen: true,
                              title: bond.label || (isOffshore ? 'Offshore Bond' : 'Onshore Bond'),
                              category: 'investment bond',
                              onConfirm: () => deleteInvestmentBond(bond.id),
                            })
                          }
                          className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors self-end sm:self-auto"
                          aria-label={`Delete ${bond.label || 'investment bond'}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Bond Jurisdiction & Ownership */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Bond Tax Structure & Jurisdiction
                          </label>
                          <select
                            value={bond.bondType}
                            onChange={(e) =>
                              saveInvestmentBond({
                                ...bond,
                                bondType: e.target.value as InvestmentBondType,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          >
                            <option value="onshore">🇬🇧 UK Onshore Life Assurance Bond (20% Notional Basic Rate Tax Credit)</option>
                            <option value="offshore">🌐 Offshore / International Life Assurance Bond (Gross Roll-Up)</option>
                          </select>
                        </div>

                        <OwnershipSelector
                          owner={bond.owner || 'primary'}
                          onChangeOwner={(o) => saveInvestmentBond({ ...bond, owner: o })}
                          supportsJoint={true}
                          jointSplitPercent={bond.jointSplitPercent ?? 50}
                          onChangeJointSplit={(pct) => saveInvestmentBond({ ...bond, jointSplitPercent: pct })}
                          primaryName={profile.personal.fullName}
                          partnerName={profile.personal.partnerName}
                          hasPartner={profile.personal.hasPartner}
                        />
                      </div>

                      {/* Valuation, Premium, Years Held & Withdrawals */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <CurrencyInput
                          label="Original Investment Premium"
                          value={bond.originalPremium}
                          onChange={(val) => saveInvestmentBond({ ...bond, originalPremium: val })}
                          step={5000}
                          helperText="Base for 5% statutory allowance"
                        />
                        <CurrencyInput
                          label="Current Valuation / Market Value"
                          value={bond.currentValue}
                          onChange={(val) => saveInvestmentBond({ ...bond, currentValue: val })}
                          step={5000}
                        />
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Policy Years Held
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={50}
                            step={1}
                            value={bond.yearsHeld ?? 1}
                            onChange={(e) =>
                              saveInvestmentBond({
                                ...bond,
                                yearsHeld: Math.max(0, parseInt(e.target.value, 10) || 0),
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                          <p className="text-[10px] text-slate-500 mt-1">
                            Divisor for Top Slicing Relief
                          </p>
                        </div>
                        <CurrencyInput
                          label="Cumulative 5% Taken to Date"
                          value={bond.cumulativeWithdrawalsTaken || 0}
                          onChange={(val) => saveInvestmentBond({ ...bond, cumulativeWithdrawalsTaken: val })}
                          step={1000}
                          helperText="Total £ already taken tax-deferred"
                        />
                      </div>

                      {/* Planned Regular Annual Withdrawal & Growth */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Planned Annual Tax-Deferred Withdrawal (%)
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            step={0.5}
                            value={bond.annualWithdrawalPercent ?? 5.0}
                            onChange={(e) =>
                              saveInvestmentBond({
                                ...bond,
                                annualWithdrawalPercent: parseFloat(e.target.value) || 0,
                                annualWithdrawalAmount: 0,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                          <p className="text-[10px] text-slate-500 mt-1">
                            Standard statutory benchmark: 5.0% (£{((bond.originalPremium * 0.05) || 0).toLocaleString('en-GB')}/yr)
                          </p>
                        </div>

                        <GrowthRateSelector
                          label="Annual Investment Growth Rate"
                          value={bond.growthRatePercent}
                          onChange={(val) => saveInvestmentBond({ ...bond, growthRatePercent: val })}
                          defaultRate={4.0}
                          helperText="Default 4.0% gross return"
                        />

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Annual Fee / AMC (%)
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={10}
                            step={0.05}
                            value={bond.annualFeePercent ?? 0.5}
                            onChange={(e) =>
                              saveInvestmentBond({
                                ...bond,
                                annualFeePercent: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                          <p className="text-[10px] text-slate-500 mt-1">
                            Product & investment management fee
                          </p>
                        </div>
                      </div>

                      {/* Trust & Estate Planning Option */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Estate & IHT Trust Structure
                          </label>
                          <select
                            value={bond.trustType || 'none'}
                            onChange={(e) =>
                              saveInvestmentBond({
                                ...bond,
                                trustType: e.target.value as BondTrustType,
                                heldInTrust: e.target.value !== 'none',
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          >
                            <option value="none">Direct Ownership (Included in Personal Estate for IHT)</option>
                            <option value="discretionary">Discretionary Trust (Relevant Property Regime / Periodic Charges)</option>
                            <option value="loan_trust">Loan Trust (Original loan stays in estate, all investment growth outside)</option>
                            <option value="discounted_gift_trust">Discounted Gift Trust (DGT) (Retained lifetime income discount)</option>
                            <option value="bare_trust">Bare Trust / Absolute Trust (Beneficiary absolute entitlement)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Adviser Notes & Policy Segments
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. 100 identical segments, assigned to beneficiaries in 2028"
                            value={bond.notes || ''}
                            onChange={(e) => saveInvestmentBond({ ...bond, notes: e.target.value })}
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                        </div>
                      </div>

                      {/* Statutory 5% Tax-Deferred Allowance Live Metrics Panel */}
                      <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                            ⚡ Statutory 5% Tax-Deferred Allowance Status (ITTOIA 2005 s.498)
                          </span>
                          <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200">
                            {taxSummary.isWithdrawalWithin5Percent
                              ? '✓ 100% Tax-Deferred (Zero Immediate Tax)'
                              : '⚠️ Excess Withdrawal Triggers Chargeable Gain'}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                            <span className="text-[10px] text-slate-500 block">Annual 5% Allowance</span>
                            <span className="font-bold text-slate-900 text-sm">
                              £{taxSummary.annual5PercentAllowance.toLocaleString('en-GB')} / yr
                            </span>
                          </div>

                          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                            <span className="text-[10px] text-slate-500 block">Accrued Cumulative ({Math.min(20, Math.max(1, bond.yearsHeld || 1))} yrs)</span>
                            <span className="font-bold text-slate-900 text-sm">
                              £{taxSummary.cumulativeAllowanceTotal.toLocaleString('en-GB')}
                            </span>
                          </div>

                          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                            <span className="text-[10px] text-slate-500 block">Remaining Allowance</span>
                            <span className="font-bold text-emerald-700 text-sm">
                              £{taxSummary.remainingCumulativeAllowance.toLocaleString('en-GB')}
                            </span>
                          </div>

                          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                            <span className="text-[10px] text-slate-500 block">Top Slicing Divisor</span>
                            <span className="font-bold text-slate-900 text-sm">
                              {taxSummary.topSlicingDivisor} {taxSummary.topSlicingDivisor === 1 ? 'Year' : 'Years'}
                            </span>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-600 leading-relaxed pt-1">
                          {taxSummary.taxDescription}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 5. Specialist & Direct Investments (EIS / VCT / SEIS / Direct Shares / Other) */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-semibold text-slate-900">
                  Specialist & Direct Investments (EIS, VCT, SEIS, Direct Shares & Other)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Venture Capital Trusts (VCT), Enterprise Investment Schemes (EIS/SEIS), Direct Shares PLC, Direct Shares Private, and unlisted alternative investments. Includes statutory cost basis tracking for CGT calculations.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveOtherInvestment({
                    id: `other-inv-${Date.now()}`,
                    owner: 'primary',
                    jointSplitPercent: 50,
                    label: '',
                    investmentType: 'eis',
                    balance: 0,
                    costBasis: 0,
                    growthRatePercent: 4.0,
                    dividendYieldPercent: 0.0,
                    annualFeePercent: 0.0,
                  })
                }
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors whitespace-nowrap self-start sm:self-auto"
              >
                <Plus className="w-3.5 h-3.5" /> Add Specialist Investment
              </button>
            </div>

            {(!profile.otherInvestments || profile.otherInvestments.length === 0) ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-2">
                <p className="text-xs text-slate-600 font-medium">
                  No specialist or direct share investments added yet.
                </p>
                <p className="text-[11px] text-slate-400">
                  Add Enterprise Investment Schemes (EIS), Venture Capital Trusts (VCT), SEIS, Direct Shares PLC, Private Shares, or other alternative assets to model their tax relief and CGT cost basis.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {profile.otherInvestments.map((item) => {
                  const typeNotes: Record<SpecialistInvestmentType, { name: string; badge: string; color: string }> = {
                    eis: {
                      name: 'EIS (Enterprise Investment Scheme)',
                      badge: '🛡️ EIS Tax Benefits: 30% Income Tax Relief + 100% CGT Exemption upon exit (held 3+ yrs) + 100% IHT Business Relief (BR) after 2 years.',
                      color: 'bg-emerald-50 text-emerald-900 border-emerald-200',
                    },
                    vct: {
                      name: 'VCT (Venture Capital Trust)',
                      badge: '🛡️ VCT Tax Benefits: 30% Income Tax Relief + 100% CGT Exemption on disposal + 100% Tax-Free dividend distributions up to £200k/yr.',
                      color: 'bg-teal-50 text-teal-900 border-teal-200',
                    },
                    seis: {
                      name: 'SEIS (Seed Enterprise Investment Scheme)',
                      badge: '🛡️ SEIS Tax Benefits: 50% Income Tax Relief + 100% CGT Exemption on exit (held 3+ yrs) + 50% CGT Reinvestment Relief on gains from other assets.',
                      color: 'bg-amber-50 text-amber-900 border-amber-200',
                    },
                    onshore_bond: {
                      name: 'Onshore UK Investment Bond',
                      badge: '🇬🇧 UK Life Assurance Bond: 5% annual cumulative tax-deferred withdrawal allowance. 20% basic rate tax credit treated as paid internally; Top Slicing Relief across policy years.',
                      color: 'bg-emerald-50 text-emerald-900 border-emerald-200',
                    },
                    offshore_bond: {
                      name: 'Offshore International Investment Bond',
                      badge: '🌐 Offshore Life Assurance Bond: 5% annual cumulative tax-deferred withdrawal allowance. Gross roll-up during investment growth; gains taxed at income tax rates on encashment with Top Slicing Relief.',
                      color: 'bg-teal-50 text-teal-900 border-teal-200',
                    },
                    direct_shares_plc: {
                      name: 'Direct Shares PLC (Public Equities)',
                      badge: '📊 Quoted Direct Shares: Subject to UK CGT (18% Basic / 24% Higher Rate, £3,000 Annual Exemption) and Dividend Tax.',
                      color: 'bg-blue-50 text-blue-900 border-blue-200',
                    },
                    direct_shares_private: {
                      name: 'Direct Shares Private (Unquoted Equities)',
                      badge: '💼 Unquoted Private Shares: Subject to UK CGT. May qualify for Business Asset Disposal Relief (BADR at 10% / 14% / 18%) or Business Relief (BR for IHT).',
                      color: 'bg-purple-50 text-purple-900 border-purple-200',
                    },
                    other: {
                      name: 'Other Investment / Alternative Asset',
                      badge: '🏷️ Other Alternative Investment: Subject to standard UK Capital Gains Tax upon disposal.',
                      color: 'bg-slate-100 text-slate-800 border-slate-300',
                    },
                  };

                  const currentType = item.investmentType || 'other';
                  const noteInfo = typeNotes[currentType] || typeNotes.other;

                  return (
                    <div key={item.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                      <div className="flex items-center justify-between gap-3">
                        <input
                          type="text"
                          placeholder="e.g. Octopus Titan VCT / Seedrs Tech EIS / Apple Direct Shares"
                          value={item.label}
                          onChange={(e) => saveOtherInvestment({ ...item, label: e.target.value })}
                          className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setDeleteModal({
                              isOpen: true,
                              title: item.label || 'Specialist Investment',
                              category: 'specialist investment',
                              onConfirm: () => deleteOtherInvestment(item.id),
                            })
                          }
                          className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                          aria-label={`Delete ${item.label || 'investment'}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Investment Classification & Ownership */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Investment Classification
                          </label>
                          <select
                            value={item.investmentType || 'eis'}
                            onChange={(e) =>
                              saveOtherInvestment({
                                ...item,
                                investmentType: e.target.value as SpecialistInvestmentType,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          >
                            <option value="eis">EIS (Enterprise Investment Scheme)</option>
                            <option value="vct">VCT (Venture Capital Trust)</option>
                            <option value="seis">SEIS (Seed Enterprise Investment Scheme)</option>
                            <option value="onshore_bond">Onshore UK Investment Bond (5% Tax-Deferred Allowance)</option>
                            <option value="offshore_bond">Offshore Investment Bond (Gross Roll-Up)</option>
                            <option value="direct_shares_plc">Direct Shares PLC (Public Listed Equities)</option>
                            <option value="direct_shares_private">Direct Shares Private (Unquoted Private Company)</option>
                            <option value="other">Other Investment (Unlisted / Alternative / Private Equity)</option>
                          </select>
                        </div>

                        <OwnershipSelector
                          owner={item.owner || 'primary'}
                          onChangeOwner={(o) => saveOtherInvestment({ ...item, owner: o })}
                          supportsJoint={true}
                          jointSplitPercent={item.jointSplitPercent ?? 50}
                          onChangeJointSplit={(pct) => saveOtherInvestment({ ...item, jointSplitPercent: pct })}
                          primaryName={profile.personal.fullName}
                          partnerName={profile.personal.partnerName}
                          hasPartner={profile.personal.hasPartner}
                        />
                      </div>

                      {/* Valuation, Cost Basis & Growth Rate */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <CurrencyInput
                          label="Current Market Value"
                          value={item.balance}
                          onChange={(val) => saveOtherInvestment({ ...item, balance: val })}
                          step={2000}
                        />
                        <CurrencyInput
                          label="Cost Basis (Purchase Price)"
                          value={item.costBasis}
                          onChange={(val) => saveOtherInvestment({ ...item, costBasis: val })}
                          step={2000}
                          helperText="Original acquisition base for CGT"
                        />
                        <GrowthRateSelector
                          label="Annual Growth Rate"
                          value={item.growthRatePercent}
                          onChange={(val) => saveOtherInvestment({ ...item, growthRatePercent: val })}
                          defaultRate={4.0}
                          helperText="Default 4.0% benchmark"
                        />
                      </div>

                      {/* Yield & Fee */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Annual Dividend / Income Yield (%)
                          </label>
                          <input
                            type="number"
                            step={0.1}
                            min={0}
                            max={20}
                            value={item.dividendYieldPercent || 0}
                            onChange={(e) =>
                              saveOtherInvestment({
                                ...item,
                                dividendYieldPercent: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Annual Management / Platform Fee (%)
                          </label>
                          <input
                            type="number"
                            step={0.05}
                            min={0}
                            max={10}
                            value={item.annualFeePercent || 0}
                            onChange={(e) =>
                              saveOtherInvestment({
                                ...item,
                                annualFeePercent: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                        </div>
                      </div>

                      {/* Tax Treatment Badge */}
                      <div className={`p-3 rounded-xl border text-[11px] font-medium leading-relaxed ${noteInfo.color}`}>
                        {noteInfo.badge}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 7: PROPERTIES & MORTGAGES */}
      {activeSection === 'properties' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-serif font-semibold text-slate-900">Properties & Mortgages</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Primary residences (qualifies for £175k IHT Residence Nil Rate Band) and buy-to-let properties. Default appreciation: 3.0%.
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                saveProperty({
                  id: `prop-${Date.now()}`,
                  owner: 'joint',
                  jointSplitPercent: 50,
                  label: '',
                  isPrimaryResidence: profile.properties.length === 0,
                  currentValue: 0,
                  annualGrowthPercent: 3.0,
                  rentalIncomeAnnual: 0,
                  isDownsizingPlanned: false,
                })
              }
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add Property Asset
            </button>
          </div>

          <div className="space-y-6">
            {profile.properties.map((prop) => (
              <div key={prop.id} className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <input
                    type="text"
                    placeholder="e.g. Main Family Residence / Buy-to-Let Property"
                    value={prop.label}
                    onChange={(e) => saveProperty({ ...prop, label: e.target.value })}
                    className="font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-sm flex-1"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setDeleteModal({
                        isOpen: true,
                        title: prop.label || 'Property',
                        category: 'property',
                        onConfirm: () => deleteProperty(prop.id),
                      })
                    }
                    className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                    aria-label={`Delete ${prop.label || 'property'}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <OwnershipSelector
                  owner={prop.owner || 'joint'}
                  onChangeOwner={(o) => saveProperty({ ...prop, owner: o })}
                  supportsJoint={true}
                  jointSplitPercent={prop.jointSplitPercent ?? 50}
                  onChangeJointSplit={(pct) => saveProperty({ ...prop, jointSplitPercent: pct })}
                  primaryName={profile.personal.fullName}
                  partnerName={profile.personal.partnerName}
                  hasPartner={profile.personal.hasPartner}
                />

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <CurrencyInput
                    label="Current Property Value"
                    value={prop.currentValue}
                    onChange={(val) => saveProperty({ ...prop, currentValue: val })}
                    step={10000}
                  />
                  <GrowthRateSelector
                    label="Annual Property Appreciation"
                    value={prop.annualGrowthPercent}
                    onChange={(val) => saveProperty({ ...prop, annualGrowthPercent: val })}
                    defaultRate={3.0}
                    presets={[0, 1, 2, 3.0, 4, 5, 6]}
                    helperText="Default 3.0% benchmark for property"
                  />
                  <CurrencyInput
                    label="Annual Net Rental Income"
                    value={prop.rentalIncomeAnnual}
                    onChange={(val) => saveProperty({ ...prop, rentalIncomeAnnual: val })}
                    step={500}
                  />
                </div>

                <div className="pt-2 space-y-3">
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs text-slate-800">
                    <input
                      type="checkbox"
                      checked={prop.isPrimaryResidence}
                      onChange={(e) => saveProperty({ ...prop, isPrimaryResidence: e.target.checked })}
                      className="w-4 h-4 text-emerald-700 rounded border-slate-300 accent-emerald-800"
                    />
                    <span>Primary UK Residence (Qualifies for £175,000 RNRB Allowance & 100% PRR CGT Exemption)</span>
                  </label>

                  {/* Non-Primary Residence Cost Basis & CGT Alert */}
                  {!prop.isPrimaryResidence ? (
                    <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 space-y-3">
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div className="flex-1 min-w-[240px]">
                          <CurrencyInput
                            label="Cost Basis (Purchase Price / Base for CGT)"
                            value={prop.costBasis ?? 0}
                            onChange={(val) => saveProperty({ ...prop, costBasis: val })}
                            step={10000}
                            helperText="Original acquisition price + allowable capital improvements"
                          />
                        </div>
                        <div className="text-xs">
                          {(!prop.costBasis || prop.costBasis === 0) ? (
                            <span className="inline-flex items-center gap-1.5 text-red-700 font-bold bg-red-100 px-3 py-1.5 rounded-lg border border-red-200">
                              ⚠️ No cost basis entered — CGT liability will be estimated on full value!
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-emerald-800 font-semibold bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-200">
                              ✓ Unrealised Gain: £{Math.max(0, prop.currentValue - (prop.costBasis ?? 0)).toLocaleString('en-GB')}
                            </span>
                          )}
                        </div>
                      </div>
                      <p className="text-[11px] text-amber-800 leading-normal">
                        ⚠️ <strong>Non-Primary Residence / Buy-to-Let Property:</strong> Subject to UK Residential Capital Gains Tax (18% Basic Rate / 24% Higher Rate). Please enter your acquisition cost basis to ensure CGT calculations are accurate.
                      </p>
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 text-[11px] text-emerald-900 font-medium flex items-center gap-2">
                      <span>✓</span>
                      <span>
                        <strong>100% Tax-Exempt:</strong> As your primary residence, this property is fully exempt from Capital Gains Tax under Private Residence Relief (PRR) and qualifies for up to £175,000 per person (£350,000 for couples) Residence Nil Rate Band (RNRB).
                      </span>
                    </div>
                  )}
                </div>

                {/* Downsizing / Equity Release Controls */}
                <div className="mt-4 pt-4 border-t border-slate-200 space-y-3">
                  <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
                    <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs text-slate-800">
                      <input
                        type="checkbox"
                        checked={prop.isDownsizingPlanned}
                        onChange={(e) => saveProperty({ ...prop, isDownsizingPlanned: e.target.checked })}
                        className="w-4 h-4 text-emerald-700 rounded border-slate-300 accent-emerald-800"
                      />
                      <span>Plan to Downsize or Release Equity from this Property (feeds directly into Cash)</span>
                    </label>

                    {prop.isDownsizingPlanned && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 animate-in fade-in">
                        <CurrencyInput
                          label="Net Capital / Equity Released (£)"
                          value={prop.downsizeReleasedAmount ?? 100000}
                          onChange={(val) => saveProperty({ ...prop, downsizeReleasedAmount: val })}
                          step={10000}
                          helperText="Net capital released from property equity and credited to liquid Cash"
                        />

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                            Target Year of Downsizing / Release
                          </label>
                          <input
                            type="number"
                            min={2026}
                            max={2060}
                            value={prop.downsizeYear ?? (new Date().getFullYear() + 5)}
                            onChange={(e) => saveProperty({ ...prop, downsizeYear: parseInt(e.target.value, 10) || 2026 })}
                            className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/20"
                          />
                          <p className="text-[11px] text-slate-500 mt-1">
                            In {prop.downsizeYear ?? 2030}, £{(prop.downsizeReleasedAmount ?? 100000).toLocaleString('en-GB')} of capital is released into liquid Cash reserves.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Attached Mortgages */}
                <div className="mt-4 pt-4 border-t border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-700">
                      Outstanding Mortgages on this Property
                    </h5>
                    <button
                      type="button"
                      onClick={() =>
                        saveMortgage({
                          id: `mort-${Date.now()}`,
                          propertyId: prop.id,
                          owner: prop.owner || 'joint',
                          jointSplitPercent: prop.jointSplitPercent ?? 50,
                          label: '',
                          outstandingBalance: 0,
                          interestRatePercent: 4.0,
                          remainingTermYears: 20,
                          monthlyPayment: 0,
                          mortgageType: 'repayment',
                        })
                      }
                      className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                      <Plus className="w-3 h-3" /> Add Mortgage
                    </button>
                  </div>

                  {profile.mortgages
                    .filter((m) => m.propertyId === prop.id)
                    .map((m) => (
                      <div key={m.id} className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
                        <div className="flex items-center justify-between gap-3">
                          <input
                            type="text"
                            placeholder="e.g. Fixed Rate Mortgage (Lender)"
                            value={m.label}
                            onChange={(e) => saveMortgage({ ...m, label: e.target.value })}
                            className="font-semibold text-slate-800 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-700 focus:outline-none px-1 text-xs flex-1"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setDeleteModal({
                                isOpen: true,
                                title: m.label || 'Mortgage',
                                category: 'mortgage',
                                onConfirm: () => deleteMortgage(m.id),
                              })
                            }
                            className="text-slate-400 hover:text-red-600 p-1 rounded hover:bg-slate-100 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <OwnershipSelector
                          owner={m.owner || 'joint'}
                          onChangeOwner={(o) => saveMortgage({ ...m, owner: o })}
                          supportsJoint={true}
                          jointSplitPercent={m.jointSplitPercent ?? 50}
                          onChangeJointSplit={(pct) => saveMortgage({ ...m, jointSplitPercent: pct })}
                          primaryName={profile.personal.fullName}
                          partnerName={profile.personal.partnerName}
                          hasPartner={profile.personal.hasPartner}
                        />

                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                          <CurrencyInput
                            label="Outstanding Balance"
                            value={m.outstandingBalance}
                            onChange={(val) => saveMortgage({ ...m, outstandingBalance: val })}
                            step={5000}
                          />
                          <CurrencyInput
                            label="Interest Rate"
                            value={m.interestRatePercent}
                            onChange={(val) => saveMortgage({ ...m, interestRatePercent: val })}
                            prefix=""
                            suffix="%"
                            step={0.05}
                          />
                          <CurrencyInput
                            label="Remaining Term (Years)"
                            value={m.remainingTermYears}
                            onChange={(val) => saveMortgage({ ...m, remainingTermYears: val })}
                            prefix=""
                            step={1}
                          />
                          <CurrencyInput
                            label="Monthly Payment (£)"
                            value={m.monthlyPayment}
                            onChange={(val) => saveMortgage({ ...m, monthlyPayment: val })}
                            step={50}
                          />
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 8: GIFTING & IHT MITIGATION */}
      {activeSection === 'gifting' && (
        <GiftingIhtHub />
      )}

      {/* SECTION 9: MACRO ASSUMPTIONS & STATE PENSION */}
      {activeSection === 'assumptions' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-serif font-semibold text-slate-900">Economic Assumptions & State Pension</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Long-term baseline economic parameters, Triple Lock inflation indexation, and April 2027 IHT legislation.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <CurrencyInput
              label={`${profile.personal.fullName || 'Primary'} State Pension Age`}
              value={profile.statePension.primaryStatePensionAge}
              onChange={(val) => updateStatePension({ ...profile.statePension, primaryStatePensionAge: val })}
              prefix=""
              step={1}
              min={66}
              max={70}
              helperText="Current UK State Pension age is 66, rising to 67 between 2026-2028"
            />

            <CurrencyInput
              label={`${profile.personal.fullName || 'Primary'} State Pension (£/yr)`}
              value={profile.statePension.primaryAnnualAmount}
              onChange={(val) => updateStatePension({ ...profile.statePension, primaryAnnualAmount: val })}
              step={100}
              helperText="Full new State Pension is £12,450.00 (~£239.50/wk in 2026/27 Triple Lock)"
            />

            {profile.personal.hasPartner && (
              <>
                <CurrencyInput
                  label={`${profile.personal.partnerName || 'Partner'} State Pension Age`}
                  value={profile.statePension.partnerStatePensionAge ?? 67}
                  onChange={(val) => updateStatePension({ ...profile.statePension, partnerStatePensionAge: val })}
                  prefix=""
                  step={1}
                  min={66}
                  max={70}
                  helperText="Statutory UK State Pension age for partner"
                />

                <CurrencyInput
                  label={`${profile.personal.partnerName || 'Partner'} State Pension (£/yr)`}
                  value={profile.statePension.partnerAnnualAmount ?? 12450}
                  onChange={(val) => updateStatePension({ ...profile.statePension, partnerAnnualAmount: val })}
                  step={100}
                  helperText="Full partner State Pension entitlement"
                />
              </>
            )}

            <CurrencyInput
              label="Long-Term CPI Inflation"
              value={profile.assumptions.inflationRatePercent}
              onChange={(val) => updateAssumptions({ ...profile.assumptions, inflationRatePercent: val })}
              prefix=""
              suffix="%"
              step={0.1}
              helperText="Bank of England long-term CPI target (default 2.0%)"
            />

            <GrowthRateSelector
              label="Default Equity / Pension Growth"
              value={profile.assumptions.defaultEquityGrowthRatePercent}
              onChange={(val) => updateAssumptions({ ...profile.assumptions, defaultEquityGrowthRatePercent: val })}
              defaultRate={4.0}
              helperText="Default 4.0% (after fees)"
            />

            <GrowthRateSelector
              label="Cash / NS&I Growth Rate"
              value={profile.assumptions.defaultBondCashGrowthRatePercent}
              onChange={(val) => updateAssumptions({ ...profile.assumptions, defaultBondCashGrowthRatePercent: val })}
              defaultRate={2.0}
              helperText="Default 2.0% for cash & NS&I"
            />

            <CurrencyInput
              label="Advisor & Platform Fee"
              value={profile.assumptions.advisorPlatformFeePercent}
              onChange={(val) => updateAssumptions({ ...profile.assumptions, advisorPlatformFeePercent: val })}
              prefix=""
              suffix="%"
              step={0.05}
            />

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700">Decumulation Drawdown Strategy</label>
              <select
                value={profile.assumptions.drawdownStrategy || 'tax_optimised'}
                onChange={(e) => {
                  const val = e.target.value as any;
                  const defaultSeq: Record<string, any> = {
                    tax_optimised: ['cash', 'gia', 'pension', 'isa'],
                    pension_first: ['pension', 'gia', 'isa', 'cash'],
                    isa_first: ['isa', 'cash', 'gia', 'pension'],
                    cash_first: ['cash', 'isa', 'gia', 'pension'],
                  };
                  updateAssumptions({
                    ...profile.assumptions,
                    drawdownStrategy: val,
                    customDrawdownOrder: defaultSeq[val] || profile.assumptions.customDrawdownOrder,
                  });
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-800 focus:border-emerald-700 focus:outline-none"
              >
                <option value="tax_optimised">🌟 Tax-Optimised Waterfall (Recommended)</option>
                <option value="pension_first">💼 Pension-First (IHT Minimiser)</option>
                <option value="isa_first">🛡️ ISA-First Bridge</option>
                <option value="cash_first">💵 Cash-First Buffer</option>
                <option value="custom">⚡ Bespoke / Custom Order</option>
              </select>
              <span className="text-2xs text-slate-500 block">Determines the priority order for decumulating asset pots in retirement.</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-2 mt-4">
            <div className="flex items-center gap-2 font-semibold">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span>April 2027 Pension Inheritance Tax Rule (Autumn Budget 2024)</span>
            </div>
            <p>
              Under legislation enacted following the UK Autumn Budget 2024, unused Defined Contribution pension funds and death benefits will be included within the gross estate for 40% Inheritance Tax from 6 April 2027.
            </p>
            <label className="flex items-center gap-2 font-medium cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={profile.assumptions.includePensionsInIhtPost2027}
                onChange={(e) => updateAssumptions({ ...profile.assumptions, includePensionsInIhtPost2027: e.target.checked })}
                className="w-4 h-4 text-emerald-700 rounded border-amber-300"
              />
              <span>Include DC Pensions in IHT Estate from April 2027 (Recommended)</span>
            </label>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        itemTitle={deleteModal.title}
        itemCategory={deleteModal.category}
        onConfirm={deleteModal.onConfirm}
        onCancel={() => setDeleteModal({ isOpen: false, title: '', category: '', onConfirm: () => {} })}
      />
    </div>
  );
};
