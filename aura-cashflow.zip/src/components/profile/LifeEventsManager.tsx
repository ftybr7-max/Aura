/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Key Life Events & Timeline Manager
 */

import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  Trash2,
  TrendingUp,
  TrendingDown,
  Gift,
  GraduationCap,
  Briefcase,
  Home,
  Heart,
  Sparkles,
  Info,
} from 'lucide-react';
import { useCashflow } from '../../aura/context/CashflowContext';
import { CurrencyInput } from '../common/PrivacyModal';
import { OwnershipSelector } from '../common/OwnershipSelector';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { LifeEvent, LifeEventType, OwnershipType } from '../../types/cashflow';

interface PresetOption {
  type: LifeEventType;
  label: string;
  defaultDirection: 'inflow' | 'outflow';
  defaultAmount: number;
  icon: React.ElementType;
  description: string;
}

const LIFE_EVENT_PRESETS: PresetOption[] = [
  {
    type: 'inheritance',
    label: 'Expected Inheritance',
    defaultDirection: 'inflow',
    defaultAmount: 100000,
    icon: Sparkles,
    description: 'Anticipated capital bequest or probate estate distribution (IHT-free to recipient).',
  },
  {
    type: 'business_sale',
    label: 'Business Sale / Equity Exit',
    defaultDirection: 'inflow',
    defaultAmount: 250000,
    icon: Briefcase,
    description: 'Sale of company shares, BADR exit, or business capital distribution.',
  },
  {
    type: 'property_downsize',
    label: 'Property Downsize Equity Release',
    defaultDirection: 'inflow',
    defaultAmount: 150000,
    icon: Home,
    description: 'Net capital released from selling main residence and moving to smaller home.',
  },
  {
    type: 'education_fees',
    label: 'University / Education Funding',
    defaultDirection: 'outflow',
    defaultAmount: 45000,
    icon: GraduationCap,
    description: 'Higher education tuition and maintenance fees funding for children / grandchildren.',
  },
  {
    type: 'gift_out',
    label: 'Lifetime Gift to Children (PET)',
    defaultDirection: 'outflow',
    defaultAmount: 50000,
    icon: Gift,
    description: 'Potentially Exempt Transfer (PET) to reduce estate IHT liability over 7-year rule.',
  },
  {
    type: 'wedding_gift',
    label: 'Wedding / First Home Deposit Gift',
    defaultDirection: 'outflow',
    defaultAmount: 30000,
    icon: Heart,
    description: 'Substantial one-off family support for property purchase or milestone celebration.',
  },
  {
    type: 'major_purchase',
    label: 'Major Capital Purchase / Renovation',
    defaultDirection: 'outflow',
    defaultAmount: 35000,
    icon: TrendingDown,
    description: 'Home extension, vehicle upgrade, sabbatical, or luxury capital project.',
  },
];

export const LifeEventsManager: React.FC = () => {
  const { profile, saveLifeEvent, deleteLifeEvent } = useCashflow();
  const currentCalendarYear = new Date().getFullYear();
  const currentAge = profile.personal.currentAge;

  const [isAddingNew, setIsAddingNew] = useState(false);
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    title: string;
    id: string;
  }>({
    isOpen: false,
    title: '',
    id: '',
  });

  const [newEvent, setNewEvent] = useState<Partial<LifeEvent>>({
    label: '',
    type: 'inheritance',
    direction: 'inflow',
    amount: 50000,
    targetAge: currentAge + 5,
    notes: '',
    owner: 'joint',
    jointSplitPercent: 50,
  });

  const handleSelectPreset = (preset: PresetOption) => {
    setNewEvent((prev) => ({
      ...prev,
      type: preset.type,
      label: preset.label,
      direction: preset.defaultDirection,
      amount: preset.defaultAmount,
    }));
  };

  const handleSave = () => {
    if (!newEvent.label || !newEvent.amount) return;

    const eventToSave: LifeEvent = {
      id: newEvent.id || `evt-${Date.now()}`,
      label: newEvent.label,
      type: newEvent.type || 'custom',
      direction: newEvent.direction || 'inflow',
      amount: Number(newEvent.amount) || 0,
      targetAge: Number(newEvent.targetAge) || currentAge,
      calendarYear: currentCalendarYear + (Number(newEvent.targetAge) - currentAge),
      notes: newEvent.notes || '',
      owner: newEvent.owner || 'joint',
      jointSplitPercent: newEvent.jointSplitPercent ?? 50,
    };

    saveLifeEvent(eventToSave);
    setIsAddingNew(false);
    setNewEvent({
      label: '',
      type: 'inheritance',
      direction: 'inflow',
      amount: 50000,
      targetAge: currentAge + 5,
      notes: '',
      owner: 'joint',
      jointSplitPercent: 50,
    });
  };

  const lifeEvents = profile.lifeEvents || [];

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-emerald-100/80 rounded-lg text-emerald-800">
              <Calendar className="w-4 h-4" />
            </span>
            <h3 className="text-lg font-serif font-semibold text-slate-900">
              Key Life Events & Milestone Timeline
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Model one-off capital inflows (inheritance, business sales, downsizing) and major lump-sum outgoings (school/university fees, lifetime gifts, renovations). These appear with indicators on the Cashflow Modeller and Net Worth trajectory charts.
          </p>
        </div>

        {!isAddingNew && (
          <button
            type="button"
            onClick={() => setIsAddingNew(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors shadow-2xs self-start"
          >
            <Plus className="w-3.5 h-3.5" /> Add Life Event
          </button>
        )}
      </div>

      {/* Creation / Edit Form */}
      {isAddingNew && (
        <div className="p-5 rounded-2xl bg-emerald-50/40 border border-emerald-200 space-y-5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-emerald-950 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-700" /> Configure One-Off Life Event
            </h4>
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="text-xs text-slate-500 hover:text-slate-700 px-2 py-1"
            >
              Cancel
            </button>
          </div>

          {/* Presets Bar */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-600 mb-2">
              Quick Select Milestone Template
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {LIFE_EVENT_PRESETS.map((preset) => {
                const Icon = preset.icon;
                const isSelected = newEvent.type === preset.type;
                return (
                  <button
                    key={preset.type}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-left text-xs transition-all ${
                      isSelected
                        ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs font-semibold'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-emerald-300' : 'text-slate-500'}`} />
                    <span className="truncate">{preset.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Event Description / Title
              </label>
              <input
                type="text"
                value={newEvent.label || ''}
                onChange={(e) => setNewEvent((prev) => ({ ...prev, label: e.target.value }))}
                placeholder="e.g. Sale of Rental Property / Child University Fund"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 focus:outline-none bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Cash Flow Direction
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setNewEvent((prev) => ({ ...prev, direction: 'inflow' }))}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                    newEvent.direction === 'inflow'
                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" /> Inflow (+)
                </button>
                <button
                  type="button"
                  onClick={() => setNewEvent((prev) => ({ ...prev, direction: 'outflow' }))}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                    newEvent.direction === 'outflow'
                      ? 'bg-rose-700 text-white border-rose-800 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <TrendingDown className="w-3.5 h-3.5" /> Outflow (-)
                </button>
              </div>
            </div>

            <CurrencyInput
              label="Lump Sum Amount"
              value={newEvent.amount || 0}
              onChange={(val) => setNewEvent((prev) => ({ ...prev, amount: val }))}
              step={5000}
            />

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Target Age (Assume Start of Tax Year)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={currentAge}
                  max={profile.personal.planningHorizonAge}
                  value={newEvent.targetAge || currentAge}
                  onChange={(e) => setNewEvent((prev) => ({ ...prev, targetAge: Number(e.target.value) }))}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 font-medium focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 focus:outline-none bg-white"
                />
                <span className="text-xs text-slate-500 font-medium whitespace-nowrap">
                  (Year {currentCalendarYear + ((newEvent.targetAge || currentAge) - currentAge)})
                </span>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                Planning Notes & Assumptions
              </label>
              <input
                type="text"
                value={newEvent.notes || ''}
                onChange={(e) => setNewEvent((prev) => ({ ...prev, notes: e.target.value }))}
                placeholder="Optional details (e.g. PET 7-year taper clock, university years 1-3)"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs text-slate-900 font-medium focus:ring-2 focus:ring-emerald-700/20 focus:border-emerald-700 focus:outline-none bg-white"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-emerald-200/60">
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={!newEvent.label || !newEvent.amount}
              className="px-5 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 rounded-xl shadow-2xs transition-colors"
            >
              Save Life Event
            </button>
          </div>
        </div>
      )}

      {/* List of Configured Life Events */}
      {lifeEvents.length === 0 ? (
        <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
          <Calendar className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <h4 className="text-sm font-semibold text-slate-800">No Life Events Configured Yet</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
            Add significant one-off capital inflows (inheritance, business exit, downsizing) or major outgoings (university fees, wedding gifts, lifetime gifts) to see their exact impact on the timeline.
          </p>
          <button
            type="button"
            onClick={() => setIsAddingNew(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 text-white rounded-xl hover:bg-emerald-900 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Add First Life Event
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {lifeEvents
            .sort((a, b) => a.targetAge - b.targetAge)
            .map((evt) => {
              const isInflow = evt.direction === 'inflow';
              const eventYear = currentCalendarYear + (evt.targetAge - currentAge);

              return (
                <div
                  key={evt.id}
                  className="p-4 rounded-2xl bg-slate-50/90 border border-slate-200 hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div
                      className={`p-2 rounded-xl text-xs font-bold flex items-center justify-center shrink-0 ${
                        isInflow
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-rose-100 text-rose-800 border border-rose-200'
                      }`}
                    >
                      {isInflow ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900 text-sm">{evt.label}</span>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            isInflow
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {isInflow ? 'Inflow (+)' : 'Outflow (-)'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span className="font-medium text-slate-700">
                          Age {evt.targetAge} (Tax Year {eventYear}/{String(eventYear + 1).slice(-2)})
                        </span>
                        {evt.notes && <span>• {evt.notes}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 pt-2 sm:pt-0 border-t sm:border-0 border-slate-200">
                    <span
                      className={`text-base font-serif font-bold ${
                        isInflow ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {isInflow ? '+' : '-'}£{evt.amount.toLocaleString('en-GB')}
                    </span>

                    <button
                      type="button"
                      onClick={() =>
                        setDeleteModal({
                          isOpen: true,
                          title: evt.label,
                          id: evt.id,
                        })
                      }
                      className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
                      aria-label={`Delete ${evt.label}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        itemTitle={deleteModal.title}
        itemCategory="life event"
        onConfirm={() => {
          deleteLifeEvent(deleteModal.id);
          setDeleteModal({ isOpen: false, title: '', id: '' });
        }}
        onCancel={() => setDeleteModal({ isOpen: false, title: '', id: '' })}
      />
    </div>
  );
};
