/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Central React Context & State Manager
 * Eliminates prop-drilling, ensures consistent calculation routing, and handles local persistence.
 */

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  CashflowProfile,
  CashflowSimulationResult,
  MonteCarloSummary,
  WhatIfScenarioModifiers,
  PersonalDetails,
  EmploymentIncome,
  ExpenseItem,
  DefinedContributionPension,
  DefinedBenefitPension,
  IsaAccount,
  GiaAccount,
  CashAccount,
  InvestmentBondAccount,
  OtherInvestmentAccount,
  PropertyAsset,
  MortgageLiability,
  StatePensionSettings,
  EconomicAssumptions,
  LifeEvent,
  HistoricGift,
  ExcessIncomeGiftingPlan,
  AdviserPracticeDetails,
  DEFAULT_ADVISER_DETAILS,
} from '../../types/cashflow';
import { DEFAULT_WHAT_IF_MODIFIERS, runCashflowSimulation } from '../engine/cashflowEngine';
import { runMonteCarloSimulation } from '../engine/monteCarloEngine';
import { SAMPLE_PROFILES } from '../data/sampleProfiles';

const LOCAL_STORAGE_KEY = 'aura_cashflow_client_profile_v2';
const REAL_TERMS_STORAGE_KEY = 'aura_cashflow_real_terms_pref';
const ADVISER_STORAGE_KEY = 'aura_cashflow_adviser_details_v1';

interface CashflowContextType {
  profile: CashflowProfile;
  adviserDetails: AdviserPracticeDetails;
  simulationResult: CashflowSimulationResult;
  monteCarloResult: MonteCarloSummary;
  activeModifiers: WhatIfScenarioModifiers;
  isRealTerms: boolean;
  activeTab: 'modeller' | 'profile' | 'drawdown' | 'gifting' | 'whatif' | 'montecarlo' | 'report' | 'rules';
  reportMode: 'summary' | 'full';
  isPrivacyBannerDismissed: boolean;
  
  // Actions
  setActiveTab: (tab: 'modeller' | 'profile' | 'drawdown' | 'gifting' | 'whatif' | 'montecarlo' | 'report' | 'rules') => void;
  setReportMode: (mode: 'summary' | 'full') => void;
  setIsRealTerms: (value: boolean) => void;
  dismissPrivacyBanner: () => void;
  setModifiers: React.Dispatch<React.SetStateAction<WhatIfScenarioModifiers>>;
  resetModifiers: () => void;
  updateAdviserDetails: (details: Partial<AdviserPracticeDetails>) => void;
  resetAdviserDetails: () => void;
  
  // Profile Mutators
  updatePersonal: (personal: PersonalDetails) => void;
  saveEmployment: (item: EmploymentIncome) => void;
  deleteEmployment: (id: string) => void;
  saveExpense: (item: ExpenseItem) => void;
  deleteExpense: (id: string) => void;
  saveLifeEvent: (item: LifeEvent) => void;
  deleteLifeEvent: (id: string) => void;
  saveHistoricGift: (item: HistoricGift) => void;
  deleteHistoricGift: (id: string) => void;
  updateExcessIncomeGifting: (plan: ExcessIncomeGiftingPlan) => void;
  saveDcPension: (item: DefinedContributionPension) => void;
  deleteDcPension: (id: string) => void;
  saveDbPension: (item: DefinedBenefitPension) => void;
  deleteDbPension: (id: string) => void;
  saveIsa: (item: IsaAccount) => void;
  deleteIsa: (id: string) => void;
  saveGia: (item: GiaAccount) => void;
  deleteGia: (id: string) => void;
  saveCash: (item: CashAccount) => void;
  deleteCash: (id: string) => void;
  saveInvestmentBond: (item: InvestmentBondAccount) => void;
  deleteInvestmentBond: (id: string) => void;
  saveOtherInvestment: (item: OtherInvestmentAccount) => void;
  deleteOtherInvestment: (id: string) => void;
  saveProperty: (item: PropertyAsset) => void;
  deleteProperty: (id: string) => void;
  saveMortgage: (item: MortgageLiability) => void;
  deleteMortgage: (id: string) => void;
  updateStatePension: (settings: StatePensionSettings) => void;
  updateAssumptions: (assumptions: EconomicAssumptions) => void;

  // Utilities
  loadPresetProfile: (presetId: string) => void;
  exportProfileJson: () => string;
  importProfileJson: (json: string) => boolean;
  setFullProfile: (newProfile: CashflowProfile) => void;
  resetToBlankProfile: () => void;
  resetToDefault: () => void;
}

export const createBlankProfile = (): CashflowProfile => ({
  personal: {
    fullName: '',
    currentAge: 45,
    targetRetirementAge: 65,
    planningHorizonAge: 95,
    taxRegion: 'england_wales_ni',
    hasPartner: false,
    partnerName: '',
    partnerAge: undefined,
    partnerTargetRetirementAge: undefined,
    relationshipType: 'spouse_civil_partner',
    isAlreadyRetired: false,
    partnerIsAlreadyRetired: false,
  },
  employment: [],
  otherIncomes: [],
  expenses: [],
  dcPensions: [],
  dbPensions: [],
  isas: [],
  gias: [],
  cashAccounts: [],
  investmentBonds: [],
  otherInvestments: [],
  properties: [],
  mortgages: [],
  otherLiabilities: [],
  statePension: {
    includeStatePension: true,
    primaryStatePensionAge: 67,
    primaryAnnualAmount: 12450,
    partnerStatePensionAge: 67,
    partnerAnnualAmount: 12450,
    tripleLockAssumptionPercent: 2.5,
  },
  assumptions: {
    inflationRatePercent: 2.0,
    realTermsDiscounting: true,
    defaultEquityGrowthRatePercent: 4.0,
    defaultBondCashGrowthRatePercent: 2.0,
    advisorPlatformFeePercent: 0.5,
    drawdownStrategy: 'tax_optimised',
    includePensionsInIhtPost2027: true,
  },
  lifeEvents: [],
  historicGifts: [],
  excessIncomeGifting: {
    enabled: false,
    donor: 'primary',
    annualGiftAmount: 0,
    startAge: 65,
    durationYears: 10,
    habitualFrequency: 'annual',
    documentationInPlace: false,
    recipientName: '',
  },
});

const CashflowContext = createContext<CashflowContextType | null>(null);

export const CashflowProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Initial State from LocalStorage or Sample
  const [profile, setProfile] = useState<CashflowProfile>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore JSON parse errors
    }
    return SAMPLE_PROFILES[0].profile;
  });

  const [isRealTerms, setIsRealTermsState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(REAL_TERMS_STORAGE_KEY);
      if (saved !== null) {
        return saved === 'true';
      }
    } catch {
      // ignore
    }
    return true; // Default to Real Terms (today's purchasing power)
  });

  const [activeModifiers, setModifiers] = useState<WhatIfScenarioModifiers>(DEFAULT_WHAT_IF_MODIFIERS);
  const [activeTab, setActiveTabState] = useState<'modeller' | 'profile' | 'drawdown' | 'whatif' | 'montecarlo' | 'report' | 'rules'>(() => {
    try {
      const saved = localStorage.getItem('aura_active_tab');
      if (saved && ['modeller', 'profile', 'drawdown', 'whatif', 'montecarlo', 'report', 'rules'].includes(saved)) {
        return saved as any;
      }
    } catch {
      // ignore
    }
    return 'modeller';
  });

  const setActiveTab = (tab: 'modeller' | 'profile' | 'drawdown' | 'whatif' | 'montecarlo' | 'report' | 'rules') => {
    setActiveTabState(tab);
    try {
      localStorage.setItem('aura_active_tab', tab);
    } catch {
      // ignore
    }
  };
  const [reportMode, setReportMode] = useState<'summary' | 'full'>('full');
  const [isPrivacyBannerDismissed, setIsPrivacyBannerDismissed] = useState<boolean>(() => {
    return localStorage.getItem('aura_privacy_notice_seen') === 'true';
  });

  const [adviserDetails, setAdviserDetailsState] = useState<AdviserPracticeDetails>(() => {
    try {
      const saved = localStorage.getItem(ADVISER_STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_ADVISER_DETAILS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_ADVISER_DETAILS;
  });

  // 2. Persist Profile Changes to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(profile));
    } catch {
      // ignore storage quota errors
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(ADVISER_STORAGE_KEY, JSON.stringify(adviserDetails));
    } catch {
      // ignore storage quota errors
    }
  }, [adviserDetails]);

  const updateAdviserDetails = (details: Partial<AdviserPracticeDetails>) => {
    setAdviserDetailsState((prev) => ({
      ...prev,
      ...details,
    }));
  };

  const resetAdviserDetails = () => {
    setAdviserDetailsState(DEFAULT_ADVISER_DETAILS);
    try {
      localStorage.removeItem(ADVISER_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const setIsRealTerms = (value: boolean) => {
    setIsRealTermsState(value);
    try {
      localStorage.setItem(REAL_TERMS_STORAGE_KEY, String(value));
    } catch {
      // ignore
    }
  };

  const dismissPrivacyBanner = () => {
    setIsPrivacyBannerDismissed(true);
    try {
      localStorage.setItem('aura_privacy_notice_seen', 'true');
    } catch {
      // ignore
    }
  };

  const resetModifiers = () => {
    setModifiers(DEFAULT_WHAT_IF_MODIFIERS);
  };

  // 3. Centralized Memoized Simulations
  const simulationResult = useMemo(() => {
    return runCashflowSimulation(profile, activeModifiers);
  }, [profile, activeModifiers]);

  const monteCarloResult = useMemo(() => {
    return runMonteCarloSimulation(profile, activeModifiers, 1000);
  }, [profile, activeModifiers]);

  // 4. Helper Mutators
  const updatePersonal = (personal: PersonalDetails) => {
    setProfile((prev) => ({ ...prev, personal }));
  };

  const saveEmployment = (item: EmploymentIncome) => {
    setProfile((prev) => {
      const index = prev.employment.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.employment.map((e) => (e.id === item.id ? item : e)) : [...prev.employment, item];
      return { ...prev, employment: updated };
    });
  };

  const deleteEmployment = (id: string) => {
    setProfile((prev) => ({ ...prev, employment: prev.employment.filter((e) => e.id !== id) }));
  };

  const saveExpense = (item: ExpenseItem) => {
    setProfile((prev) => {
      const index = prev.expenses.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.expenses.map((e) => (e.id === item.id ? item : e)) : [...prev.expenses, item];
      return { ...prev, expenses: updated };
    });
  };

  const deleteExpense = (id: string) => {
    setProfile((prev) => ({ ...prev, expenses: prev.expenses.filter((e) => e.id !== id) }));
  };

  const saveLifeEvent = (item: LifeEvent) => {
    setProfile((prev) => {
      const currentList = prev.lifeEvents || [];
      const index = currentList.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? currentList.map((e) => (e.id === item.id ? item : e)) : [...currentList, item];
      return { ...prev, lifeEvents: updated };
    });
  };

  const deleteLifeEvent = (id: string) => {
    setProfile((prev) => ({ ...prev, lifeEvents: (prev.lifeEvents || []).filter((e) => e.id !== id) }));
  };

  const saveHistoricGift = (item: HistoricGift) => {
    setProfile((prev) => {
      const currentList = prev.historicGifts || [];
      const index = currentList.findIndex((g) => g.id === item.id);
      const updated = index >= 0 ? currentList.map((g) => (g.id === item.id ? item : g)) : [...currentList, item];
      return { ...prev, historicGifts: updated };
    });
  };

  const deleteHistoricGift = (id: string) => {
    setProfile((prev) => ({ ...prev, historicGifts: (prev.historicGifts || []).filter((g) => g.id !== id) }));
  };

  const updateExcessIncomeGifting = (plan: ExcessIncomeGiftingPlan) => {
    setProfile((prev) => ({ ...prev, excessIncomeGifting: plan }));
  };

  const saveDcPension = (item: DefinedContributionPension) => {
    setProfile((prev) => {
      const index = prev.dcPensions.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.dcPensions.map((e) => (e.id === item.id ? item : e)) : [...prev.dcPensions, item];
      return { ...prev, dcPensions: updated };
    });
  };

  const deleteDcPension = (id: string) => {
    setProfile((prev) => ({ ...prev, dcPensions: prev.dcPensions.filter((e) => e.id !== id) }));
  };

  const saveDbPension = (item: DefinedBenefitPension) => {
    setProfile((prev) => {
      const index = prev.dbPensions.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.dbPensions.map((e) => (e.id === item.id ? item : e)) : [...prev.dbPensions, item];
      return { ...prev, dbPensions: updated };
    });
  };

  const deleteDbPension = (id: string) => {
    setProfile((prev) => ({ ...prev, dbPensions: prev.dbPensions.filter((e) => e.id !== id) }));
  };

  const saveIsa = (item: IsaAccount) => {
    setProfile((prev) => {
      const index = prev.isas.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.isas.map((e) => (e.id === item.id ? item : e)) : [...prev.isas, item];
      return { ...prev, isas: updated };
    });
  };

  const deleteIsa = (id: string) => {
    setProfile((prev) => ({ ...prev, isas: prev.isas.filter((e) => e.id !== id) }));
  };

  const saveGia = (item: GiaAccount) => {
    setProfile((prev) => {
      const index = prev.gias.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.gias.map((e) => (e.id === item.id ? item : e)) : [...prev.gias, item];
      return { ...prev, gias: updated };
    });
  };

  const deleteGia = (id: string) => {
    setProfile((prev) => ({ ...prev, gias: prev.gias.filter((e) => e.id !== id) }));
  };

  const saveCash = (item: CashAccount) => {
    setProfile((prev) => {
      const index = prev.cashAccounts.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.cashAccounts.map((e) => (e.id === item.id ? item : e)) : [...prev.cashAccounts, item];
      return { ...prev, cashAccounts: updated };
    });
  };

  const deleteCash = (id: string) => {
    setProfile((prev) => ({ ...prev, cashAccounts: prev.cashAccounts.filter((e) => e.id !== id) }));
  };

  const saveInvestmentBond = (item: InvestmentBondAccount) => {
    setProfile((prev) => {
      const currentList = prev.investmentBonds || [];
      const index = currentList.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? currentList.map((e) => (e.id === item.id ? item : e)) : [...currentList, item];
      return { ...prev, investmentBonds: updated };
    });
  };

  const deleteInvestmentBond = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      investmentBonds: (prev.investmentBonds || []).filter((e) => e.id !== id),
    }));
  };

  const saveOtherInvestment = (item: OtherInvestmentAccount) => {
    setProfile((prev) => {
      const currentList = prev.otherInvestments || [];
      const index = currentList.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? currentList.map((e) => (e.id === item.id ? item : e)) : [...currentList, item];
      return { ...prev, otherInvestments: updated };
    });
  };

  const deleteOtherInvestment = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      otherInvestments: (prev.otherInvestments || []).filter((e) => e.id !== id),
    }));
  };

  const saveProperty = (item: PropertyAsset) => {
    setProfile((prev) => {
      const index = prev.properties.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.properties.map((e) => (e.id === item.id ? item : e)) : [...prev.properties, item];
      return { ...prev, properties: updated };
    });
  };

  const deleteProperty = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      properties: prev.properties.filter((e) => e.id !== id),
      mortgages: prev.mortgages.filter((m) => m.propertyId !== id),
    }));
  };

  const saveMortgage = (item: MortgageLiability) => {
    setProfile((prev) => {
      const index = prev.mortgages.findIndex((e) => e.id === item.id);
      const updated = index >= 0 ? prev.mortgages.map((e) => (e.id === item.id ? item : e)) : [...prev.mortgages, item];
      return { ...prev, mortgages: updated };
    });
  };

  const deleteMortgage = (id: string) => {
    setProfile((prev) => ({ ...prev, mortgages: prev.mortgages.filter((e) => e.id !== id) }));
  };

  const updateStatePension = (settings: StatePensionSettings) => {
    setProfile((prev) => ({ ...prev, statePension: settings }));
  };

  const updateAssumptions = (assumptions: EconomicAssumptions) => {
    setProfile((prev) => ({ ...prev, assumptions }));
  };

  const loadPresetProfile = (presetId: string) => {
    const found = SAMPLE_PROFILES.find((p) => p.id === presetId);
    if (found) {
      setProfile(JSON.parse(JSON.stringify(found.profile)));
      resetModifiers();
    }
  };

  const exportProfileJson = () => {
    return JSON.stringify(profile, null, 2);
  };

  const importProfileJson = (json: string): boolean => {
    try {
      const parsed = JSON.parse(json);
      if (parsed && parsed.personal && parsed.personal.currentAge) {
        setProfile(parsed);
        resetModifiers();
        return true;
      }
    } catch {
      // failed parsing
    }
    return false;
  };

  const setFullProfile = (newProfile: CashflowProfile) => {
    setProfile(newProfile);
    resetModifiers();
  };

  const resetToBlankProfile = () => {
    const blank = createBlankProfile();
    setProfile(blank);
    resetModifiers();
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(blank));
    } catch {
      // ignore
    }
  };

  const resetToDefault = () => {
    resetToBlankProfile();
  };

  return (
    <CashflowContext.Provider
      value={{
        profile,
        adviserDetails,
        simulationResult,
        monteCarloResult,
        activeModifiers,
        isRealTerms,
        activeTab,
        reportMode,
        isPrivacyBannerDismissed,
        setActiveTab,
        setReportMode,
        setIsRealTerms,
        dismissPrivacyBanner,
        setModifiers,
        resetModifiers,
        updateAdviserDetails,
        resetAdviserDetails,
        setFullProfile,
        resetToBlankProfile,
        resetToDefault,
        loadPresetProfile,
        exportProfileJson,
        importProfileJson,
        updatePersonal,
        saveEmployment,
        deleteEmployment,
        saveExpense,
        deleteExpense,
        saveLifeEvent,
        deleteLifeEvent,
        saveHistoricGift,
        deleteHistoricGift,
        updateExcessIncomeGifting,
        saveDcPension,
        deleteDcPension,
        saveDbPension,
        deleteDbPension,
        saveIsa,
        deleteIsa,
        saveGia,
        deleteGia,
        saveCash,
        deleteCash,
        saveInvestmentBond,
        deleteInvestmentBond,
        saveOtherInvestment,
        deleteOtherInvestment,
        saveProperty,
        deleteProperty,
        saveMortgage,
        deleteMortgage,
        updateStatePension,
        updateAssumptions,
      }}
    >
      {children}
    </CashflowContext.Provider>
  );
};

export function useCashflow(): CashflowContextType {
  const context = useContext(CashflowContext);
  if (!context) {
    throw new Error('useCashflow must be used within a CashflowProvider');
  }
  return context;
}
