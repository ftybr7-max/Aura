/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Official UK Rules & Sources Registry
 * Centralizes all material tax rules, primary statutory citations, review dates, and future legislation status.
 * Grounded in GOV.UK, HMRC Internal Manuals, DWP, and legislation.gov.uk.
 */

export interface UKRuleRecord {
  id: string;
  category: 'Income Tax & NI' | 'Pensions & LSA' | 'ISAs & Capital Gains' | 'Inheritance Tax' | 'State Pension';
  ruleName: string;
  currentValue: string;
  status: 'current' | 'legislated_future' | 'policy_proposed';
  effectiveDate: string;
  nextReviewDate: string;
  primaryAuthority: string;
  primaryUrl: string;
  technicalInterpretationUrl: string;
  notes: string;
}

export const UK_RULES_REGISTRY: UKRuleRecord[] = [
  {
    id: 'personal-allowance',
    category: 'Income Tax & NI',
    ruleName: 'Personal Allowance & £100k Taper (2026/27)',
    currentValue: '£12,570 (£1 reduction per £2 over £100,000, £0 at £125,140)',
    status: 'current',
    effectiveDate: '6 April 2021 (Statutorily frozen through April 2028)',
    nextReviewDate: 'Autumn Budget 2028',
    primaryAuthority: 'Income Tax Act 2007 s.35 / Finance Act 2021',
    primaryUrl: 'https://www.gov.uk/income-tax-rates',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/employment-income-manual/eim00500',
    notes: 'Generates an effective 60% marginal income tax rate on income between £100,000 and £125,140 due to withdrawal of the personal allowance.',
  },
  {
    id: 'income-tax-scotland',
    category: 'Income Tax & NI',
    ruleName: 'Scottish Income Tax Bands (2026/27)',
    currentValue: '19% Starter (£12,571-£15,397), 20% Basic (£15,398-£27,490), 21% Intermediate (£27,491-£43,662), 42% Higher (£43,663-£75,000), 45% Advanced (£75,001-£125,140), 48% Top (>£125,140)',
    status: 'current',
    effectiveDate: '6 April 2026',
    nextReviewDate: 'Scottish Budget 2026/27',
    primaryAuthority: 'Scottish Government Budget / Scotland Act 2016',
    primaryUrl: 'https://www.gov.uk/scottish-income-tax',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/employment-income-manual/eim40000',
    notes: 'Applies to non-savings, non-dividend earned and pension income of Scottish tax residents. Savings and dividends remain under rUK rates.',
  },
  {
    id: 'national-insurance',
    category: 'Income Tax & NI',
    ruleName: 'Class 1 Employee National Insurance (2026/27)',
    currentValue: '8% between £12,570 and £50,270; 2% above £50,270',
    status: 'current',
    effectiveDate: '6 April 2024 (Maintained for 2026/27)',
    nextReviewDate: 'Finance Act Annual Review',
    primaryAuthority: 'National Insurance Contributions (Reduction in Rates) Act 2024',
    primaryUrl: 'https://www.gov.uk/national-insurance-rates-letters',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim01000',
    notes: 'Exempt for pension income drawdowns, dividends, and individuals past State Pension Age.',
  },
  {
    id: 'pension-annual-allowance',
    category: 'Pensions & LSA',
    ruleName: 'Pension Annual Allowance & High Earner Taper (2026/27)',
    currentValue: '£60,000 standard; tapered down to min £10,000 if Threshold Income > £200k & Adjusted Income > £260k-£360k',
    status: 'current',
    effectiveDate: '6 April 2023 (Maintained for 2026/27)',
    nextReviewDate: 'Annual Finance Bill',
    primaryAuthority: 'Finance (No. 2) Act 2023 / HMRC Pensions Tax Manual PTM050000',
    primaryUrl: 'https://www.gov.uk/tax-on-your-private-pension/annual-allowance',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/pensions-tax-manual/ptm050000',
    notes: 'Relief at source provides automatic 20% basic rate top-up; higher (40%) and additional (45%) rate relief claimed on Self Assessment.',
  },
  {
    id: 'lump-sum-allowance',
    category: 'Pensions & LSA',
    ruleName: 'Lump Sum Allowance (LSA) & Tax-Free Cash (2026/27)',
    currentValue: '£268,275 lifetime cap on 25% tax-free lump sums (LTA abolished)',
    status: 'current',
    effectiveDate: '6 April 2024 (Finance Act 2024)',
    nextReviewDate: 'Annual Review',
    primaryAuthority: 'Finance Act 2024 / HMRC Lifetime Allowance Abolition Framework',
    primaryUrl: 'https://www.gov.uk/tax-on-your-private-pension/tax-free-lump-sums',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/pensions-tax-manual/ptm063000',
    notes: 'Lump Sum & Death Benefit Allowance (LSDBA) capped at £1,073,100. Existing primary/enhanced protection grandfathered where registered.',
  },
  {
    id: 'pension-nmpa-2028',
    category: 'Pensions & LSA',
    ruleName: 'Normal Minimum Pension Age (NMPA) Rise to 57',
    currentValue: 'Rising from age 55 to age 57 for private pension access',
    status: 'legislated_future',
    effectiveDate: '6 April 2028',
    nextReviewDate: 'Enacted in Primary Legislation',
    primaryAuthority: 'Finance Act 2022 s.10 / HMRC Pensions Tax Manual PTM062205',
    primaryUrl: 'https://www.gov.uk/hmrc-internal-manuals/pensions-tax-manual/ptm062205',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/pensions-tax-manual/ptm062205',
    notes: 'Individuals born after 5 April 1973 will not be able to access private pensions until age 57 (unless protected pension age applies).',
  },
  {
    id: 'pension-iht-2027',
    category: 'Inheritance Tax',
    ruleName: 'DC Pensions Brought into IHT Estate (April 2027 Reform)',
    currentValue: 'Unspent DC pension pots & death benefits included within 40% taxable IHT estate',
    status: 'legislated_future',
    effectiveDate: '6 April 2027',
    nextReviewDate: 'Finance Bill 2026/27 Enactment',
    primaryAuthority: 'HM Treasury / Autumn Budget 2024 Policy Paper & Technical Consultation',
    primaryUrl: 'https://www.gov.uk/government/publications/autumn-budget-2024',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/inheritance-tax-manual',
    notes: 'Fundamentally changes UK retirement decumulation: removes the tax incentive to preserve DC pensions and spend ISAs first.',
  },
  {
    id: 'state-pension',
    category: 'State Pension',
    ruleName: 'New State Pension & Triple Lock (2026/27)',
    currentValue: '£12,450.00 / yr (~£239.50 / wk under 2026/27 Triple Lock uprating)',
    status: 'current',
    effectiveDate: '6 April 2026',
    nextReviewDate: '6 April 2027 (Annual Triple Lock Determination)',
    primaryAuthority: 'Department for Work and Pensions (DWP) / Pensions Act 2014',
    primaryUrl: 'https://www.gov.uk/new-state-pension',
    technicalInterpretationUrl: 'https://www.gov.uk/government/organisations/department-for-work-pensions',
    notes: 'State Pension age is 66, transitioning to 67 between 2026 and 2028 under the Pensions Act 2014 schedule.',
  },
  {
    id: 'isa-annual-limit',
    category: 'ISAs & Capital Gains',
    ruleName: 'Individual Savings Account (ISA) Allowance (2026/27)',
    currentValue: '£20,000 per adult per tax year (Individual ownership only)',
    status: 'current',
    effectiveDate: '6 April 2017 (Maintained at £20,000)',
    nextReviewDate: 'Annual Review',
    primaryAuthority: 'HMRC Individual Savings Account Regulations 1998 (as amended)',
    primaryUrl: 'https://www.gov.uk/individual-savings-accounts',
    technicalInterpretationUrl: 'https://www.gov.uk/guidance/manage-isa-investors',
    notes: '100% free from UK Income Tax and Capital Gains Tax. Under UK law, ISAs cannot be held in joint names.',
  },
  {
    id: 'capital-gains-tax',
    category: 'ISAs & Capital Gains',
    ruleName: 'Capital Gains Tax Exemption & Rates (2026/27)',
    currentValue: '£3,000 annual exemption; 18% basic rate / 24% higher & additional rate',
    status: 'current',
    effectiveDate: '30 October 2024 / Maintained for 2026/27',
    nextReviewDate: 'Annual Review',
    primaryAuthority: 'Taxation of Chargeable Gains Act 1992 / Autumn Budget 2024',
    primaryUrl: 'https://www.gov.uk/capital-gains-tax/rates',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual',
    notes: 'Uniform 18% and 24% rates apply across shares, funds, and residential property gains above the £3,000 annual exempt amount.',
  },
  {
    id: 'iht-nil-rate-band',
    category: 'Inheritance Tax',
    ruleName: 'IHT Nil Rate Band & Residence Nil Rate Band (2026/27)',
    currentValue: '£325,000 NRB + up to £175,000 RNRB (100% spousal transfer up to £1,000,000 for married couples/civil partners)',
    status: 'current',
    effectiveDate: 'Statutorily frozen through April 2030',
    nextReviewDate: 'Autumn Budget 2030',
    primaryAuthority: 'Inheritance Tax Act 1984 / Autumn Budget 2024',
    primaryUrl: 'https://www.gov.uk/inheritance-tax',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/inheritance-tax-manual/ihtm13000',
    notes: 'Spousal exemption & transferable NRB/RNRB only apply to legally married couples and registered civil partners (not unmarried cohabitants). RNRB tapers £1 for every £2 net estate exceeds £2,000,000.',
  },
  {
    id: 'investment-bonds-tax',
    category: 'ISAs & Capital Gains',
    ruleName: 'Investment Bonds 5% Tax-Deferred Allowance & Chargeable Events',
    currentValue: '5% per annum cumulative tax-deferred withdrawal of original capital for up to 20 years (100% total); Onshore bonds receive 20% notional basic rate credit; Top Slicing Relief across policy years',
    status: 'current',
    effectiveDate: 'Enacted (ITTOIA 2005 s.498-507)',
    nextReviewDate: 'Ongoing Statutory Regime',
    primaryAuthority: 'Income Tax (Trading and Other Income) Act 2005 ss.461-546 / HMRC IPTM3500',
    primaryUrl: 'https://www.gov.uk/hmrc-internal-manuals/insurance-policyholder-taxation-manual/iptm3500',
    technicalInterpretationUrl: 'https://www.gov.uk/hmrc-internal-manuals/insurance-policyholder-taxation-manual/iptm3800',
    notes: 'Withdrawals within the 5% cumulative limit trigger zero immediate income tax liability. Onshore life funds pay internal tax so basic-rate investors pay 0% extra on chargeable event gains, while higher/additional rate investors pay 20%/25% net with Top Slicing Relief. Offshore bonds grow with gross roll-up and are taxed at marginal rates on encashment.',
  },
];
