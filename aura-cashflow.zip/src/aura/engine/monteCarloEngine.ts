/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Stochastic Monte Carlo Simulation Engine
 * Runs 1,000 randomized market sequence trials to assess plan resilience and sequence-of-returns risk.
 */

import { CashflowProfile, MonteCarloSummary, MonteCarloTrialResult, WhatIfScenarioModifiers } from '../../types/cashflow';
import { DEFAULT_WHAT_IF_MODIFIERS, runCashflowSimulation } from './cashflowEngine';

/**
 * Box-Muller transform to generate normally distributed random numbers.
 */
function randomNormal(mean: number, stdDev: number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + z * stdDev;
}

/**
 * Runs 1,000 stochastic trials across the investment timeline.
 */
export function runMonteCarloSimulation(
  profile: CashflowProfile,
  modifiers: WhatIfScenarioModifiers = DEFAULT_WHAT_IF_MODIFIERS,
  trialsCount: number = 1000
): MonteCarloSummary {
  const baseResult = runCashflowSimulation(profile, modifiers);
  const yearsCount = baseResult.years.length;
  const currentAge = profile.personal.currentAge;
  const retirementAge = baseResult.retirementAge;

  const meanReturn = (profile.assumptions.defaultEquityGrowthRatePercent + modifiers.marketReturnOffsetPercent) / 100;
  const volatility = 0.12; // 12% annual standard deviation for balanced multi-asset portfolio

  const trials: MonteCarloTrialResult[] = [];
  const yearlyWealthByYear: number[][] = Array.from({ length: yearsCount }, () => []);

  for (let t = 0; t < trialsCount; t++) {
    // Initial liquid wealth in today's money
    let currentLiquid = baseResult.years[0].liquidNetWorthReal;
    let isSuccessful = true;
    let depletionAge: number | null = null;
    const yearlyLiquidWealth: number[] = [];

    for (let y = 0; y < yearsCount; y++) {
      const yearData = baseResult.years[y];
      const age = currentAge + y;
      const isRetired = age >= retirementAge;

      // Generate stochastic annual real return for this year
      const stochasticReturn = randomNormal(meanReturn, volatility);

      // Pre-retirement savings or post-retirement net cashflow gap
      const netInflowReal = yearData.netSpendableInflowReal;
      const netOutflowReal = yearData.totalOutflowsReal;
      const cashflowDifference = netInflowReal - netOutflowReal;

      // Apply annual market return to liquid investments
      if (currentLiquid > 0) {
        currentLiquid = currentLiquid * (1 + stochasticReturn);
      }

      // Add surplus or deduct living expense shortfall
      currentLiquid += cashflowDifference;

      if (currentLiquid <= 0) {
        currentLiquid = 0;
        if (isSuccessful && isRetired) {
          isSuccessful = false;
          depletionAge = age;
        }
      }

      yearlyLiquidWealth.push(currentLiquid);
      yearlyWealthByYear[y].push(currentLiquid);
    }

    trials.push({
      trialIndex: t,
      isSuccessful,
      depletionAge,
      terminalWealthReal: currentLiquid,
      yearlyLiquidWealthReal: yearlyLiquidWealth,
    });
  }

  // Calculate Percentiles at each year
  const yearlyPercentilesReal = yearlyWealthByYear.map((wealthArray, index) => {
    const sorted = [...wealthArray].sort((a, b) => a - b);
    const p = (pct: number) => sorted[Math.floor((pct / 100) * (sorted.length - 1))] || 0;
    return {
      age: currentAge + index,
      p10: p(10),
      p25: p(25),
      p50: p(50), // median
      p75: p(75),
      p90: p(90),
    };
  });

  const successfulTrials = trials.filter((t) => t.isSuccessful).length;
  const successProbabilityPercent = Math.round((successfulTrials / trialsCount) * 100);

  const sortedTerminalWealth = [...trials.map((t) => t.terminalWealthReal)].sort((a, b) => a - b);
  const p10TerminalWealthReal = sortedTerminalWealth[Math.floor(0.10 * sortedTerminalWealth.length)] || 0;
  const medianTerminalWealthReal = sortedTerminalWealth[Math.floor(0.50 * sortedTerminalWealth.length)] || 0;
  const p90TerminalWealthReal = sortedTerminalWealth[Math.floor(0.90 * sortedTerminalWealth.length)] || 0;

  const failedTrialsWithDepletion = trials.filter((t) => t.depletionAge !== null);
  const medianDepletionAge =
    failedTrialsWithDepletion.length > 0
      ? [...failedTrialsWithDepletion.map((t) => t.depletionAge!)].sort((a, b) => a - b)[
          Math.floor(failedTrialsWithDepletion.length / 2)
        ]
      : null;

  let resilienceRating: 'Very High' | 'High' | 'Moderate' | 'Vulnerable' | 'Critical' = 'Moderate';
  let verdictPlainEnglish = '';

  if (successProbabilityPercent >= 90) {
    resilienceRating = 'Very High';
    verdictPlainEnglish =
      'Your retirement plan has exceptional resilience. Even across the bottom 10% of historical market downturns, your liquid assets and guaranteed pension income comfortably fund your desired lifestyle to age 95.';
  } else if (successProbabilityPercent >= 80) {
    resilienceRating = 'High';
    verdictPlainEnglish =
      'High likelihood of success. Your plan absorbs standard market cycles and recessions well. In a prolonged bear market at retirement, minor discretionary spending adjustments (5-10%) would prevent capital erosion.';
  } else if (successProbabilityPercent >= 65) {
    resilienceRating = 'Moderate';
    verdictPlainEnglish =
      'Moderate resilience. There is a measurable sequence-of-returns risk if market downturns coincide with your early retirement years. Consider maintaining a 2-year cash buffer or exploring slight downsize equity release.';
  } else if (successProbabilityPercent >= 45) {
    resilienceRating = 'Vulnerable';
    verdictPlainEnglish =
      'Plan is vulnerable to market volatility. Under adverse market conditions, assets may deplete around age ' +
      (medianDepletionAge || 82) +
      '. Increasing pre-retirement contributions or deferring retirement by 1-2 years significantly reinforces security.';
  } else {
    resilienceRating = 'Critical';
    verdictPlainEnglish =
      'Critical shortfall risk. Your current expenditure significantly outpaces sustainable withdrawal limits. Structural adjustments to target retirement age, pension savings, or spending are strongly recommended.';
  }

  return {
    trialsCount,
    successProbabilityPercent,
    medianTerminalWealthReal,
    p10TerminalWealthReal,
    p90TerminalWealthReal,
    medianDepletionAge,
    yearlyPercentilesReal,
    resilienceRating,
    verdictPlainEnglish,
  };
}
