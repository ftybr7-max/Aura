/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Comprehensive Year-by-Year Cashflow Simulation Engine
 * Centralizes all cashflow projections, multi-pot drawdown, asset growth, and tax calculations.
 */

import {
  CashflowProfile,
  CashflowSimulationResult,
  YearlyCashflowData,
  WhatIfScenarioModifiers,
  DrawdownPotKey,
} from '../../types/cashflow';
import { calculateComprehensiveTaxYear, calculateInheritanceTax, UK_TAX_CONSTANTS } from './taxEngine';

export const DEFAULT_WHAT_IF_MODIFIERS: WhatIfScenarioModifiers = {
  retirementAgeOffset: 0,
  spendingChangePercent: 0,
  marketReturnOffsetPercent: 0,
  inflationRateOffsetPercent: 0,
  earlyDownsize: false,
  marketCrashAtRetirement: false,
  longTermCareCostShock: false,
  includeStatePension: true,
};

/**
 * Runs the full deterministic cashflow simulation across the client's planning horizon.
 */
export function runCashflowSimulation(
  profile: CashflowProfile,
  modifiers: WhatIfScenarioModifiers = DEFAULT_WHAT_IF_MODIFIERS
): CashflowSimulationResult {
  const currentAge = profile.personal.currentAge;
  const planningHorizonAge = Math.max(currentAge + 1, profile.personal.planningHorizonAge || 95);
  const targetRetirementAge = Math.max(currentAge, profile.personal.targetRetirementAge + modifiers.retirementAgeOffset);
  
  const inflationRate = Math.max(0, (profile.assumptions.inflationRatePercent + modifiers.inflationRateOffsetPercent) / 100);
  const currentCalendarYear = new Date().getFullYear();
  const totalYears = planningHorizonAge - currentAge + 1;

  // Clone opening asset balances (Nominal)
  let currentCash = profile.cashAccounts.reduce((sum, a) => sum + a.balance, 0);
  let currentIsa = profile.isas.reduce((sum, a) => sum + a.balance, 0);
  let currentGia = profile.gias.reduce((sum, a) => sum + a.balance, 0);
  let currentGiaCostBasis = profile.gias.reduce((sum, a) => sum + (a.costBasis || a.balance), 0);
  let currentInvestmentBonds = (profile.investmentBonds || []).reduce((sum, b) => sum + b.currentValue, 0);
  let currentOtherInvestments = (profile.otherInvestments || []).reduce((sum, o) => sum + o.balance, 0);
  let currentPension = profile.dcPensions.reduce((sum, a) => sum + a.currentPotValue, 0);
  let currentProperty = profile.properties.reduce((sum, a) => sum + a.currentValue, 0);
  let currentMortgage = profile.mortgages.reduce((sum, m) => sum + m.outstandingBalance, 0);
  let currentOtherDebt = profile.otherLiabilities.reduce((sum, l) => sum + l.outstandingBalance, 0);

  // Cumulative tracking
  let remainingLsa = UK_TAX_CONSTANTS.LUMP_SUM_ALLOWANCE; // £268,275 lifetime cap
  let totalLifetimeTaxPaidNominal = 0;
  let totalLifetimeTaxPaidReal = 0;
  let totalPensionsSavedTaxNominal = 0;
  let ageFundsDepleted: number | null = null;
  let peakNetWorthNominal = 0;
  let peakNetWorthAge = currentAge;

  const yearlyData: YearlyCashflowData[] = [];

  for (let i = 0; i < totalYears; i++) {
    const age = currentAge + i;
    const partnerAge = profile.personal.hasPartner && profile.personal.partnerAge ? profile.personal.partnerAge + i : undefined;
    const calendarYear = currentCalendarYear + i;
    const isRetired = profile.personal.isAlreadyRetired || age >= targetRetirementAge;
    const isPartnerRetired = profile.personal.partnerIsAlreadyRetired || (partnerAge && profile.personal.partnerTargetRetirementAge ? partnerAge >= profile.personal.partnerTargetRetirementAge : false);
    const discountFactor = Math.pow(1 + inflationRate, i);

    // 1. INFLOWS & ATTRIBUTION (Strictly individual PAYE / pensions, apportioned joint assets)
    // Primary individual streams
    let primaryGrossEmploymentIncome = 0;
    let primaryGrossBonus = 0;
    let primaryEmployeePensionContribSalarySacrifice = 0;
    let primaryEmployeePensionContribReliefAtSource = 0;
    let primaryEmployerPensionContribTotal = 0;

    // Partner individual streams
    let partnerGrossEmploymentIncome = 0;
    let partnerGrossBonus = 0;
    let partnerEmployeePensionContribSalarySacrifice = 0;
    let partnerEmployeePensionContribReliefAtSource = 0;
    let partnerEmployerPensionContribTotal = 0;

    profile.employment.forEach((emp) => {
      const growthFactor = Math.pow(1 + emp.annualGrowthPercent / 100, i);
      const empSalary = emp.annualGross * growthFactor;
      const empBonus = emp.annualBonus * growthFactor;

      if (emp.owner === 'partner' && profile.personal.hasPartner) {
        if (!isPartnerRetired) {
          partnerGrossEmploymentIncome += empSalary;
          partnerGrossBonus += empBonus;
          const empContrib = (empSalary * emp.employeePensionPercent) / 100;
          const emplyrContrib = (empSalary * emp.employerPensionPercent) / 100;
          partnerEmployerPensionContribTotal += emplyrContrib;
          if (emp.isSalarySacrifice) {
            partnerEmployeePensionContribSalarySacrifice += empContrib;
          } else {
            partnerEmployeePensionContribReliefAtSource += empContrib;
          }
        }
      } else {
        // Primary employment
        if (!isRetired) {
          primaryGrossEmploymentIncome += empSalary;
          primaryGrossBonus += empBonus;
          const empContrib = (empSalary * emp.employeePensionPercent) / 100;
          const emplyrContrib = (empSalary * emp.employerPensionPercent) / 100;
          primaryEmployerPensionContribTotal += emplyrContrib;
          if (emp.isSalarySacrifice) {
            primaryEmployeePensionContribSalarySacrifice += empContrib;
          } else {
            primaryEmployeePensionContribReliefAtSource += empContrib;
          }
        }
      }
    });

    // Defined Benefit Pensions (strictly individual under UK Pensions Tax Manual)
    let primaryDbPensionIncome = 0;
    let partnerDbPensionIncome = 0;
    profile.dbPensions.forEach((db) => {
      if (db.owner === 'partner' && profile.personal.hasPartner && partnerAge !== undefined) {
        if (partnerAge >= db.startAge) {
          const yearsInPayment = partnerAge - db.startAge;
          const escalation = Math.pow(1 + db.annualEscalationPercent / 100, yearsInPayment);
          partnerDbPensionIncome += db.annualGuaranteedIncome * escalation;
        }
      } else {
        if (age >= db.startAge) {
          const yearsInPayment = age - db.startAge;
          const escalation = Math.pow(1 + db.annualEscalationPercent / 100, yearsInPayment);
          primaryDbPensionIncome += db.annualGuaranteedIncome * escalation;
        }
      }
    });

    // State Pension (individual statutory entitlement based on NI record)
    let primaryStatePensionIncome = 0;
    let partnerStatePensionIncome = 0;
    if (modifiers.includeStatePension && profile.statePension.includeStatePension) {
      if (age >= profile.statePension.primaryStatePensionAge) {
        const yearsInPayment = age - profile.statePension.primaryStatePensionAge;
        const uprating = Math.pow(1 + Math.max(inflationRate, profile.statePension.tripleLockAssumptionPercent / 100), yearsInPayment);
        primaryStatePensionIncome += profile.statePension.primaryAnnualAmount * uprating;
      }
      if (profile.personal.hasPartner && partnerAge && profile.statePension.partnerStatePensionAge && partnerAge >= profile.statePension.partnerStatePensionAge) {
        const partnerYears = partnerAge - profile.statePension.partnerStatePensionAge;
        const partnerUprating = Math.pow(1 + Math.max(inflationRate, profile.statePension.tripleLockAssumptionPercent / 100), partnerYears);
        partnerStatePensionIncome += (profile.statePension.partnerAnnualAmount || 0) * partnerUprating;
      }
    }

    // Rental Incomes (supports primary, partner, or joint split)
    let primaryRentalIncome = 0;
    let partnerRentalIncome = 0;
    profile.properties.forEach((p) => {
      if (!p.isPrimaryResidence && p.rentalIncomeAnnual > 0) {
        const annualRental = p.rentalIncomeAnnual * Math.pow(1 + inflationRate, i);
        if (p.owner === 'partner' && profile.personal.hasPartner) {
          partnerRentalIncome += annualRental;
        } else if (p.owner === 'primary' || !profile.personal.hasPartner) {
          primaryRentalIncome += annualRental;
        } else {
          // Joint ownership (default 50/50 or custom split)
          const primaryShare = (p.jointSplitPercent !== undefined ? p.jointSplitPercent : 50) / 100;
          primaryRentalIncome += annualRental * primaryShare;
          partnerRentalIncome += annualRental * (1 - primaryShare);
        }
      }
    });

    // Other Incomes (taxable and non-taxable)
    let primaryOtherTaxableIncome = 0;
    let partnerOtherTaxableIncome = 0;
    let otherNonTaxableIncome = 0;

    profile.otherIncomes.forEach((oi) => {
      if (age >= oi.startAge && age <= oi.endAge) {
        const infl = oi.isInflationLinked ? Math.pow(1 + inflationRate, i) : 1;
        const amt = oi.annualAmount * infl;
        if (oi.isTaxable) {
          if (oi.owner === 'partner' && profile.personal.hasPartner) {
            partnerOtherTaxableIncome += amt;
          } else if (oi.owner === 'primary' || !profile.personal.hasPartner) {
            primaryOtherTaxableIncome += amt;
          } else {
            // Joint ownership
            const primaryShare = (oi.jointSplitPercent !== undefined ? oi.jointSplitPercent : 50) / 100;
            primaryOtherTaxableIncome += amt * primaryShare;
            partnerOtherTaxableIncome += amt * (1 - primaryShare);
          }
        } else {
          otherNonTaxableIncome += amt;
        }
      }
    });

    // 5% Annual Tax-Deferred Regular Withdrawals from Investment Bonds
    let bondRegularWithdrawalThisYear = 0;
    (profile.investmentBonds || []).forEach((b) => {
      let withdrawalAmt = 0;
      if (b.annualWithdrawalAmount !== undefined && b.annualWithdrawalAmount > 0) {
        withdrawalAmt = b.annualWithdrawalAmount;
      } else if (b.annualWithdrawalPercent !== undefined && b.annualWithdrawalPercent > 0) {
        withdrawalAmt = (b.originalPremium * b.annualWithdrawalPercent) / 100;
      }
      if (withdrawalAmt > 0 && currentInvestmentBonds > 0) {
        const actualTaken = Math.min(currentInvestmentBonds, withdrawalAmt);
        currentInvestmentBonds -= actualTaken;
        bondRegularWithdrawalThisYear += actualTaken;
      }
    });
    otherNonTaxableIncome += bondRegularWithdrawalThisYear;

    // Aggregated Gross Inflow
    const primaryGrossTotal =
      primaryGrossEmploymentIncome +
      primaryGrossBonus +
      primaryDbPensionIncome +
      primaryStatePensionIncome +
      primaryRentalIncome +
      primaryOtherTaxableIncome;

    const partnerGrossTotal =
      partnerGrossEmploymentIncome +
      partnerGrossBonus +
      partnerDbPensionIncome +
      partnerStatePensionIncome +
      partnerRentalIncome +
      partnerOtherTaxableIncome;

    const totalGrossInflow = primaryGrossTotal + partnerGrossTotal + otherNonTaxableIncome;

    // 2. INDIVIDUAL UK TAX ASSESSMENTS (UK Income Tax & NI are strictly assessed per individual)
    const isPastPrimarySpa = age >= profile.statePension.primaryStatePensionAge;
    const primaryBaseTax = calculateComprehensiveTaxYear({
      grossSalary: primaryGrossEmploymentIncome,
      grossBonus: primaryGrossBonus,
      dbPensionIncome: primaryDbPensionIncome,
      statePensionIncome: primaryStatePensionIncome,
      taxableRentalOtherIncome: primaryRentalIncome + primaryOtherTaxableIncome,
      employeePensionContribSalarySacrifice: primaryEmployeePensionContribSalarySacrifice,
      employeePensionContribReliefAtSource: primaryEmployeePensionContribReliefAtSource,
      taxRegion: profile.personal.taxRegion,
      isPastStatePensionAge: isPastPrimarySpa,
    });

    const isPastPartnerSpa = partnerAge !== undefined && profile.statePension.partnerStatePensionAge
      ? partnerAge >= profile.statePension.partnerStatePensionAge
      : false;

    const partnerBaseTax = profile.personal.hasPartner && partnerAge !== undefined
      ? calculateComprehensiveTaxYear({
          grossSalary: partnerGrossEmploymentIncome,
          grossBonus: partnerGrossBonus,
          dbPensionIncome: partnerDbPensionIncome,
          statePensionIncome: partnerStatePensionIncome,
          taxableRentalOtherIncome: partnerRentalIncome + partnerOtherTaxableIncome,
          employeePensionContribSalarySacrifice: partnerEmployeePensionContribSalarySacrifice,
          employeePensionContribReliefAtSource: partnerEmployeePensionContribReliefAtSource,
          taxRegion: profile.personal.partnerTaxRegion || profile.personal.taxRegion,
          isPastStatePensionAge: isPastPartnerSpa,
        })
      : null;

    const combinedBaseIncomeTax = primaryBaseTax.totalIncomeTax + (partnerBaseTax ? partnerBaseTax.totalIncomeTax : 0);
    const combinedNationalInsurance = primaryBaseTax.nationalInsurance + (partnerBaseTax ? partnerBaseTax.nationalInsurance : 0);
    const combinedBaseTaxPaid = primaryBaseTax.totalTax + (partnerBaseTax ? partnerBaseTax.totalTax : 0);
    const combinedNetSpendableBeforeDrawdown =
      primaryBaseTax.netIncome +
      (partnerBaseTax ? partnerBaseTax.netIncome : 0) +
      otherNonTaxableIncome;

    // 3. OUTFLOWS & SPENDING
    let livingExpenses = 0;
    const spendingMultiplier = 1 + modifiers.spendingChangePercent / 100;

    profile.expenses.forEach((exp) => {
      const isExpenseActive = exp.isSingleYear
        ? age === exp.startAge
        : age >= exp.startAge && age <= exp.endAge;

      if (isExpenseActive) {
        let baseExp = exp.annualAmount;
        if (isRetired && !exp.isSingleYear) {
          baseExp *= exp.retirementMultiplier;
        }
        const infl = exp.isInflationLinked ? Math.pow(1 + inflationRate, i) : 1;
        livingExpenses += baseExp * infl * spendingMultiplier;
      }
    });

    // Process Key One-Off Life Events for this year
    const activeLifeEventsForYear = (profile.lifeEvents || []).filter((evt) => {
      if (evt.targetAge !== undefined && evt.targetAge === age) return true;
      if (evt.calendarYear !== undefined && evt.calendarYear === calendarYear) return true;
      return false;
    });

    let lifeEventInflowThisYear = 0;
    let lifeEventOutflowThisYear = 0;

    activeLifeEventsForYear.forEach((evt) => {
      if (evt.direction === 'inflow') {
        lifeEventInflowThisYear += evt.amount;
      } else {
        lifeEventOutflowThisYear += evt.amount;
      }
    });

    // Inflows from life events increase spendable funds/cash
    const netSpendableBeforeDrawdown = combinedNetSpendableBeforeDrawdown + lifeEventInflowThisYear;

    // Long term care shock scenario
    if (modifiers.longTermCareCostShock && age >= 82 && age <= 85) {
      livingExpenses += 55000 * Math.pow(1 + inflationRate, i);
    }

    // Mortgage & Debt Payments
    let mortgagePayments = 0;
    if (currentMortgage > 0) {
      profile.mortgages.forEach((m) => {
        const yearsRemaining = m.remainingTermYears - i;
        if (yearsRemaining > 0) {
          mortgagePayments += m.monthlyPayment * 12;
          // Amortize principal
          const annualInterest = currentMortgage * (m.interestRatePercent / 100);
          const principalPaid = Math.max(0, m.monthlyPayment * 12 - annualInterest);
          currentMortgage = Math.max(0, currentMortgage - principalPaid);
        } else {
          currentMortgage = 0;
        }
      });
    }

    let otherDebtPayments = 0;
    if (currentOtherDebt > 0) {
      profile.otherLiabilities.forEach((l) => {
        const yearsRemaining = l.remainingTermYears - i;
        if (yearsRemaining > 0) {
          otherDebtPayments += l.monthlyPayment * 12;
          currentOtherDebt = Math.max(0, currentOtherDebt - (l.monthlyPayment * 12));
        } else {
          currentOtherDebt = 0;
        }
      });
    }

    // Excess Income Gifting (s.21 IHTA 1984 Normal Expenditure Out of Income)
    let excessIncomeGiftThisYear = 0;
    if (profile.excessIncomeGifting?.enabled) {
      const giftPlan = profile.excessIncomeGifting;
      if (age >= giftPlan.startAge && age < giftPlan.startAge + giftPlan.durationYears) {
        excessIncomeGiftThisYear = giftPlan.annualGiftAmount;
      }
    }

    const totalOutflows = livingExpenses + mortgagePayments + otherDebtPayments + lifeEventOutflowThisYear + excessIncomeGiftThisYear;

    // 4. CASHFLOW GAP & DRAWDOWN SEQUENCING
    let drawdownCash = 0;
    let drawdownGia = 0;
    let drawdownIsa = 0;
    let drawdownPensionTaxFree = 0;
    let drawdownPensionTaxable = 0;
    let totalDrawdown = 0;
    let unmetShortfall = 0;
    let additionalTaxFromPension = 0;

    const cashflowGap = totalOutflows - netSpendableBeforeDrawdown;
    const strategy = profile.assumptions.drawdownStrategy || 'tax_optimised';

    if (cashflowGap > 0) {
      // Deficit: need to draw down funds
      let requiredNet = cashflowGap;
      const emergencyReserve = profile.cashAccounts.reduce((sum, a) => sum + (a.isEmergencyFund ? a.minimumReserve : 0), 0);

      // Helper functions for drawing from specific pots
      const drawCash = () => {
        const availableCash = Math.max(0, currentCash - emergencyReserve);
        if (availableCash > 0 && requiredNet > 0) {
          const drawn = Math.min(availableCash, requiredNet);
          drawdownCash += drawn;
          currentCash -= drawn;
          requiredNet -= drawn;
        }
      };

      const drawGia = () => {
        if (currentGia > 0 && requiredNet > 0) {
          const giaDrawn = Math.min(currentGia, requiredNet);
          const gainRatio = currentGia > currentGiaCostBasis ? (currentGia - currentGiaCostBasis) / currentGia : 0;
          const realizedGain = giaDrawn * gainRatio;
          const cgtDue = Math.max(0, realizedGain - UK_TAX_CONSTANTS.CGT_ANNUAL_EXEMPT_AMOUNT) * UK_TAX_CONSTANTS.CGT_BASIC_RATE;
          
          drawdownGia += giaDrawn;
          currentGia -= giaDrawn;
          currentGiaCostBasis = Math.max(0, currentGiaCostBasis - (giaDrawn * (1 - gainRatio)));
          requiredNet -= Math.max(0, giaDrawn - cgtDue);
        }
      };

      const drawIsa = () => {
        if (currentIsa > 0 && requiredNet > 0) {
          const drawn = Math.min(currentIsa, requiredNet);
          drawdownIsa += drawn;
          currentIsa -= drawn;
          requiredNet -= drawn;
        }
      };

      const drawPension = () => {
        if (currentPension > 0 && requiredNet > 0) {
          const availableTaxFree = Math.min(currentPension * 0.25, remainingLsa);
          const taxFreeDrawn = Math.min(availableTaxFree, requiredNet);
          drawdownPensionTaxFree += taxFreeDrawn;
          remainingLsa = Math.max(0, remainingLsa - taxFreeDrawn);
          currentPension = Math.max(0, currentPension - taxFreeDrawn);
          requiredNet -= taxFreeDrawn;

          if (requiredNet > 0 && currentPension > 0) {
            const estimatedMarginalRate = primaryBaseTax.marginalTaxRatePercent > 0 ? primaryBaseTax.marginalTaxRatePercent / 100 : 0.20;
            const grossPensionNeeded = requiredNet / Math.max(0.1, (1 - estimatedMarginalRate));
            const grossDrawn = Math.min(currentPension, grossPensionNeeded);
            
            const finalTaxCalc = calculateComprehensiveTaxYear({
              grossSalary: primaryGrossEmploymentIncome,
              grossBonus: primaryGrossBonus,
              dbPensionIncome: primaryDbPensionIncome,
              statePensionIncome: primaryStatePensionIncome,
              taxableDrawdownIncome: (drawdownPensionTaxable + grossDrawn),
              taxableRentalOtherIncome: primaryRentalIncome + primaryOtherTaxableIncome,
              taxRegion: profile.personal.taxRegion,
              isPastStatePensionAge: isPastPrimarySpa,
            });

            const newAdditionalTax = Math.max(0, finalTaxCalc.totalTax - primaryBaseTax.totalTax);
            const netPensionReceived = grossDrawn - (newAdditionalTax - additionalTaxFromPension);
            additionalTaxFromPension = newAdditionalTax;
            
            drawdownPensionTaxable += grossDrawn;
            currentPension = Math.max(0, currentPension - grossDrawn);
            requiredNet = Math.max(0, requiredNet - Math.max(0, netPensionReceived));
          }
        }
      };

      // Resolve active pot sequence order
      const defaultSequenceMap: Record<string, DrawdownPotKey[]> = {
        tax_optimised: ['cash', 'gia', 'pension', 'isa'],
        pension_first: ['pension', 'gia', 'isa', 'cash'],
        isa_first: ['isa', 'cash', 'gia', 'pension'],
        cash_first: ['cash', 'isa', 'gia', 'pension'],
        pro_rata: ['cash', 'gia', 'pension', 'isa'],
      };

      const customOrder = profile.assumptions.customDrawdownOrder;
      const sequenceToExecute: DrawdownPotKey[] =
        strategy === 'custom' && customOrder && customOrder.length === 4
          ? customOrder
          : defaultSequenceMap[strategy] || ['cash', 'gia', 'pension', 'isa'];

      // Execute pots in resolved sequence
      for (const pot of sequenceToExecute) {
        if (requiredNet <= 0) break;
        if (pot === 'cash') drawCash();
        else if (pot === 'gia') drawGia();
        else if (pot === 'pension') drawPension();
        else if (pot === 'isa') drawIsa();
      }

      totalDrawdown = drawdownCash + drawdownGia + drawdownIsa + drawdownPensionTaxFree + drawdownPensionTaxable;
      unmetShortfall = Math.max(0, requiredNet);

      if (unmetShortfall > 100 && ageFundsDepleted === null && isRetired) {
        ageFundsDepleted = age;
      }
    } else {
      // Surplus cashflow: reinvest in savings (Cash / ISA / GIA)
      const surplus = -cashflowGap;
      const isaRoom = Math.max(0, UK_TAX_CONSTANTS.ISA_ANNUAL_ALLOWANCE * (profile.personal.hasPartner ? 2 : 1));
      const isaAdd = Math.min(surplus, isaRoom);
      currentIsa += isaAdd;
      const remSurplus = surplus - isaAdd;
      currentCash += remSurplus;
    }

    // Add ongoing regular contributions before retirement (with Bed & ISA GIA transfer and cash source depletion support)
    const emergencyReserve = profile.cashAccounts.reduce((sum, a) => sum + (a.isEmergencyFund ? a.minimumReserve : 0), 0);

    if (!isRetired) {
      profile.isas.forEach((a) => {
        const annualIsaTarget = a.ongoingMonthlyContribution * 12;
        if (annualIsaTarget > 0) {
          if (a.fundingSource === 'cash' || a.fundingSource?.startsWith('cash-')) {
            // Funded from Cash pot: once depleted to emergency reserve, contribution stops
            const availableCash = Math.max(0, currentCash - emergencyReserve);
            const transferAmount = Math.min(availableCash, annualIsaTarget);
            if (transferAmount > 0) {
              currentCash = Math.max(0, currentCash - transferAmount);
              currentIsa += transferAmount;
            }
          } else if (a.fundingSource && a.fundingSource !== 'surplus_cash') {
            // Bed & ISA: transfer from GIA. Once GIA is depleted, transfer/contribution stops
            const transferAmount = Math.min(currentGia, annualIsaTarget);
            if (transferAmount > 0) {
              const gainRatio = currentGia > currentGiaCostBasis ? (currentGia - currentGiaCostBasis) / currentGia : 0;
              const realizedGain = transferAmount * gainRatio;
              const cgtDue = Math.max(0, realizedGain - UK_TAX_CONSTANTS.CGT_ANNUAL_EXEMPT_AMOUNT) * UK_TAX_CONSTANTS.CGT_BASIC_RATE;
              
              currentGia = Math.max(0, currentGia - transferAmount);
              currentGiaCostBasis = Math.max(0, currentGiaCostBasis - (transferAmount * (1 - gainRatio)));
              currentIsa += Math.max(0, transferAmount - cgtDue);
            }
          } else {
            // Funded from regular surplus income
            currentIsa += annualIsaTarget;
          }
        }
      });

      profile.gias.forEach((a) => {
        const annualGiaTarget = a.ongoingMonthlyContribution * 12;
        if (annualGiaTarget > 0) {
          if (a.fundingSource === 'cash' || a.fundingSource?.startsWith('cash-')) {
            // Funded from Cash: once depleted, contribution stops
            const availableCash = Math.max(0, currentCash - emergencyReserve);
            const transferAmount = Math.min(availableCash, annualGiaTarget);
            if (transferAmount > 0) {
              currentCash = Math.max(0, currentCash - transferAmount);
              currentGia += transferAmount;
              currentGiaCostBasis += transferAmount;
            }
          } else {
            // Funded from regular surplus income
            currentGia += annualGiaTarget;
            currentGiaCostBasis += annualGiaTarget;
          }
        }
      });

      // Individual SIPP / DC Pension Direct Contributions (e.g. from Cash or GIA or Surplus)
      profile.dcPensions.forEach((p) => {
        const annualDcDirectTarget = (p.ongoingMonthlyContribution || 0) * 12;
        if (annualDcDirectTarget > 0) {
          if (p.fundingSource === 'cash' || p.fundingSource?.startsWith('cash-')) {
            // Funded from Cash: once depleted, contribution stops
            const availableCash = Math.max(0, currentCash - emergencyReserve);
            const transferAmount = Math.min(availableCash, annualDcDirectTarget);
            if (transferAmount > 0) {
              currentCash = Math.max(0, currentCash - transferAmount);
              // Gross up with 20% basic rate relief at source (e.g. net £80 becomes £100 in pension)
              const grossPensionAdd = transferAmount * 1.25;
              currentPension += grossPensionAdd;
              totalPensionsSavedTaxNominal += transferAmount * 0.25;
            }
          } else if (p.fundingSource === 'gia' || (p.fundingSource && p.fundingSource !== 'salary' && p.fundingSource !== 'surplus_cash')) {
            // Funded from GIA: once depleted, contribution stops
            const transferAmount = Math.min(currentGia, annualDcDirectTarget);
            if (transferAmount > 0) {
              const gainRatio = currentGia > currentGiaCostBasis ? (currentGia - currentGiaCostBasis) / currentGia : 0;
              const realizedGain = transferAmount * gainRatio;
              const cgtDue = Math.max(0, realizedGain - UK_TAX_CONSTANTS.CGT_ANNUAL_EXEMPT_AMOUNT) * UK_TAX_CONSTANTS.CGT_BASIC_RATE;
              
              currentGia = Math.max(0, currentGia - transferAmount);
              currentGiaCostBasis = Math.max(0, currentGiaCostBasis - (transferAmount * (1 - gainRatio)));
              const netInvested = Math.max(0, transferAmount - cgtDue);
              const grossPensionAdd = netInvested * 1.25;
              currentPension += grossPensionAdd;
              totalPensionsSavedTaxNominal += netInvested * 0.25;
            }
          } else {
            // Funded from regular surplus income
            const grossPensionAdd = annualDcDirectTarget * 1.25;
            currentPension += grossPensionAdd;
            totalPensionsSavedTaxNominal += annualDcDirectTarget * 0.25;
          }
        }
      });

      // Pension accumulation from all active employment contracts
      const totalPensionContribsThisYear =
        primaryEmployeePensionContribSalarySacrifice +
        primaryEmployeePensionContribReliefAtSource +
        primaryEmployerPensionContribTotal +
        partnerEmployeePensionContribSalarySacrifice +
        partnerEmployeePensionContribReliefAtSource +
        partnerEmployerPensionContribTotal;

      currentPension += totalPensionContribsThisYear;
    }

    // 5. ASSET GROWTH & MARKET CRASH SCENARIO
    let equityGrowthRate = (profile.assumptions.defaultEquityGrowthRatePercent + modifiers.marketReturnOffsetPercent) / 100;
    const bondCashGrowthRate = profile.assumptions.defaultBondCashGrowthRatePercent / 100;
    const platformFee = profile.assumptions.advisorPlatformFeePercent / 100;

    // Market crash sequence risk shock: defaults to next calendar year (2027) or user-specified year/retirement
    const isCrashYear = !!modifiers.marketCrashAtRetirement && (
      modifiers.marketCrashTiming === 'at_retirement'
        ? age === targetRetirementAge
        : modifiers.marketCrashTiming === 'custom_year'
        ? calendarYear === (modifiers.marketCrashYear || (currentCalendarYear + 1))
        : calendarYear === (currentCalendarYear + 1) // default next calendar year (2027)
    );

    if (isCrashYear) {
      equityGrowthRate = modifiers.marketCrashSeverityPercent !== undefined
        ? modifiers.marketCrashSeverityPercent / 100
        : -0.25;
    }

    // Apply net growth
    currentPension = Math.max(0, currentPension * (1 + equityGrowthRate - platformFee));
    currentIsa = Math.max(0, currentIsa * (1 + equityGrowthRate - platformFee));
    currentGia = Math.max(0, currentGia * (1 + equityGrowthRate - platformFee));
    currentInvestmentBonds = Math.max(0, currentInvestmentBonds * (1 + equityGrowthRate - platformFee));
    currentOtherInvestments = Math.max(0, currentOtherInvestments * (1 + equityGrowthRate - platformFee));
    currentCash = Math.max(0, currentCash * (1 + bondCashGrowthRate));

    // Property growth & Downsizing
    const propertyGrowth = (profile.properties[0]?.annualGrowthPercent || 3.0) / 100;
    currentProperty *= (1 + propertyGrowth);

    // Profile-level planned downsizing on properties (from Lite Fact-Find or Section 7)
    profile.properties.forEach((p) => {
      if (p.isDownsizingPlanned) {
        const isDownsizeYear =
          (p.downsizeYear !== undefined && calendarYear === p.downsizeYear) ||
          (p.downsizeYear === undefined && p.downsizeAge !== undefined && age === p.downsizeAge) ||
          (p.downsizeYear === undefined && p.downsizeAge === undefined && age === targetRetirementAge);

        if (isDownsizeYear) {
          let releasedAmount = 0;
          if (p.downsizeReleasedAmount !== undefined && p.downsizeReleasedAmount > 0) {
            releasedAmount = Math.min(currentProperty, p.downsizeReleasedAmount);
          } else if (p.downsizeTargetValue !== undefined && p.downsizeTargetValue < currentProperty) {
            releasedAmount = currentProperty - p.downsizeTargetValue;
          } else if (currentProperty > 200000) {
            // Default 35% equity release if not specified
            releasedAmount = currentProperty * 0.35;
          }

          if (releasedAmount > 0) {
            currentProperty = Math.max(0, currentProperty - releasedAmount);
            // Feeds directly into liquid Cash reserves as required
            currentCash += releasedAmount;
          }
        }
      }
    });

    if (modifiers.earlyDownsize && age === targetRetirementAge && currentProperty > 350000) {
      const releasedEquity = currentProperty * 0.4;
      currentProperty *= 0.6;
      currentIsa += Math.min(releasedEquity, UK_TAX_CONSTANTS.ISA_ANNUAL_ALLOWANCE);
      currentCash += Math.max(0, releasedEquity - UK_TAX_CONSTANTS.ISA_ANNUAL_ALLOWANCE);
    }

    // 6. TOTAL TAX & NET WORTH SUMMARIES
    const totalTaxPaidYear = combinedBaseTaxPaid + additionalTaxFromPension;
    totalLifetimeTaxPaidNominal += totalTaxPaidYear;
    totalLifetimeTaxPaidReal += totalTaxPaidYear / discountFactor;
    totalPensionsSavedTaxNominal += primaryBaseTax.pensionTaxReliefReceived + (partnerBaseTax?.pensionTaxReliefReceived || 0);

    const liquidNetWorthNominal =
      currentPension + currentIsa + currentGia + currentCash + currentInvestmentBonds + currentOtherInvestments;
    const totalNetWorthNominal = liquidNetWorthNominal + currentProperty - currentMortgage - currentOtherDebt;

    if (totalNetWorthNominal > peakNetWorthNominal) {
      peakNetWorthNominal = totalNetWorthNominal;
      peakNetWorthAge = age;
    }

    // Real terms (Discounted to today's purchasing power)
    const pensionPotReal = currentPension / discountFactor;
    const isaBalanceReal = currentIsa / discountFactor;
    const giaBalanceReal = currentGia / discountFactor;
    const cashBalanceReal = currentCash / discountFactor;
    const propertyValueReal = currentProperty / discountFactor;
    const liquidNetWorthReal = liquidNetWorthNominal / discountFactor;
    const totalNetWorthReal = totalNetWorthNominal / discountFactor;
    const mortgageDebtReal = currentMortgage / discountFactor;

    // 7. INHERITANCE TAX (IHT) ESTIMATE AT CURRENT YEAR
    const isPost2027 = calendarYear >= 2027;
    const ihtEst = calculateInheritanceTax({
      propertyValue: currentProperty,
      liquidAssets: currentIsa + currentGia + currentCash + currentInvestmentBonds + currentOtherInvestments,
      dcPensionPot: currentPension,
      mortgageDebt: currentMortgage,
      otherDebt: currentOtherDebt,
      hasPartner: profile.personal.hasPartner,
      relationshipType: profile.personal.relationshipType || 'spouse_civil_partner',
      isPostApril2027: isPost2027,
      includePensionsInIhtPost2027: profile.assumptions.includePensionsInIhtPost2027,
      historicGifts: profile.historicGifts || [],
    });

    yearlyData.push({
      year: i + 1,
      calendarYear,
      age,
      partnerAge,
      isRetired,
      isPartnerRetired,
      discountFactor,

      grossEmploymentIncome: primaryGrossEmploymentIncome + partnerGrossEmploymentIncome,
      grossBonus: primaryGrossBonus + partnerGrossBonus,
      dbPensionIncome: primaryDbPensionIncome + partnerDbPensionIncome,
      statePensionIncome: primaryStatePensionIncome + partnerStatePensionIncome,
      rentalIncome: primaryRentalIncome + partnerRentalIncome,
      otherTaxableIncome: primaryOtherTaxableIncome + partnerOtherTaxableIncome,
      otherNonTaxableIncome,
      totalGrossInflow,

      pensionContributionsTotal:
        primaryEmployeePensionContribSalarySacrifice +
        primaryEmployeePensionContribReliefAtSource +
        primaryEmployerPensionContribTotal +
        partnerEmployeePensionContribSalarySacrifice +
        partnerEmployeePensionContribReliefAtSource +
        partnerEmployerPensionContribTotal,
      incomeTax: combinedBaseIncomeTax + (additionalTaxFromPension > 0 ? additionalTaxFromPension : 0),
      nationalInsurance: combinedNationalInsurance,
      totalTaxPaid: totalTaxPaidYear,
      netSpendableInflow: netSpendableBeforeDrawdown,

      // Individual Partner Breakdown
      primaryGrossInflow: primaryGrossTotal,
      primaryIncomeTax: primaryBaseTax.totalIncomeTax + (additionalTaxFromPension > 0 ? additionalTaxFromPension : 0),
      primaryNationalInsurance: primaryBaseTax.nationalInsurance,
      primaryNetIncome: primaryBaseTax.netIncome,
      partnerGrossInflow: partnerGrossTotal,
      partnerIncomeTax: partnerBaseTax ? partnerBaseTax.totalIncomeTax : 0,
      partnerNationalInsurance: partnerBaseTax ? partnerBaseTax.nationalInsurance : 0,
      partnerNetIncome: partnerBaseTax ? partnerBaseTax.netIncome : 0,
      isMarriedOrCivilPartner: profile.personal.hasPartner && (profile.personal.relationshipType === 'spouse_civil_partner' || !profile.personal.relationshipType),
      spousalIhtExemptionApplied: ihtEst.isSpousalExemptionEligible,

      livingExpenses,
      mortgagePayments,
      otherDebtPayments,
      totalOutflows,

      cashflowSurplusOrDeficit: netSpendableBeforeDrawdown - totalOutflows,

      drawdownCash,
      drawdownGia,
      drawdownIsa,
      drawdownPensionTaxFree,
      drawdownPensionTaxable,
      totalDrawdown,
      unmetShortfall,

      pensionPotNominal: currentPension,
      isaBalanceNominal: currentIsa,
      giaBalanceNominal: currentGia,
      cashBalanceNominal: currentCash,
      propertyValueNominal: currentProperty,
      liquidNetWorthNominal,
      totalNetWorthNominal,
      mortgageDebtNominal: currentMortgage,

      pensionPotReal,
      isaBalanceReal,
      giaBalanceReal,
      cashBalanceReal,
      propertyValueReal,
      liquidNetWorthReal,
      totalNetWorthReal,
      mortgageDebtReal,

      totalGrossInflowReal: totalGrossInflow / discountFactor,
      netSpendableInflowReal: netSpendableBeforeDrawdown / discountFactor,
      totalOutflowsReal: totalOutflows / discountFactor,
      totalDrawdownReal: totalDrawdown / discountFactor,
      unmetShortfallReal: unmetShortfall / discountFactor,

      activeLifeEvents: activeLifeEventsForYear.length > 0 ? activeLifeEventsForYear : undefined,

      estimatedGrossEstate: ihtEst.grossEstate,
      estimatedIhtLiability: ihtEst.ihtLiability,
      netEstateToHeirs: ihtEst.netEstateToBeneficiaries,
    });
  }

  // Key Milestones Extraction
  const todayMilestone = yearlyData[0];
  const retirementYear = yearlyData.find((y) => y.age === targetRetirementAge) || yearlyData[yearlyData.length - 1];
  const age75Year = yearlyData.find((y) => y.age === 75) || yearlyData[yearlyData.length - 1];
  const age95Year = yearlyData.find((y) => y.age === 95) || yearlyData[yearlyData.length - 1];
  const endYear = yearlyData[yearlyData.length - 1];

  const wealthAtRetirementNominal = retirementYear.totalNetWorthNominal;
  const wealthAtRetirementReal = retirementYear.totalNetWorthReal;
  const legacyWealthAt95Nominal = age95Year.totalNetWorthNominal;
  const legacyWealthAt95Real = age95Year.totalNetWorthReal;

  // Sustainable Spending: Average annual real spending supported through horizon
  const sustainableAnnualSpendingReal = retirementYear.totalOutflowsReal;
  const sustainableAnnualSpendingNominal = retirementYear.totalOutflows;

  return {
    years: yearlyData,
    retirementAge: targetRetirementAge,
    planningHorizonAge,
    ageFundsDepleted,
    isPlanFullyFunded: ageFundsDepleted === null,
    sustainableAnnualSpendingNominal,
    sustainableAnnualSpendingReal,
    wealthAtRetirementNominal,
    wealthAtRetirementReal,
    legacyWealthAt95Nominal,
    legacyWealthAt95Real,
    totalLifetimeTaxPaidNominal,
    totalLifetimeTaxPaidReal,
    totalPensionsSavedTaxNominal,
    peakNetWorthNominal,
    peakNetWorthAge,
    projectedIhtLiabilityAtEndNominal: endYear.estimatedIhtLiability,
    projectedIhtLiabilityAtEndReal: endYear.estimatedIhtLiability / endYear.discountFactor,
    summaryMilestones: {
      today: { age: currentAge, netWorth: todayMilestone.totalNetWorthReal },
      retirement: { age: targetRetirementAge, netWorth: retirementYear.totalNetWorthReal, annualSpending: retirementYear.totalOutflowsReal },
      mortgageFreeAge: profile.mortgages.length > 0 ? currentAge + (profile.mortgages[0]?.remainingTermYears || 0) : undefined,
      statePensionAge: profile.statePension.primaryStatePensionAge,
      age75: { netWorth: age75Year.totalNetWorthReal },
      planningHorizon: { age: planningHorizonAge, netWorth: endYear.totalNetWorthReal },
    },
  };
}
