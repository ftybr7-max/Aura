/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Aura Cashflow — Official UK Tax Engine
 * Grounded in current UK legislation (HMRC, DWP, GOV.UK, legislation.gov.uk)
 * Evaluated for UK Tax Year 2026/27 and legislated future enactments (e.g. April 2027 Pension IHT, 2028 NMPA Age 57)
 */

import { TaxCalculationResult, TaxRegion, LegalRelationshipType } from '../../types/cashflow';

export const UK_TAX_CONSTANTS = {
  // Tax Year Identification
  TAX_YEAR_LABEL: '2026/27',

  // Personal Allowance (Frozen through April 2028 under Finance Act 2021 / Autumn Statement)
  STANDARD_PERSONAL_ALLOWANCE: 12570,
  PERSONAL_ALLOWANCE_TAPER_THRESHOLD: 100000,
  PERSONAL_ALLOWANCE_TAPER_RATE: 0.5, // £1 reduction for every £2 of Adjusted Net Income over £100,000 (£0 at £125,140)

  // England, Wales, NI Income Tax Bands (after Personal Allowance)
  BASIC_RATE_LIMIT: 37700, // up to £50,270 total income
  HIGHER_RATE_LIMIT: 125140, // from £50,271 to £125,140
  BASIC_RATE: 0.20,
  HIGHER_RATE: 0.40,
  ADDITIONAL_RATE: 0.45,

  // Scotland Income Tax Bands (2026/27 Scottish Budget)
  SCOTLAND_STARTER_LIMIT: 2827, // £12,571 - £15,397
  SCOTLAND_BASIC_LIMIT: 14920, // £15,398 - £27,490
  SCOTLAND_INTERMEDIATE_LIMIT: 31092, // £27,491 - £43,662
  SCOTLAND_HIGHER_LIMIT: 62430, // £43,663 - £75,000
  SCOTLAND_ADVANCED_LIMIT: 112570, // £75,001 - £125,140
  SCOTLAND_STARTER_RATE: 0.19,
  SCOTLAND_BASIC_RATE: 0.20,
  SCOTLAND_INTERMEDIATE_RATE: 0.21,
  SCOTLAND_HIGHER_RATE: 0.42,
  SCOTLAND_ADVANCED_RATE: 0.45,
  SCOTLAND_TOP_RATE: 0.48,

  // National Insurance Class 1 Primary (Employees) - 2026/27
  NI_PRIMARY_THRESHOLD: 12570,
  NI_UPPER_EARNINGS_LIMIT: 50270,
  NI_MAIN_RATE: 0.08, // 8% primary main rate
  NI_HIGHER_RATE: 0.02, // 2% above UEL

  // Dividend Tax
  DIVIDEND_ALLOWANCE: 500,
  DIVIDEND_BASIC_RATE: 0.0875,
  DIVIDEND_HIGHER_RATE: 0.3375,
  DIVIDEND_ADDITIONAL_RATE: 0.3935,

  // Capital Gains Tax (Autumn Budget 2024 legislated rates)
  CGT_ANNUAL_EXEMPT_AMOUNT: 3000,
  CGT_BASIC_RATE: 0.18, // 18% basic rate
  CGT_HIGHER_RATE: 0.24, // 24% higher/additional rate

  // ISAs (Individual only under UK law)
  ISA_ANNUAL_ALLOWANCE: 20000,

  // Investment Bonds (ITTOIA 2005 s.498-507 & HMRC IPTM3500)
  INVESTMENT_BOND_ANNUAL_TAX_DEFERRED_RATE: 0.05, // 5% per annum of original premium
  INVESTMENT_BOND_MAX_DEFERRED_YEARS: 20, // 20 years = 100% of original capital
  ONSHORE_BOND_BASIC_RATE_TAX_CREDIT: 0.20, // 20% treated as paid within UK life fund

  // Pensions (2026/27)
  PENSION_ANNUAL_ALLOWANCE: 60000,
  PENSION_MONEY_PURCHASE_ANNUAL_ALLOWANCE: 10000, // MPAA once flexibly accessing DC pot
  PENSION_TAPER_THRESHOLD_INCOME: 200000,
  PENSION_TAPER_ADJUSTED_INCOME: 260000,
  PENSION_MIN_TAPERED_ALLOWANCE: 10000,
  LUMP_SUM_ALLOWANCE: 268275, // 25% tax-free lump sum lifetime cap (Finance Act 2024)
  LUMP_SUM_AND_DEATH_BENEFIT_ALLOWANCE: 1073100, // LSDBA
  NORMAL_MINIMUM_PENSION_AGE_CURRENT: 55,
  NORMAL_MINIMUM_PENSION_AGE_2028: 57, // Rising to 57 on 6 April 2028 (Finance Act 2022)

  // State Pension (Full New State Pension 2026/27 with Triple Lock uprating)
  STATE_PENSION_FULL_ANNUAL: 12450.00, // ~£239.50 per week

  // Inheritance Tax (Frozen through April 2030)
  IHT_NIL_RATE_BAND: 325000,
  IHT_RESIDENCE_NIL_RATE_BAND: 175000,
  IHT_RNRB_TAPER_THRESHOLD: 2000000,
  IHT_STANDARD_RATE: 0.40,
};

/**
 * Calculates the exact tapered Personal Allowance for a given adjusted net income.
 */
export function calculatePersonalAllowance(adjustedNetIncome: number): number {
  if (adjustedNetIncome <= UK_TAX_CONSTANTS.PERSONAL_ALLOWANCE_TAPER_THRESHOLD) {
    return UK_TAX_CONSTANTS.STANDARD_PERSONAL_ALLOWANCE;
  }
  const excess = adjustedNetIncome - UK_TAX_CONSTANTS.PERSONAL_ALLOWANCE_TAPER_THRESHOLD;
  const reduction = excess * UK_TAX_CONSTANTS.PERSONAL_ALLOWANCE_TAPER_RATE;
  return Math.max(0, UK_TAX_CONSTANTS.STANDARD_PERSONAL_ALLOWANCE - reduction);
}

/**
 * Calculates UK Income Tax for earned and pension income.
 */
export function calculateIncomeTax(
  taxableEarnedIncome: number,
  personalAllowance: number,
  region: TaxRegion = 'england_wales_ni'
): {
  basicRateTax: number;
  higherRateTax: number;
  additionalRateTax: number;
  totalIncomeTax: number;
  effectiveRate: number;
} {
  const taxableIncome = Math.max(0, taxableEarnedIncome - personalAllowance);

  if (taxableIncome <= 0) {
    return {
      basicRateTax: 0,
      higherRateTax: 0,
      additionalRateTax: 0,
      totalIncomeTax: 0,
      effectiveRate: 0,
    };
  }

  if (region === 'scotland') {
    // Scottish tax calculation
    let rem = taxableIncome;
    const starter = Math.min(rem, UK_TAX_CONSTANTS.SCOTLAND_STARTER_LIMIT);
    rem -= starter;

    const basic = Math.min(rem, UK_TAX_CONSTANTS.SCOTLAND_BASIC_LIMIT - UK_TAX_CONSTANTS.SCOTLAND_STARTER_LIMIT);
    rem -= basic;

    const intermediate = Math.min(rem, UK_TAX_CONSTANTS.SCOTLAND_INTERMEDIATE_LIMIT - UK_TAX_CONSTANTS.SCOTLAND_BASIC_LIMIT);
    rem -= intermediate;

    const higher = Math.min(rem, UK_TAX_CONSTANTS.SCOTLAND_HIGHER_LIMIT - UK_TAX_CONSTANTS.SCOTLAND_INTERMEDIATE_LIMIT);
    rem -= higher;

    const advanced = Math.min(rem, UK_TAX_CONSTANTS.SCOTLAND_ADVANCED_LIMIT - UK_TAX_CONSTANTS.SCOTLAND_HIGHER_LIMIT);
    rem -= advanced;

    const top = rem;

    const tax =
      starter * UK_TAX_CONSTANTS.SCOTLAND_STARTER_RATE +
      basic * UK_TAX_CONSTANTS.SCOTLAND_BASIC_RATE +
      intermediate * UK_TAX_CONSTANTS.SCOTLAND_INTERMEDIATE_RATE +
      higher * UK_TAX_CONSTANTS.SCOTLAND_HIGHER_RATE +
      advanced * UK_TAX_CONSTANTS.SCOTLAND_ADVANCED_RATE +
      top * UK_TAX_CONSTANTS.SCOTLAND_TOP_RATE;

    return {
      basicRateTax: starter * UK_TAX_CONSTANTS.SCOTLAND_STARTER_RATE + basic * UK_TAX_CONSTANTS.SCOTLAND_BASIC_RATE + intermediate * UK_TAX_CONSTANTS.SCOTLAND_INTERMEDIATE_RATE,
      higherRateTax: higher * UK_TAX_CONSTANTS.SCOTLAND_HIGHER_RATE + advanced * UK_TAX_CONSTANTS.SCOTLAND_ADVANCED_RATE,
      additionalRateTax: top * UK_TAX_CONSTANTS.SCOTLAND_TOP_RATE,
      totalIncomeTax: tax,
      effectiveRate: taxableEarnedIncome > 0 ? (tax / taxableEarnedIncome) * 100 : 0,
    };
  }

  // Standard England, Wales, Northern Ireland tax calculation
  let basicTax = 0;
  let higherTax = 0;
  let additionalTax = 0;

  const basicBand = Math.min(taxableIncome, UK_TAX_CONSTANTS.BASIC_RATE_LIMIT);
  basicTax = basicBand * UK_TAX_CONSTANTS.BASIC_RATE;

  const higherBandMax = UK_TAX_CONSTANTS.HIGHER_RATE_LIMIT - UK_TAX_CONSTANTS.STANDARD_PERSONAL_ALLOWANCE;
  if (taxableIncome > basicBand) {
    const higherBand = Math.min(taxableIncome, higherBandMax) - basicBand;
    higherTax = higherBand * UK_TAX_CONSTANTS.HIGHER_RATE;
  }

  if (taxableIncome > higherBandMax) {
    const additionalBand = taxableIncome - higherBandMax;
    additionalTax = additionalBand * UK_TAX_CONSTANTS.ADDITIONAL_RATE;
  }

  const total = basicTax + higherTax + additionalTax;
  return {
    basicRateTax: basicTax,
    higherRateTax: higherTax,
    additionalRateTax: additionalTax,
    totalIncomeTax: total,
    effectiveRate: taxableEarnedIncome > 0 ? (total / taxableEarnedIncome) * 100 : 0,
  };
}

/**
 * Calculates UK Class 1 Employee National Insurance.
 * Note: Only applied to employment earnings (not on pensions, dividends, or after State Pension Age).
 */
export function calculateNationalInsurance(
  employmentEarnings: number,
  isPastStatePensionAge: boolean = false
): number {
  if (isPastStatePensionAge || employmentEarnings <= UK_TAX_CONSTANTS.NI_PRIMARY_THRESHOLD) {
    return 0;
  }

  const mainBand = Math.min(
    employmentEarnings,
    UK_TAX_CONSTANTS.NI_UPPER_EARNINGS_LIMIT
  ) - UK_TAX_CONSTANTS.NI_PRIMARY_THRESHOLD;

  const mainNI = Math.max(0, mainBand) * UK_TAX_CONSTANTS.NI_MAIN_RATE;

  let upperNI = 0;
  if (employmentEarnings > UK_TAX_CONSTANTS.NI_UPPER_EARNINGS_LIMIT) {
    const upperBand = employmentEarnings - UK_TAX_CONSTANTS.NI_UPPER_EARNINGS_LIMIT;
    upperNI = upperBand * UK_TAX_CONSTANTS.NI_HIGHER_RATE;
  }

  return mainNI + upperNI;
}

/**
 * Complete Net Income and Tax Calculator for an individual in a single tax year.
 * Used uniformly across the entire app so that net income, savings rate, and tax
 * calculations never deviate.
 */
export function calculateComprehensiveTaxYear({
  grossSalary = 0,
  grossBonus = 0,
  dbPensionIncome = 0,
  statePensionIncome = 0,
  taxableDrawdownIncome = 0,
  taxableRentalOtherIncome = 0,
  dividendIncome = 0,
  capitalGains = 0,
  employeePensionContribSalarySacrifice = 0,
  employeePensionContribReliefAtSource = 0,
  taxRegion = 'england_wales_ni',
  isPastStatePensionAge = false,
}: {
  grossSalary?: number;
  grossBonus?: number;
  dbPensionIncome?: number;
  statePensionIncome?: number;
  taxableDrawdownIncome?: number;
  taxableRentalOtherIncome?: number;
  dividendIncome?: number;
  capitalGains?: number;
  employeePensionContribSalarySacrifice?: number;
  employeePensionContribReliefAtSource?: number;
  taxRegion?: TaxRegion;
  isPastStatePensionAge?: boolean;
}): TaxCalculationResult {
  // Salary sacrifice directly reduces gross salary for tax and NI purposes
  const adjustedEmploymentEarnings = Math.max(0, grossSalary + grossBonus - employeePensionContribSalarySacrifice);

  // Total gross taxable income (before relief-at-source deduction)
  const earnedAndPensionGross =
    adjustedEmploymentEarnings +
    dbPensionIncome +
    statePensionIncome +
    taxableDrawdownIncome +
    taxableRentalOtherIncome;

  // Adjusted Net Income for personal allowance taper (relief at source grossed up pension contributions reduce ANI)
  const grossedUpPensionRelief = employeePensionContribReliefAtSource * 1.25;
  const adjustedNetIncome = Math.max(0, earnedAndPensionGross + dividendIncome - grossedUpPensionRelief);

  const personalAllowance = calculatePersonalAllowance(adjustedNetIncome);

  // Income Tax on Earned & Pension Income
  const incomeTaxResult = calculateIncomeTax(earnedAndPensionGross, personalAllowance, taxRegion);

  // National Insurance (only on employment earnings, before State Pension Age)
  const nationalInsurance = calculateNationalInsurance(adjustedEmploymentEarnings, isPastStatePensionAge);

  // Dividend Tax
  let dividendTax = 0;
  const taxableDividends = Math.max(0, dividendIncome - UK_TAX_CONSTANTS.DIVIDEND_ALLOWANCE);
  if (taxableDividends > 0) {
    // Simplified dividend tier allocation based on total income band
    const totalIncome = earnedAndPensionGross + taxableDividends;
    if (totalIncome <= UK_TAX_CONSTANTS.BASIC_RATE_LIMIT + personalAllowance) {
      dividendTax = taxableDividends * UK_TAX_CONSTANTS.DIVIDEND_BASIC_RATE;
    } else if (totalIncome <= UK_TAX_CONSTANTS.HIGHER_RATE_LIMIT) {
      dividendTax = taxableDividends * UK_TAX_CONSTANTS.DIVIDEND_HIGHER_RATE;
    } else {
      dividendTax = taxableDividends * UK_TAX_CONSTANTS.DIVIDEND_ADDITIONAL_RATE;
    }
  }

  // Capital Gains Tax
  let cgtPaid = 0;
  const taxableGains = Math.max(0, capitalGains - UK_TAX_CONSTANTS.CGT_ANNUAL_EXEMPT_AMOUNT);
  if (taxableGains > 0) {
    const isHigherOrAdditional = earnedAndPensionGross > (UK_TAX_CONSTANTS.BASIC_RATE_LIMIT + personalAllowance);
    const rate = isHigherOrAdditional ? UK_TAX_CONSTANTS.CGT_HIGHER_RATE : UK_TAX_CONSTANTS.CGT_BASIC_RATE;
    cgtPaid = taxableGains * rate;
  }

  const totalGross = grossSalary + grossBonus + dbPensionIncome + statePensionIncome + taxableDrawdownIncome + taxableRentalOtherIncome + dividendIncome;
  const totalTax = incomeTaxResult.totalIncomeTax + nationalInsurance + dividendTax + cgtPaid;
  const netIncome = Math.max(0, totalGross - totalTax - employeePensionContribSalarySacrifice - employeePensionContribReliefAtSource);

  // Effective and marginal tax rates
  const effectiveTaxRatePercent = totalGross > 0 ? (totalTax / totalGross) * 100 : 0;
  
  // Calculate marginal rate at current income level
  let marginalTaxRatePercent = 0;
  if (isPastStatePensionAge) {
    if (adjustedNetIncome > 100000 && adjustedNetIncome <= 125140) {
      marginalTaxRatePercent = 60; // 40% income tax + 20% personal allowance loss
    } else if (adjustedNetIncome > 125140) {
      marginalTaxRatePercent = 45;
    } else if (adjustedNetIncome > 50270) {
      marginalTaxRatePercent = 40;
    } else if (adjustedNetIncome > 12570) {
      marginalTaxRatePercent = 20;
    }
  } else {
    // Employed (subject to NI)
    if (adjustedNetIncome > 100000 && adjustedNetIncome <= 125140) {
      marginalTaxRatePercent = 62; // 40% income tax + 20% PA loss + 2% NI
    } else if (adjustedNetIncome > 125140) {
      marginalTaxRatePercent = 47; // 45% + 2% NI
    } else if (adjustedNetIncome > 50270) {
      marginalTaxRatePercent = 42; // 40% + 2% NI
    } else if (adjustedNetIncome > 12570) {
      marginalTaxRatePercent = 28; // 20% + 8% NI
    }
  }

  return {
    grossIncome: totalGross,
    adjustedNetIncome,
    personalAllowance,
    basicRateTax: incomeTaxResult.basicRateTax,
    higherRateTax: incomeTaxResult.higherRateTax,
    additionalRateTax: incomeTaxResult.additionalRateTax,
    totalIncomeTax: incomeTaxResult.totalIncomeTax,
    nationalInsurance,
    dividendTax,
    cgtPaid,
    totalTax,
    netIncome,
    effectiveTaxRatePercent,
    marginalTaxRatePercent,
    pensionTaxReliefReceived: grossedUpPensionRelief - employeePensionContribReliefAtSource,
  };
}

/**
 * Calculates statutory UK IHT taper relief for a gift based on elapsed years (s.3A & s.7(4) IHTA 1984).
 * Returns elapsed full years, taper relief reduction percentage, and effective tax rate multiplier.
 */
export function calculateGiftTaperRelief(giftDateString: string, referenceDateString = '2026-08-20'): {
  yearsElapsed: number;
  taperReductionPercent: number; // e.g. 0%, 20%, 40%, 60%, 80%, 100%
  taxRatePercent: number; // e.g. 40%, 32%, 24%, 16%, 8%, 0%
  isExemptBySurvival: boolean;
  statusLabel: string;
} {
  const giftDate = new Date(giftDateString);
  const refDate = new Date(referenceDateString);
  
  if (isNaN(giftDate.getTime())) {
    return {
      yearsElapsed: 0,
      taperReductionPercent: 0,
      taxRatePercent: 40,
      isExemptBySurvival: false,
      statusLabel: '0-3 Years (0% Taper / 40% Tax)',
    };
  }

  const diffMs = refDate.getTime() - giftDate.getTime();
  const diffDays = Math.max(0, diffMs / (1000 * 60 * 60 * 24));
  const yearsElapsed = Math.floor(diffDays / 365.25);

  if (yearsElapsed >= 7) {
    return {
      yearsElapsed,
      taperReductionPercent: 100,
      taxRatePercent: 0,
      isExemptBySurvival: true,
      statusLabel: '7+ Years (100% Exempt - Outside Estate)',
    };
  } else if (yearsElapsed >= 6) {
    return {
      yearsElapsed,
      taperReductionPercent: 80,
      taxRatePercent: 8, // 40% * (1 - 0.8)
      isExemptBySurvival: false,
      statusLabel: '6 to 7 Years (80% Taper / 8% Tax)',
    };
  } else if (yearsElapsed >= 5) {
    return {
      yearsElapsed,
      taperReductionPercent: 60,
      taxRatePercent: 16, // 40% * (1 - 0.6)
      isExemptBySurvival: false,
      statusLabel: '5 to 6 Years (60% Taper / 16% Tax)',
    };
  } else if (yearsElapsed >= 4) {
    return {
      yearsElapsed,
      taperReductionPercent: 40,
      taxRatePercent: 24, // 40% * (1 - 0.4)
      isExemptBySurvival: false,
      statusLabel: '4 to 5 Years (40% Taper / 24% Tax)',
    };
  } else if (yearsElapsed >= 3) {
    return {
      yearsElapsed,
      taperReductionPercent: 20,
      taxRatePercent: 32, // 40% * (1 - 0.2)
      isExemptBySurvival: false,
      statusLabel: '3 to 4 Years (20% Taper / 32% Tax)',
    };
  } else {
    return {
      yearsElapsed,
      taperReductionPercent: 0,
      taxRatePercent: 40,
      isExemptBySurvival: false,
      statusLabel: '0 to 3 Years (0% Taper / 40% Tax)',
    };
  }
}

/**
 * Assesses an individual or household's historic gifts portfolio for UK IHT compliance.
 * Computes NRB erosion, failed PETs in 7-year lookback, and lifetime CLT charges.
 */
export function evaluateHistoricGiftsPortfolio(
  gifts: import('../../types/cashflow').HistoricGift[] = [],
  donorFilter?: 'primary' | 'partner',
  referenceDate = '2026-08-20'
): {
  totalGiftedValue: number;
  totalExemptGiftsValue: number;
  totalActivePetsWithin7Years: number;
  totalActiveCltsWithin7Years: number;
  nrbErodedByGifts: number;
  directGiftTaxDueOnDeath: number;
  processedGifts: Array<
    import('../../types/cashflow').HistoricGift & {
      yearsElapsed: number;
      isExempt: boolean;
      taperReductionPercent: number;
      effectiveTaxRatePercent: number;
      statusLabel: string;
      netTaxableAmount: number;
    }
  >;
} {
  const filtered = donorFilter ? gifts.filter((g) => g.donor === donorFilter) : gifts;

  let totalGiftedValue = 0;
  let totalExemptGiftsValue = 0;
  let totalActivePetsWithin7Years = 0;
  let totalActiveCltsWithin7Years = 0;
  let nrbErodedByGifts = 0;
  let directGiftTaxDueOnDeath = 0;

  // Sort gifts in chronological order for standard 7-year NRB utilization rules
  const sorted = [...filtered].sort((a, b) => new Date(a.giftDate).getTime() - new Date(b.giftDate).getTime());

  let cumulativeNrbUsed = 0;
  const nrbCap = UK_TAX_CONSTANTS.IHT_NIL_RATE_BAND; // £325,000 individual NRB

  const processedGifts = sorted.map((g) => {
    totalGiftedValue += g.amount;
    const taper = calculateGiftTaperRelief(g.giftDate, referenceDate);

    // Apply statutory allowances and exemptions
    let netTaxable = Math.max(0, g.amount - (g.annualExemptionClaimed || 0));
    let isExempt = false;

    if (g.type === 'spousal' || g.type === 'excess_income' || g.type === 'small_gift' || g.type === 'annual_exemption') {
      isExempt = true;
      netTaxable = 0;
      totalExemptGiftsValue += g.amount;
    } else if (taper.isExemptBySurvival) {
      isExempt = true;
      netTaxable = 0;
      totalExemptGiftsValue += g.amount;
    } else {
      // Active within 7 years (failed PET or CLT)
      if (g.type === 'pet') {
        totalActivePetsWithin7Years += netTaxable;
      } else if (g.type === 'clt') {
        totalActiveCltsWithin7Years += netTaxable;
      }

      // Gifts use available NRB in chronological order
      const nrbAvailableForThisGift = Math.max(0, nrbCap - cumulativeNrbUsed);
      const nrbConsumed = Math.min(nrbAvailableForThisGift, netTaxable);
      cumulativeNrbUsed += nrbConsumed;
      nrbErodedByGifts += nrbConsumed;

      const excessOverNrb = Math.max(0, netTaxable - nrbConsumed);
      if (excessOverNrb > 0) {
        const giftTax = excessOverNrb * (taper.taxRatePercent / 100);
        directGiftTaxDueOnDeath += giftTax;
      }
    }

    return {
      ...g,
      yearsElapsed: taper.yearsElapsed,
      isExempt,
      taperReductionPercent: taper.taperReductionPercent,
      effectiveTaxRatePercent: taper.taxRatePercent,
      statusLabel: isExempt ? '100% Exempt (s.18/s.19/s.21 or 7+ yrs)' : taper.statusLabel,
      netTaxableAmount: netTaxable,
    };
  });

  return {
    totalGiftedValue,
    totalExemptGiftsValue,
    totalActivePetsWithin7Years,
    totalActiveCltsWithin7Years,
    nrbErodedByGifts,
    directGiftTaxDueOnDeath,
    processedGifts,
  };
}

/**
 * Evaluates HMRC Section 21 IHTA 1984 Normal Expenditure Out of Income capacity.
 */
export function calculateExcessIncomeGiftingCapacity(
  input:
    | import('../../types/cashflow').CashflowProfile
    | {
        netSpendableIncome: number;
        totalLivingOutflows: number;
      }
): {
  netSpendableIncome: number;
  totalLivingOutflows: number;
  annualNetIncome: number;
  annualLivingExpenses: number;
  totalNetExcessCapacity: number;
  annualSurplusIncome: number;
  monthlySurplusIncome: number;
  hasCapacity: boolean;
  maxExemptGiftingCapacityAnnual: number;
  estimatedAnnualIhtSavedAt40Percent: (giftAmount: number) => number;
} {
  let netSpendable = 0;
  let livingOutflows = 0;

  if ('personal' in input) {
    // Input is CashflowProfile - compute live from profile
    input.employment.forEach((emp) => {
      const gross = emp.annualGross + emp.annualBonus;
      const pensionContrib = (emp.annualGross * emp.employeePensionPercent) / 100;
      const tax = calculateComprehensiveTaxYear({
        grossSalary: emp.annualGross,
        grossBonus: emp.annualBonus,
        employeePensionContribSalarySacrifice: emp.isSalarySacrifice ? pensionContrib : 0,
        employeePensionContribReliefAtSource: !emp.isSalarySacrifice ? pensionContrib : 0,
        taxRegion: emp.owner === 'partner' ? (input.personal.partnerTaxRegion || input.personal.taxRegion) : input.personal.taxRegion,
      });
      netSpendable += tax.netIncome;
    });

    input.otherIncomes.forEach((oi) => {
      netSpendable += oi.annualAmount * (oi.isTaxable ? 0.8 : 1.0);
    });

    input.properties.forEach((p) => {
      if (!p.isPrimaryResidence && p.rentalIncomeAnnual > 0) {
        netSpendable += p.rentalIncomeAnnual * 0.8;
      }
    });

    input.expenses.forEach((exp) => {
      livingOutflows += exp.annualAmount;
    });

    input.mortgages.forEach((m) => {
      livingOutflows += m.monthlyPayment * 12;
    });
  } else {
    netSpendable = input.netSpendableIncome;
    livingOutflows = input.totalLivingOutflows;
  }

  const annualSurplus = Math.max(0, netSpendable - livingOutflows);
  const monthlySurplus = annualSurplus / 12;

  return {
    netSpendableIncome: netSpendable,
    totalLivingOutflows: livingOutflows,
    annualNetIncome: netSpendable,
    annualLivingExpenses: livingOutflows,
    totalNetExcessCapacity: annualSurplus,
    annualSurplusIncome: annualSurplus,
    monthlySurplusIncome: monthlySurplus,
    hasCapacity: annualSurplus > 500,
    maxExemptGiftingCapacityAnnual: annualSurplus,
    estimatedAnnualIhtSavedAt40Percent: (giftAmount: number) => Math.max(0, giftAmount * 0.4),
  };
}

/**
 * Calculates UK Inheritance Tax (IHT) on an estate.
 * Handles the £325,000 Nil Rate Band, £175,000 Residence Nil Rate Band (with £2m taper),
 * Spousal transferable exemptions (up to £1,000,000 for married couples/civil partners under s.18 & s.8A IHTA 1984),
 * Post-April 2027 DC Pension inclusion rule, and historic 7-year PET NRB erosion.
 * 
 * CRITICAL UK STATUTORY DISTINCTION:
 * Spousal IHT Exemption (s.18 IHTA 1984) and Transferable Nil-Rate Band (s.8A IHTA 1984)
 * ONLY apply to legally married spouses and registered civil partners.
 * Unmarried cohabiting partners and other co-owners receive NO spousal exemption or transferable band.
 */
export function calculateInheritanceTax({
  propertyValue = 0,
  liquidAssets = 0,
  dcPensionPot = 0,
  mortgageDebt = 0,
  otherDebt = 0,
  hasPartner = false,
  relationshipType = 'spouse_civil_partner',
  hasSpouseOrCivilPartner,
  isPropertyPassedToDirectDescendants = true,
  isPostApril2027 = true,
  includePensionsInIhtPost2027 = true,
  historicGifts = [],
}: {
  propertyValue?: number;
  liquidAssets?: number;
  dcPensionPot?: number;
  mortgageDebt?: number;
  otherDebt?: number;
  hasPartner?: boolean;
  relationshipType?: LegalRelationshipType;
  hasSpouseOrCivilPartner?: boolean;
  isPropertyPassedToDirectDescendants?: boolean;
  isPostApril2027?: boolean;
  includePensionsInIhtPost2027?: boolean;
  historicGifts?: import('../../types/cashflow').HistoricGift[];
}): {
  grossEstate: number;
  netEstateBeforeTax: number;
  baseNilRateBand: number;
  nrbErodedByHistoricGifts: number;
  nilRateBandAvailable: number;
  residenceNilRateBandAvailable: number;
  totalAllowances: number;
  taxableEstate: number;
  ihtLiability: number;
  directTaxOnFailedPets: number;
  totalIhtDue: number;
  netEstateToBeneficiaries: number;
  isSpousalExemptionEligible: boolean;
  spousalExemptionStatusDescription: string;
} {
  const netProperty = Math.max(0, propertyValue - mortgageDebt);
  const otherLiabilities = otherDebt;
  
  // Post-April 2027 rule: unspent DC pensions are included in the estate
  const pensionInEstate = (isPostApril2027 && includePensionsInIhtPost2027) ? dcPensionPot : 0;
  
  const grossEstate = propertyValue + liquidAssets + pensionInEstate;
  const netEstateBeforeTax = Math.max(0, netProperty + liquidAssets + pensionInEstate - otherLiabilities);

  // Legal relationship check:
  // ONLY married spouses and registered civil partners qualify for transferable nil-rate band and spousal relief.
  const isSpouseEligible = hasSpouseOrCivilPartner !== undefined
    ? hasSpouseOrCivilPartner
    : hasPartner && relationshipType === 'spouse_civil_partner';

  let spousalExemptionStatusDescription = 'Single individual allowances (£325k NRB + £175k RNRB)';
  if (hasPartner) {
    if (relationshipType === 'spouse_civil_partner') {
      spousalExemptionStatusDescription = 'Married / Civil Partnership: 100% spousal exemption (s.18 IHTA 1984) & 2x transferable nil-rate bands (up to £1,000,000)';
    } else if (relationshipType === 'unmarried_partner') {
      spousalExemptionStatusDescription = 'Unmarried Cohabiting Partner: No spousal IHT exemption or transferable band under UK law (standard single allowances apply)';
    } else {
      spousalExemptionStatusDescription = 'Other Co-owner / Non-spouse: Standard single individual allowances apply';
    }
  }

  // Transferable allowance multiplier (2x for legally married / civil partners on death of second spouse)
  const spousalMultiplier = isSpouseEligible ? 2 : 1;
  const baseNrb = UK_TAX_CONSTANTS.IHT_NIL_RATE_BAND * spousalMultiplier;

  // Process historic gifts and NRB erosion
  const giftsEval = evaluateHistoricGiftsPortfolio(historicGifts);
  const nrbErodedByHistoricGifts = Math.min(baseNrb, giftsEval.nrbErodedByGifts);
  const nrb = Math.max(0, baseNrb - nrbErodedByHistoricGifts);

  // Residence Nil Rate Band (RNRB) - applies only if qualifying property exists and is passed to children/grandchildren
  let rnrb = 0;
  if (netProperty > 0 && isPropertyPassedToDirectDescendants) {
    const baseRnrb = Math.min(netProperty, UK_TAX_CONSTANTS.IHT_RESIDENCE_NIL_RATE_BAND * spousalMultiplier);
    
    // Tapering: if estate > £2,000,000
    const taperThreshold = UK_TAX_CONSTANTS.IHT_RNRB_TAPER_THRESHOLD;
    if (netEstateBeforeTax > taperThreshold) {
      const taperExcess = netEstateBeforeTax - taperThreshold;
      const taperReduction = taperExcess * 0.5;
      rnrb = Math.max(0, baseRnrb - taperReduction);
    } else {
      rnrb = baseRnrb;
    }
  }

  const totalAllowances = nrb + rnrb;
  const taxableEstate = Math.max(0, netEstateBeforeTax - totalAllowances);
  const ihtLiability = taxableEstate * UK_TAX_CONSTANTS.IHT_STANDARD_RATE;
  const directTaxOnFailedPets = giftsEval.directGiftTaxDueOnDeath;
  const totalIhtDue = ihtLiability + directTaxOnFailedPets;
  const netEstateToBeneficiaries = netEstateBeforeTax - totalIhtDue;

  return {
    grossEstate,
    netEstateBeforeTax,
    baseNilRateBand: baseNrb,
    nrbErodedByHistoricGifts,
    nilRateBandAvailable: nrb,
    residenceNilRateBandAvailable: rnrb,
    totalAllowances,
    taxableEstate,
    ihtLiability,
    directTaxOnFailedPets,
    totalIhtDue,
    netEstateToBeneficiaries,
    isSpousalExemptionEligible: isSpouseEligible,
    spousalExemptionStatusDescription,
  };
}

/**
 * Evaluates the statutory UK 5% annual cumulative tax-deferred withdrawal allowance,
 * chargeable event gains, 20% on-shore notional tax credit, and top slicing relief divisor
 * under ITTOIA 2005 s.498-507 and HMRC Insurance Policyholder Taxation Manual IPTM3500.
 */
export interface InvestmentBondTaxSummary {
  annual5PercentAllowance: number; // 5% of original premium
  cumulativeAllowanceTotal: number; // 5% * min(20, yearsHeld + 1) * originalPremium
  cumulativeWithdrawalsTaken: number;
  remainingCumulativeAllowance: number;
  plannedAnnualWithdrawal: number;
  isWithdrawalWithin5Percent: boolean;
  excessWithdrawalOverAllowance: number;
  immediateTaxPayable: number;
  onshoreNotionalTaxCreditRate: number; // 20% for onshore, 0% for offshore
  marginalIncomeTaxRateOnGains: number;
  taxDescription: string;
  topSlicingDivisor: number; // yearsHeld
}

export function calculateInvestmentBondTaxSummary(params: {
  bondType: 'onshore' | 'offshore';
  originalPremium: number;
  currentValue: number;
  yearsHeld: number;
  cumulativeWithdrawalsTaken?: number;
  annualWithdrawalAmount?: number;
  annualWithdrawalPercent?: number;
  investorMarginalTaxRatePercent?: number;
}): InvestmentBondTaxSummary {
  const premium = Math.max(0, params.originalPremium || 0);
  const years = Math.max(1, params.yearsHeld || 1);
  const cumulativeTaken = Math.max(0, params.cumulativeWithdrawalsTaken || 0);
  const marginalRate = params.investorMarginalTaxRatePercent ?? 20;

  const annual5PercentAllowance = premium * UK_TAX_CONSTANTS.INVESTMENT_BOND_ANNUAL_TAX_DEFERRED_RATE;
  const maxYearsAccrued = Math.min(UK_TAX_CONSTANTS.INVESTMENT_BOND_MAX_DEFERRED_YEARS, years);
  const cumulativeAllowanceTotal = premium * UK_TAX_CONSTANTS.INVESTMENT_BOND_ANNUAL_TAX_DEFERRED_RATE * maxYearsAccrued;
  const remainingCumulativeAllowance = Math.max(0, cumulativeAllowanceTotal - cumulativeTaken);

  let plannedAnnualWithdrawal = 0;
  if (params.annualWithdrawalAmount !== undefined && params.annualWithdrawalAmount > 0) {
    plannedAnnualWithdrawal = params.annualWithdrawalAmount;
  } else if (params.annualWithdrawalPercent !== undefined && params.annualWithdrawalPercent > 0) {
    plannedAnnualWithdrawal = (premium * params.annualWithdrawalPercent) / 100;
  }

  const isWithdrawalWithin5Percent = plannedAnnualWithdrawal <= annual5PercentAllowance + remainingCumulativeAllowance;
  const excessWithdrawalOverAllowance = Math.max(0, plannedAnnualWithdrawal - (annual5PercentAllowance + remainingCumulativeAllowance));

  // Immediate tax payable on withdrawals within 5% is £0 (Tax-deferred)
  let immediateTaxPayable = 0;
  if (excessWithdrawalOverAllowance > 0) {
    if (params.bondType === 'onshore') {
      // 20% notional tax credit treated as paid
      const netTaxRate = Math.max(0, (marginalRate - 20) / 100);
      immediateTaxPayable = excessWithdrawalOverAllowance * netTaxRate;
    } else {
      // Offshore: taxed at full marginal rate (0%, 20%, 40%, 45%)
      immediateTaxPayable = excessWithdrawalOverAllowance * (marginalRate / 100);
    }
  }

  const onshoreNotionalTaxCreditRate = params.bondType === 'onshore' ? 20 : 0;
  const effectiveTaxRateOnExcess = params.bondType === 'onshore'
    ? Math.max(0, marginalRate - 20)
    : marginalRate;

  let taxDescription = '';
  if (params.bondType === 'onshore') {
    taxDescription = `UK Onshore Bond: 5% annual cumulative allowance (£${annual5PercentAllowance.toLocaleString('en-GB')}/yr). 20% basic rate tax credit is treated as already paid internally. Basic rate taxpayers (20%) have 0% additional tax to pay on gains. Higher rate (40%) pays 20% net; Additional rate (45%) pays 25% net. Top Slicing Relief divisor: ${years} years.`;
  } else {
    taxDescription = `Offshore Bond: 5% annual cumulative allowance (£${annual5PercentAllowance.toLocaleString('en-GB')}/yr). Gross roll-up during growth (no internal UK tax). Chargeable event gains are taxed as income at investor marginal rates (${marginalRate}%) with Top Slicing Relief across ${years} complete policy years.`;
  }

  return {
    annual5PercentAllowance,
    cumulativeAllowanceTotal,
    cumulativeWithdrawalsTaken: cumulativeTaken,
    remainingCumulativeAllowance,
    plannedAnnualWithdrawal,
    isWithdrawalWithin5Percent,
    excessWithdrawalOverAllowance,
    immediateTaxPayable,
    onshoreNotionalTaxCreditRate,
    marginalIncomeTaxRateOnGains: effectiveTaxRateOnExcess,
    taxDescription,
    topSlicingDivisor: years,
  };
}
